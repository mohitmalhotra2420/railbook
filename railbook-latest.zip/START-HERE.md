# RailBook — poora project (continue karne ke liye) · 25 Sep 2026

Ye zip aapke **poore project** ka snapshot hai — web app + server + Android app + tests + previews + APKs.
Naye workspace me bas extract karke `npm ci` chalao aur wahin se aage badho (git history bhi andar hai).

```
railbook-full/
├── START-HERE.md              ← yahi file
├── railbook/                  ← asli repo (Vite + React + TS client + Express/TS server + tests)
│   ├── src/                   ← client (views/, components/, booking/, ai/, irctc/, seatfinder.ts…)
│   ├── server/                ← server (app.ts, agent/, railway/ scrapers…)
│   ├── tests/                 ← 110 files (vitest) — source-of-truth behaviour
│   ├── docs/                  ← RAILBOOK-ADDENDUM (round-by-round history, §9.21 = latest)
│   ├── provas/                ← real payload samples (live se liye gaye)
│   ├── tools/                 ← preview/verification tools (Round-29: build-round29-preview.mjs, probe-live-r29*.mjs)
│   ├── .env                   ← GITHUB_TOKEN + RENDER_API_KEY (deploy ke liye — isko commit NAHI karna)
│   └── .git/                  ← poori history (HEAD: de97b12)
├── android-app/               ← Android WebView app (Kotlin + autofill assets, keystore ke saath)
├── host-scripts/              ← apk-build-v149.sh (APK banane ka script, latest = v149)
├── previews/                  ← har round ke real-render previews (HTML)
└── apks/                      ← latest release APKs (v1.4.8, v1.4.9 — r29 me naya APK nahi)
```

## 1. Turant shuru karne ke liye

```bash
cd railbook
npm ci --include=dev            # node_modules (~130 MB)
npx vitest run                  # poora suite: 99 files / 1006 tests (≈2 min)
./node_modules/.bin/tsc -p tsconfig.server.json   # server TS clean hona chahiye
./node_modules/.bin/tsc --noEmit -p tsconfig.json  # client: 68 puraane errors baseline (koi naya nahi hona chahiye)
npm run build                   # client bundle (dist/)
```

Dev server: `npm run dev` (client) · server: `npm run server` (ya jo scripts package.json me hain).

## 2. Deploy (Render)

`.env` me `RENDER_API_KEY` (aur `GITHUB_TOKEN`) hai. Flow jo har round me chalta hai:

```bash
cd railbook && source .env
git push "https://${GITHUB_TOKEN}@github.com/mohitmalhotra2420/railbook.git" HEAD:main
curl -s -X POST -H "Authorization: Bearer $RENDER_API_KEY" -H "content-type: application/json" \
  -d '{"clearCache":"clear"}' https://api.render.com/v1/services/srv-dae34rqd0e5s73evgjsg/deploys
# poll: GET /v1/services/srv-dae34rqd0e5s73evgjsg/deploys/<id>  → "live"
curl -s https://railbook-gegs.onrender.com/api/version   # commit sha verify
```

Service: `srv-dae34rqd0e5s73evgjsg` · live: https://railbook-gegs.onrender.com

## 3. Android APK

`host-scripts/apk-build-v145.sh` chalane se: JDK17 + Gradle 8.7 + Android SDK (34) set hota hai,
`android-app/` ka copy banta hai, versionCode/Name bump hota hai, `assembleRelease` chalta hai aur
APK `~/RailBook/APKs/` me save hota hai. **Keystore `android-app/railbook-release.keystore` zip me hai**
(update install ke liye wahi key chahiye). Autofill assets yeh hain:

```
android-app/app/src/main/assets/autofill/
  ├── fieldmap.js              (payload validate + generic fill + flags/food/contact rules)
  ├── irctc-passenger.js       (IRCTC page par asli autofill: anchors, food, checkbox, contact)
  ├── railbook-webview-bridge.js (banner/panel + native status line)
  └── railbook-seatboard-live.js
```
`MainActivity.kt` (`injectRailbookCapture`) V2 key `railbookAutofillPayloadV2` pehle padhta hai, phir purani key.

## 4. Current state (26 Sep 2026)

- **Live:** commit `f10d824` (Round-39, 27 Sep 2026), `/api/version` = `f10d824`.
- **Round-20:** direct-trains card = Seat Finder jaisa shared `TrainClassBlock`; kisi bhi class chip par tap → seedha IRCTC-jaisa passenger form (train no/date/from→to auto, catering real, insurance/payment nahi); chat ka lamba jawab `ReplyText` rows me.
- **Round-21:** IRCTC autofill me food + "Book only if confirm berths are allotted" + "Consider for auto up-gradation" + mobile/email. Naya **V2 payload** (`railbookAutofillPayloadV2`); purani key + `postMessage` me exact **V1 shape** (purane app/extension safe).
- **Round-21b (latest):** catering ka **per-source sach** — `sources{erail,confirmtkt}`, `conflict`, `premiumCatering` (Rajdhani/Shatabda/Duronto/Vande Bharat/Tejas), `foodChoiceExpected`, `evidence[]`. Passenger form me **Food choice sirf saaf data par**; conflict par honest line, guess kabhi nahi. App panel batata hai jab IRCTC page par food option hi na ho.
- **Round-21c:** chat section se **Seat Finder card hata** diya (component `SeatFinder.tsx`, `seatfinder.ts` filters, `server/agent/seatFinderTool.ts` + `seatFilter.ts`, AI seat intent — **sab intact**, sirf chat render se gaya).
- **Round-22 (26 Sep):**
  1. **Seat-answer padhne layak** — `ReplyText.tsx` ab **em-dash (—)** aur "… departure" wale text ko rows me todta hai + upar ek honest summary line (`💺 2 me seat (102, 42) · fare ₹150–₹180`) — sirf usi text ke numbers se.
  2. **Filters direct card ke shuru me** — naya shared `src/components/SeatFilterBar.tsx` (✅ Available · 🚆 Sabhi trains · Sab class · class chips · ❄️ AC · Time · ⚡ Sabse jaldi · 💰 Sabse sasta); SeatFinder card + JourneyOptions dono wahi ek component use karte hain. Filter **sirf direct list** par (connecting/alternatives untouched); class filter par block me sirf wahi class chip; "Sabse sasta" filtered class ke fare par.
  3. **IRCTC overlay simple** — Android app me sirf **"Redirecting to IRCTC…" + 45s countdown** (pehle 30s + extra 30s phase tha — ab ek hi 45s, uske baad seedha continue).

- **Round-23 (26 Sep 2026):**
  1. **Available me sirf AVL/RAC** — `JourneyOptions.tsx` me ✅ Available mode par rows ab sirf AVL/RAC class chips dikhate hain; WL/N-A chips hidden, aur jis train me ek bhi AVL/RAC nahi wo list se hat jaati hai (jaise 11058 jaise trains WL-only gap wale). 🚆 Sabhi trains par sab kuch waise hi (saari classes, WL/N-A halki) — koi fake row nahi.
  2. **Review page ab sirf "Continue to IRCTC"** — `src/views/ReviewStatus.tsx` ke `FareReview` se booking summary, wallet box, "Nothing is confirmed…" note aur neeche ka sticky **Confirm Booking** hataye. `IrctcHandoff.tsx` se **Copy journey + passenger summary** button, copy-ready summary block aur payload preview hate. Continue click par journey+passenger summary **clipboard me best-effort copy** hoti hai (UI me nahi dikhti); honest note rehti hai — "Kuch bhi auto-submit nahi hota · login / OTP / CAPTCHA / payment RailBook ke paas nahi aate". RailBook ka apna booking flow (Passengers → IRCTC handoff jaisa) untouched.
  3. **App header ab asli version** — `MainActivity.appVersionLabel()` `versionName (versionCode)` dikhata hai (pehle `strings.xml` me hardcoded `v1.2.8` tha, isliye device par purana build chalne ka confusion hota tha). New debug ke liye: header padho → `v1.4.7 (30)` = latest.
  4. Tests: naya `tests/round23-avail-chips-and-review.test.tsx` (3) + `tests/irctc-handoff.test.tsx` update; full suite **102 files / 1021 PASS**.

- **Round-24 (26 Sep 2026):**
  1. **"Review fare" → "Review journey"** — `Passengers.tsx` ka CTA label + voice prompt line, aur `speakGuide.ts` ki bolne wali line.
  2. **Review page = journey summary + uske neeche sirf Continue to IRCTC** — `FareReview` me receipt wapas: **Train · Date · From → To · Class · Seat · Passengers · Base fare · Service fee · Total**, aur neeche har passenger ki detail (naam · umar · gender · berth · khaana · ID · checkbox) + **Mobile / Email / WhatsApp**. DOM order: summary pehle, button neeche. Uske elawa kuch nahi (wallet, Confirm Booking, copy summary, extra note — sab nahi). `IrctcHandoff` card ab sirf button hai (honest baat button ke `title` par, jaise "auto-submit nahi hota · login/OTP/CAPTCHA/payment RailBook ke paas nahi aate").
  3. **Passenger page khaali dikhne wala bug** — `passengers` list khaali mile to ab **apne aap ek blank card** ban jaata hai (pehle sirf background dikhta tha par "SAB READY" + enabled CTA the). Screen khulte hi scroller **top** par + `resize`/`visualViewport` (keyboard/IME) ke baad scroll **clamp** — isliye keyboard band hone ke baad blank hissa nahi dikhta. Purane WebView ke liye CSS fallback: `100vh` pehle phir `100dvh`, aur `inset:0` se pehle explicit `top/right/bottom/left:0`.
  4. **Tools:** `tools/probe-device-scroll.mjs` (live site ko phone-size Chromium me khol kar layout/scroll naapta hai; `playwright` dev-dependency) · `tools/probe-live-review.mjs` (deploy ke baad asli screenshots) · `tools/build-round24-preview.mjs` → `RailBook-round24-2026-09-26.html`.
  5. **Naya APK zaroori nahi** — is round me Android code change nahi (app WebView me live site load karta hai, wahi naya UI dikhega). App v1.4.7 hi current hai.

- **Round-25 (26 Sep 2026):** "baki trains Seat Finder card mein kyu le jaata?" →
  1. `seatFilter.seatSummaryLine()` ab saari seat rows likhti hai (12 tak; aage honest "+N aur bhi hain") — purana `(Seat Finder card me)` pointer hataya (wo card Round-21c me chat se hata tha, isliye jhootha tha).
  2. Naya `missingSeatLines()` + `server/app.ts` turn assembly: jo trains AI ke jawab me chhoot gayi, unki asli lines usi jawab me jud jaati hain (chat me rows ban kar dikhti hain). AI fail → wahi compact 💺 line (usme saari trains).
  3. Prompt + tool summary me saaf rule: saari trains likho, koi "card" pointer nahi. Client par `src/chatText.ts` `stripSeatCardPointer()` safety net (Concierge render se pehle).
  4. Tests: `tests/round25-seat-answer-all-trains.test.tsx` (7, turn-level sahit) · preview `RailBook-round25-2026-09-26.html` · builder `tools/build-round25-preview.mjs`. APK change nahi (WebView live).

- **Round-26 (26 Sep 2026):** "WL trains bhi dikhao" + "10 trains par 9 kyu" →
  1. **Count fix:** `ReplyText` label-match 40 → **140 akshar** — AI ne pehli train intro line me likhi ho to bhi wo row banti hai (10 trains = 10 rows). Summary line ab **total + seat/WL farq** batati hai (`💺 14 trains: 10 me seat (…) · 4 WL/N-A`).
  2. **Default me WL/N-A bhi:** `parseSeatIntent` me naya `EXPLICIT_AVAILABLE_WORDS` — `onlyAvailable` true sirf jab user khud *available / khali / vacant / confirmed* bole; warna saari trains (AVL/RAC + WL/N-A) status ke saath.
  3. `seatSummaryLine` all-mode branch (ek line me saari trains + "10 me seat (AVL/RAC), 8 me WL/N-A"), `seatFinderTool`/`autoTools`/`toolSpecs` me `only_available` default false, dono prompts me rule. `server/app.ts` me chhoot gayi rows AVL+WL dono se.
  4. Tests: `tests/round26-seat-all-classes.test.tsx` (7) + round-25 test update → **105 files / 1043 PASS** · preview `RailBook-round26-2026-09-26.html` · builder `tools/build-round26-preview.mjs`. APK change nahi.

- **Round-27 (26 Sep 2026):** "ek hi class dikha raha" + "baki trains live board par hai" + "class pe tap → sidha passenger form" + "mic working nahi hai" →
  1. **Per-train classes (server):** `seatFilter.ts` me `groupRowsByTrain()` / `trainClassesText()` — jawab/line me har train ki **saari** classes (`12013 AMRITSAR SHTABDI — CC AVL 444 ₹675 · 3A AVL 71 ₹520 · EC AVL 23 ₹1,015`), trains ke beech ` | `. `missingSeatLines()` bhi per-train. Cap ab **`capRowsByTrain()`** se **trains** par (pehle rows par tha — isi se same train ki EC/3E/2A block se kat rahi thi).
  2. **Chat ka tappable block (client):** naya `seatlist` block (`src/ai/orchestrate.ts` + `src/api.ts` + `Concierge.tsx` ka `SeatListBlock`) — train-wise `TrainClassBlock` groups, header `Seat wali trains (live board) · N trains · M me seat`, har class chip **tap → passenger form** (`openBookingFromSeatRow`). `chatText.seatListGroups()` + `stripDuplicatedSeatRows()` (text se duplicate row-lines hatati hain, prose bachi rehti hai); `ReplyText` me `AVL/AVAIL` rows + ek line ki saari classes alag-alag rows.
  3. **Native mic:** Android WebView me Web Speech API **nahi hota** — naya `VoiceBridge.kt` (SpeechRecognizer, hi-IN, `window.__railbookVoice.dispatch`) + `MainActivity` me `addJavascriptInterface(…, "RailBookVoice")` + manifest `<queries>`; client `src/voice/nativeSpeech.ts` + `speech.ts`/`useVoiceInput.ts` native-aware (native par `getUserMedia` call nahi).
  4. Tests: `tests/round27-seat-classes-and-mic.test.tsx` (12) + round-25 test format update → **106 files / 1055 PASS** · preview `RailBook-round27-2026-09-26.html` · builders `tools/build-round27-preview.mjs`, probe `tools/probe-live-r27.mjs`. **APK v1.4.8 (vc 31)** — native mic ke liye zaroori.

- **Round-39 (latest, 27 Sep 2026):** user (wahi demand R38 ke baad) — *"jaise chatgpt/gemini/claude/manus — koi bhi trains/Indian railway/booking/live status/stations sawaal (examples) par ek dum accurate answer/outcome do."* →
  1. **24-sawaal battery** (`tools/probe-r39-battery.mjs`) se weak jawab pakde: distance par **Expressway (sadak)**, pet/smoking/charging/AC-fail/2A-3A-fare par "data nahi", "sabse bada station" par Ernakulam ka page, "Konkan Railway" par Mangalore Central, aur **"Tum kya nahi kar sakte?" par AI ne booking flow shuru kar diya ("Kahan se jaana hai?")**.
  2. **Mode guard** (subject.ts): rail sawaal par road/air page reject; distance ka honest jawab (+journey time offer).
  3. **KB**: pet/dog · smoking · charging point · AC-fail refund (TDR 20h) · bachche ka ticket · 2A-3A fare order · sabse bada station (Howrah 23 platforms) · sabse lambi route (Vivek Express 4,154 km) · Konkan Railway (Roha→Thokur 741 km); RULES_TOPIC_RE me words → **KB web se pehle**.
  4. **Capability/meta sawaal ka fixed honest jawab** (run.ts, 0.3s) — 2 rok ke saath (IRCTC click nahi, passenger details nahi). **Client amenity replies** ab sach (charging/bedding/catering).
  5. Tests: naya `tests/round39-every-question-battery.test.ts` (11) → **118 files / 1286 ALL PASS** · live `f10d824` · **APK nahi**.
  6. **Workspace reset** (3rd time) — `/home/user/recover.sh` banaya (GitHub fetch + reset + npm ci + APK se bridge restore); reset par pehle wahi chalao.
- **Round-38 (27 Sep 2026):** user (R37 ke turant baad) — *"jaise chatgpt/gemini/claude/manus … koi bhi trains/India railway/Booking/live status/stations etc poochun to wo ek dum se accurate answer dete hai but mera AI kyu nhi — esko bhi waisa banao, user ke questions samjho aur ek dum perfect answer/outcome do."* →
  1. **Battery se naapa** (`tools/probe-r38-battery.mjs`, 18 sawaal): 18/18 jawab par **accuracy** me galat pages — "Ludhiana junction ke kitne platform" → **Raipur Haryana Junction** ka page (!), "Sleeper coach berth" → Vande Bharat ka page, "Rajdhani top speed" → galat service, "khana/chai" → raw English/"data nahi", "wheelchair" → adhoora toilet page.
  2. **Subject guard** (`server/agent/subject.ts`, naya): jawab ka page sawaal ke strong shabdon (station/train naam, number) se match hota hai — galat page skip, sab reject → saaf "sahi page nahi mila + jo sach me bata sakta hoon" (kuch bhi andaze se nahi). Web-rescue me bhi pehla subject-match.
  3. **KB facts** (`railkb.ts`): berth count (SL72/3A64/2A46/1A22/CC78/2S108/EC56) · Rajdhani 130 km/h · Vande Bharat 160/183 · onboard khana IRCTC · platform count honest · **divyangjan/wheelchair facility**; RULES_TOPIC_RE me ye words (pehle KB, phir web).
  4. **Live natija (`1136870`):** 18/18 direct · 18/18 Hinglish · **avg 33.1s → 23.5s**; R37 scenario dobara verify (form khula + loop nahi).
  5. Tests: naya `tests/round38-any-question-accuracy.test.ts` (12) + round15 update → **117 files / 1264 ALL PASS** · build `index-COu_oIzK.js` 487.5 kB · preview `RailBook-round38-2026-09-27.html` · **APK nahi**.
- **Round-37 (27 Sep 2026):** user screenshot — *"mainay 3 baar bola 12054 mein 2S book krdo … AI wahi reply dohra raha, form khula hi nahi … AI khd kyu nhi samjh ke sahi se outcome deta? mai kya har choti choti cheez check karun? jaise chatgpt/gemini/claude/manus — ek dum perfect answer/outcome do."* →
  1. **`resolveBookingTarget()` (naya, pure)** — train/class/route/date har verified source se (state → seat rows → picker tap → yaad rows → trains list → ctx → **user ke apne chat se**). Raw repro: picker turn ke baad ctx me origin/destination **null** the → client gate fail → kuch nahi hota tha.
  2. **Booking branch resolver par** + picker memory + "class na boli + 2+ khuli → class-choice card" (Round-35 behaviour naye shape me) + date-only par saaf date sawaal (class dobara nahi).
  3. **Form khula + wahi hukm dobara** → turant saaf line ("form pehle se khula hai… main passenger details nahi bharta") — server chakkar nahi, "main booking nahi kar sakta" nahi. `criticalBookingFlow` fix (booking hukm local raste me atak jaata tha → 3rd request hi nahi jaati thi).
  4. **Repeat-guard (server)** + prompt **rule 29 "JAWAB EK DAMM SEEDHA"** (wahi jawab dobara → corrective call; apna purana sawaal dobara nahi; knowledge par confident + verified).
  5. **General sawaal quality:** raw Wikipedia dump nahi — `polishWebReply`/`composeWebAnswer` se composed 2-4 line Hinglish; comparison ("Vande Bharat aur Rajdhani me kya fark hai") par **dono** topic pages + dono sources; railKB token-overlap matching (0.75+, 2+ token) se alag-shabdon wala sawaal bhi KB se.
  6. Live proof (`b738b8c`): T1 seat jawab · **T2 "12054 mein 2S book krdo" → form khul gaya (12054 · 2S · ASR → HW · 📅 2026-09-28)** · T3 dobara → "form pehle se khula hai" (loop khatam) · comparison → dono trains ka composed jawab.
  7. Tests: naya `tests/round37-booking-loop-and-repeat-guard.test.ts` (37) + round29/30/34/35 anchors → **117 files / 1251 ALL PASS** · build `index-B8_cbDTF.js` 487.5 kB · preview `RailBook-round37-2026-09-27.html` · probes `tools/probe-live-r37-live.mjs` + `tools/probe-r37-debug.mjs` · **APK nahi**.
- **Round-36 (26 Sep 2026):** user — *"agla kadam AI se aaye, wo khud ka dimag lagaye jaise ChatGPT/Gemini lagata hai, waisa hi next question poochhe aur soche kya poochna hai, fallback pe verified data se na aaye, AI har baar apna brain use kare"* →
  1. **Data-fallback poora band:** client ka `nextStepsFor` branch + import hata — "Agla kadam" card SIRF model ke validated `nextActions` se; model na de to card dikhta hi nahi (nakli next step nahi).
  2. **Main-loop repair ab 2 koshish** (pehli "apna dimaag lagao — jaise ChatGPT/Gemini", doosri sakht sirf-[NEXT]) — dono fail → `next_step_repair_empty_no_fallback`.
  3. **Dedicated chhota NEXT call (`nextStepFromModelOnly`)** — plan/seat turns 60-70s budget kha jaate hain to bhi model se hi agla kadam: compact prompt (user sawaal + jawab + verified tool data), provider-aware candidates (HF model apne endpoint par — pehle NVIDIA par 404 ho raha tha), fast model pehle, 12s timeout, evidence se validate.
  4. **Plan fast-path par bhi NEXT** ("Kal,1" ke plan par pehle card nahi aata tha).
  5. **Prompt:** Hinglish label/utterance; clarifying turns me bhi chip (model ne sawaal poochha ho to us sawaal ka sambhavit jawab).
  6. Live proof (`05622f4`, 6 turns): T2 "Kal,1" → card "Book 22478 · CC (AVL 2 ₹1830)" · T3 alternatives → "Book 22486 · 2S (AVL 504 ₹155)" · T4/T5/T6 → cards · **model 5 · data-fallback 0 · 1 turn (AI ka clarifying sawaal, data nahi) bina card**.
  7. Tests: naya `tests/round36-agla-kadam-sirf-ai-ke-dimaag-se.test.ts` (13) + round31/32/34/toolcalling updates → **115 files / 1214 ALL PASS** · build `index-k0C8DtSn.js` 482.5 kB · preview `RailBook-round36-2026-09-26.html` · probe `tools/probe-live-r36-live.mjs` · **APK nahi**.
  8. Render note: `clearCache:"clear"` ke saath deploy karo — `do_not_clear` par purana image serve hua tha (frontend stale).

- **Round-35 (26 Sep 2026):** user — *"maine bola vaishno devi se ludhiana ki seat availability btao … uske baad 19028 train mein multiple class mein seats available thi to maine bola '19028 mein book krdo' to AI ne yeh nahi poocha kon si class mein book karun … AI khud kyu nhi soch rha, har cheez thodi btani padegi"* →
  1. **Naya block `classchoice`:** booking hukm + class na boli + us train me 2+ class khuli (AVL/RAC) → form RUK jaata hai, card aata hai (`13042 … Kaunsi class me book karun?`) chips = sirf wo classes jo board par sach me khuli (`3A · AVAILABLE 29 · ₹520`); chip tap → seedha us class ka passenger form.
  2. **Ek hi class khuli ho** to seedha wahi (faltu sawaal nahi). **`pickRowForBooking` seat-wali class prefer** karta hai (WL se pehle).
  3. **Rule 28 (server):** class ambiguous par pehle SAAF poochho aur `[NEXT]` me class chips do — live me model ne khud bhi poochha ("Class confirm karo…").
  4. Tests: naya `tests/round35-ask-class-when-ambiguous.test.tsx` (15) → **114 files / 1200 ALL PASS** · server tsc clean · build `index-DcFTsEZG.js` 485.8 kB · preview `RailBook-round35-2026-09-26.html` · probe `tools/probe-live-r35-live.mjs` · **APK nahi**.
  5. Live proof (`b97b3c7`): "vaishno devi se ludhiana" seat board; **"Book 13042"** → form ruk gaya + class-choice card (3A ₹520 / 2A ₹725); chip tap → form 13042 · 3A · SVDK→LDH · 2026-09-28 · ₹520/pax.

- **Round-34 (26 Sep 2026):** user (2 screenshots) — *"12380 mein seats available hai and then I said book 12380 to eske pass seats to pehle hi hain to fir kyu dubara pooch rha… agla kadam na humesha AI hi chunne sabh sochke and suggestions bhi de user ko, agla kadam fallback pe verified data se mat aaye"* →
  1. **"Book <train>" bare hukm:** `isBookingIntent` me `book|booking|reserve` + 4-5 digit train number (bina `?`) — pehle sirf "book … krdo" regex tha, isliye seat list dikhne ke baad bhi message server gaya aur pax gate ne "kitne passengers?" poochh liya.
  2. **Seat rows yaad:** client `lastSeatRowsRef` (route+date ke saath) — booking hukm par form usi asli data se bharta hai (status/seats/fare/timing); route/date match na ho to purani rows use nahi.
  3. **NEXT-repair pass:** model ke jawab grounded ho + turn me ok tool data ho par `[NEXT]` missing → ek chhoti repair call model ko ("sirf 1-2 line [NEXT] …, isi turn ke data se") → chips model ke. Prompt rule 26 sakht: data ho to [NEXT] ZAROOR; data-fallback aakhri upay.
  4. **Local booking path sirf booking ki baaton ka:** `freshQuestionDuringBooking` — form khula hone par bhi naya sawaal (train number/seat/fare/time/status) model ke paas jaata hai; confirm/aage/back/details local.
  5. Tests: naya `tests/round34-book-known-seats-and-model-next.test.tsx` (16) + mock call-count update → **113 files / 1185 ALL PASS** · server tsc clean · build `index-BLb0w2Ig.js` 483.9 kB · preview `RailBook-round34-2026-09-26.html` · probe `tools/probe-live-r34-live.mjs` · **APK nahi**.
  6. Live proof (`a1aff0d`): "Book 12053" → seedha form (12053 · 2S · LDH→ASR · 2026-09-28 · 🕑 19:48 · ₹110/pax, paxAsk=false); form khula hone par bhi seat sawaal → model ka jawab; **NEXT tags: model 4 · data-fallback 0**.

- **Round-33 (26 Sep 2026):** user (3 screenshots) — *"AI ko jitne bhi tools available hai wo sabh provide kro (no restriction), bss AI continue to IRCTC pe click nhi karega na hi passenger details khud se fill krega, don't fake anything sab real and live data, first use confirm tkt, then rail yatri, then e rail on API fallback (fare, seat availability, timings, route, station codes, live status…)"* + "trains list krdi without fare and timings" + "alternative trains poocha, wahi list" + "'Kal,1' ke baad passengers dobara poochh liye" →
  1. **Tools ki azadi (rule 27):** saare tools khule, koi count-limit nahi (web search ka max-1 cap bhi gaya) — sirf 2 cheezein mana: "Continue to IRCTC" click aur passenger form khud bharna (booking deterministic, confirmBook hamesha false).
  2. **Sawaal ka matlab pehle (rule 28):** plan → RANK_JOURNEY_OPTIONS/JOURNEY_ANALYZE · alternative/doosri trains → FIND_ALTERNATIVE_TRAINS · trains batao → SEARCH_TRAINS · seat → seat tools; har list me timings + fare zaroor.
  3. **Provider order central:** naya `server/railway/webOrder.ts` — CONFIRMTKT → RAILYATRI → ERAIL, capability-wise chains (availability/fare/trains-between/schedule/station/live); router ki dono availability branches + withFareFilled + erailFareBreakdown + searchTrainsRouted ab isi chain se.
  4. **List me timings+fare:** naya `confirmTktTrainsBetween` (board → TrainResult, `boardRowsToTrainResults` pure+tested); `SEARCH_TRAINS` data me per-train fares; seat cards par `🕑 20:19 · 2h 46m` (seatFilter times hamesha).
  5. **'Kal,1' fix:** userStatedPax me pichhle pax-sawaal ke baad bare number pax (date/5-digit train number ke hisse pehle hataate); model ka samjha pax capture hokar ctx me yaad rehta hai; SEARCH_TRAINS ko pax ki zaroorat nahi.
  6. Tests: naya `tests/round33-tool-freedom-and-provider-order.test.ts` (26) + 4 purane update → **112 files / 1169 ALL PASS** · server tsc clean · build `index-C0QGbnrE.js` 483.0 kB · preview `RailBook-round33-2026-09-26.html` · probe `tools/probe-live-r33-live.mjs` (live all-pass) · **APK nahi**.
  7. Live proof (`a96ed83`): "Kal,1" → JOURNEY PLAN (1 passenger · 19 direct · 6 me seat · RECOMMENDED direct 22478); "Alternative trains" → 12484 3A AVL 110 ₹635 · 12716 3A AVL 47 ₹635 · 11058 3E AVL 29 ₹600 · 12926 1A AVL 1 ₹1,620; seat card par timings.

- **Round-32 (26 Sep 2026):** user correction — *"har query pehle model ke pass jaani chahiye and wo decide kare kon sa tool use karna yan kya karna hai, user ka answer kahan se laana hai"* → matlab **agla kadam bhi model chalaye**, data sirf validate/fallback (Round-31 ka data-derived framing user ne reject kiya). →
  1. **Model-first verify:** har query pehle se hi model ke paas jaati hai (client sirf 3 local exception) aur server par model tool chunta hai — deterministic routing sirf fallback, booking mutations deterministic, model ke paas booking tool nahi (`confirmBook` false).
  2. **Rule 26:** jawab ke aakhir me `[NEXT] <label> => <utterance>` (max 2, sirf isi turn ke tool data se, kuch verified na ho to koi line nahi). Server `extractNextActions()` unhe reply se alag karta hai + har action `groundingCheck(label+utterance)` se filter — ungrounded **drop**.
  3. **Client:** model ke chips pehle (tag **"AI ne chuna"**), na mile to data fallback (tag **"verified data se"**), kuch bhi verified na ho to **koi card nahi**.
  4. **Round-32b (live par pakda gaya):** model ke tool ka data (web_railyatri `CC AVL 334 ₹490`) aur screen ka board (web_confirmtkt `CC AVL 341 ₹675`) ek hi screen par takra rahe the → naya pure `reconcileNextActions(actions, boardRows)`: action model ka hi rehta hai, sirf takraate seat/fare numbers chip se hat jaate hain (train number kabhi nahi).
  5. Tests: naya `tests/round32-model-next-step.test.ts` (22) + round-31 update → **111 files / 1143 ALL PASS** · server tsc clean · build `index-CW1i71n2.js` 482.8 kB · preview `RailBook-round32-2026-09-26.html` · probes `tools/probe-live-r32.mjs` (local 6/6) + `tools/probe-live-r32-live.mjs` (live all-pass) · **APK nahi**.
  6. Live proof (`dc257a0`): asli model `nextActions=[Book 12013 · CC (AVL 334)]` → tag "AI ne chuna"; schedule turn → "verified data se" `12013 ki seat availability`; suvidha sawaal → koi card nahi.

- **Round-31 (26 Sep 2026):** "answer ke baad AI ko next step pe leke jaana chahiye… AI khud dimaag kyu nahi lagata?" →
  1. **"➡️ Agla kadam" card:** `src/ai/nextstep.ts` (naya pure helper `nextStepsFor`) + Concierge me har jawab ke neeche 1–2 tappable chips, **sirf usi turn ke verified data se** (seat rows/train list/journey plan) — Book (→ Round-29 auto passenger form), doosri classes, baaki trains, seat availability, ya doosri date. Kuch verified na ho → **koi chip nahi**.
  2. Model ke paas booking tool nahi (confirmBook false) — isliye agla kadam data se banta hai, andaze se nahi (fake screen/number ka risk zero).
  3. Tests: `tests/round31-next-step.test.tsx` (18) → **110 files / 1121** (1120 pass; 3 RailCore flaky alag pass) · preview `RailBook-round31-2026-09-26.html` · probes `tools/probe-live-r31*.mjs` · **APK nahi**.
  4. Live proof (`de97b12`): seat answer → `Book 12013 · CC (AVL 354 ₹675)` + `doosri classes (EC)`; tap → passenger form (12013 · CC · LDH → ASR · 2026-09-27).

- **Round-30 (26 Sep 2026):** "12013 ki seat availability btana … yeh question pe board kyu le aata, maine to maanga hi nahi" →
  1. **Focus scope:** `src/chatText.ts` ke naye pure helpers `trainNumbersInText()` (saal/tareekh/time ko train nahi samajhta) + `focusSeatRows()`; `Concierge.tsx` ka `seatlist` block ab message ke train number(s) par scoped — block sirf maangi hui train ka, header "Aapki maangi train (live board)". Generic sawaal par poora board pehle jaisa; maangi train list me na ho → block hi nahi.
  2. **Round-29 auto-advance** bhi wahi helper use karta hai (number extraction ek jagah).
  3. Tests: `tests/round30-focused-train-seat-block.test.tsx` (11) → **109 files / 1103 PASS** · preview `RailBook-round30-2026-09-26.html` · builder `tools/build-round30-preview.mjs` · probes `tools/probe-live-r30.mjs` (local) + `tools/probe-live-r30-live.mjs` (live) · **APK nahi** (koi Android change nahi).
  4. Live proof (`0b36c52`): 12013 → 1 card (focused, 2 chips) · generic → 20 trains/59 chips.

- **Round-29 (26 Sep 2026):** "same train ki classes alag alag cards me kyun" + "class pe tap" + "22432 mein 3A book krdo" + "vaishno devi" →
  1. **Ek train = ek card (chat):** `ReplyText.tsx` me `groupReplyRowsByTrain()` — trainNumber par grouping, header me number+naam ek baar, andar har class ki apni row (apna AVL/RAC/WL + fare), **order preserve**, exact duplicate record ek hi baar, input rows mutate nahi (sirf display view-model).
  2. **Class row tap → seedha passenger form:** `openBookingFromReplyRow()` → wahi `selectTrainAndClassGo()` (N/A/REGRET par button nahi).
  3. **"book krdo" → khud passenger form:** naya `src/booking/autobook.ts` (`isBookingIntent` · `pickRowForBooking` · `buildAutoBookSeat`) + Concierge gate; UNKNOWN status par bhi form (live check "Review journey" par), `booking/state.ts` UNKNOWN allow; `Passengers.tsx` honest fare/timings lines ("₹0" nahi).
  4. **Chhota station naam:** "vaishno devi" (+ 10 aur variants, Hindi bhi) → SVDK dono station maps me.
  5. Tests: `tests/round29-group-same-train-book.test.tsx` (22) + round-20/27 update → **108 files / 1091 PASS** · preview `RailBook-round29-2026-09-26.html` · builder `tools/build-round29-preview.mjs` · probes `tools/probe-live-r29.mjs` (local) + `tools/probe-live-r29-live.mjs` (live) · **APK nahi** (r29 me koi Android change nahi — v1.4.9 hi).

- **Round-28 (26 Sep 2026):** black handoff panel + blue header user ko nahi (backend me) · passenger dock fix · 45s → 30s + "details khud bhar jaayengi" →
  1. **Bridge panel hataya:** `railbook-webview-bridge.js` me `banner()` badal kar `postNotice()/pill()` — page par sirf **one-line pill** (6s me khud hide; STOP wale 12s), poori detail `fill-result` + `ui-notice` se native (status + log + Toast). Kuch chhupta nahi.
  2. **Android header chhupa:** `activity_main.xml` me `topBar` `visibility="gone"` — version/BHASHA/status/RAILBOOK-IRCTC-CLEAR screen par nahi, **code + listeners zinda**; user updates chhote Toast (`setStatus`) se.
  3. **Passenger dock fix:** `.overlay-screen` ab `fixed` + `100vh/100dvh` (pehle `.app` ke andar absolute — chat lambi hone par dock screen ke neeche chala jaata tha). Probe: CTA top 1336px → **836px (bina scroll)**. CTA label: details adhoori → "Review journey (pehle details bharo)".
  4. **30s + assurance:** `PREWARM_COUNTDOWN_MS = 30_000L`; prewarm overlay + passenger dock + Continue-to-IRCTC ke neeche line — "Aapki details IRCTC par khud bhar jaayengi, dobara daalne ki zaroorat nahi (login/OTP/payment aap karenge)". Browser me honest alag wording (`autoFillNotice`).
  5. Tests: `tests/round28-pax-dock-and-autofill-note.test.tsx` (15) → **107 files / 1070 PASS** · preview `RailBook-round28-2026-09-26.html` · builder `tools/build-round28-preview.mjs`, probes `tools/probe-live-r28.mjs` + `tools/probe-pax-dock.mjs`. **APK v1.4.9** (vc 32).

### Standing rules (inhe todna nahi)

1. **Kuch bhi fake nahi** — jo real provider/AI se aata hai wahi dikhta hai; data na aaye to honest line ("nahi aayi"), guess/placeholder nahi.
2. **Architecture touch nahi** — AI logic, tools/API calling, alternatives/connecting logic jaisa hai waisa rehta hai; UI changes UI tak.
3. **UI change = preview pehle** — preview hamesha **single source** (asli components + built CSS + real payload; `/home/user/RailBook/previews/`).
4. Seat Finder ke rules: har train ki **saari** classes ek saath (WL/N-A halki), count header se match, WL neeche / Available upar, Hindi/English/Hinglish.
5. Handoff/autofill contract: IRCTC ka login/OTP/CAPTCHA/payment **kabhi auto nahi**.

### Baselines (naye round me compare karne ke liye)

| cheez | value |
|---|---|
| vitest | **118 files / 1286 tests** (ALL PASS — Round-39 ke 11 naye) |
| server tsc | clean |
| client tsc | 67 errors (purane, baseline — koi naya nahi) |
| live commit | `f10d824` (Round-39) |
| preview | `RailBook-round38-2026-09-27.html` (Round-37/36/35 ke bhi previews/ me hain) |
| APK | v1.4.9 `RailBook-v1.4.9-release.apk` (versionCode 32) sha256 `4ea684c3…8e1ce` — Round-29 me koi Android change nahi (web fix; app live URL load karta hai) |

### Chhote gotchas

- Bash tool: `command` aur `cwd` **alag fields** me do (ek me poora nahi).
- Patch karne se pehle `grep -n` se current text lo; patch ke baad turant syntax check (`node -e "new vm.Script(...)"` JS ke liye).
- vitest background me `cwd=/home/user` se mat chalao — repo root se chalao.
- **UI change verify karna ho to:** `node tools/probe-live-review.mjs /home/user/RailBook/previews` (live site ko phone-size Chromium me khol kar screenshots + text deta hai).
- **App header = install proof:** "Redirecting to IRCTC…" ke saath **45s** + koi step line nahi dikhe to build current hai; 30s ya steps dikhe to purana APK — naya install karo (v1.4.7).
- Preview me external CSS/JS load nahi hota (sandboxed iframe) — sab inline rakho.
