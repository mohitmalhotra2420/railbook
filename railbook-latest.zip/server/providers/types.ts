export type ClassCode = "1A" | "2A" | "3A" | "3E" | "SL" | "CC" | "EC" | "2S" | "EA";

export type AvailabilityStatus =
  | "AVAILABLE"
  | "RAC"
  | "WAITLIST"
  | "NOT_AVAILABLE"
  | "UNKNOWN";

export type BookingStatus =
  | "DRAFT"
  | "PAYMENT_PENDING"
  | "BOOKING_PENDING"
  | "CONFIRMED"
  | "FAILED"
  | "CANCELLED";

export interface Station {
  code: string;
  name: string;
  city: string;
}

export interface ClassAvailability {
  code: ClassCode;
  /** 23 Sep 2026: UI rows `classCode` maangti hain (agent mapping ki shape) — route
   * board/live-fill rows me dono field rakhte hain taaki koi consumer "undefined" na dekhe. */
  classCode?: ClassCode;
  label: string;
  status: AvailabilityStatus;
  seats?: number;
  rac?: number;
  waitlist?: number;
  fare: number;
  quota?: string;
  date?: string;
  /** Asked segment ka data RailCore ne nahi diya (NOT_FOUND) — ye row train
   * ke first/last stop (endpoints) ki availability hai, labeled dikhna hai. */
  segmentNote?: string;
  /** Round-7: fare API-fail par erail.in scrape se aaya (status UNKNOWN,
   * fare-only). Round-16: "web_railyatri" = seats+status RailYatri SA
   * (IRCTC-sourced, cached) se — `webNote` mein last-updated. */
  source?: "web_erail" | "web_railyatri" | "web_confirmtkt" | "web_wikipedia" | "railradar" | "indianrailapi";
  /** Honest note jo UI dikhata hai — jaise "Train Cancelled" (ConfirmTkt board). */
  note?: string;
  /** Round-18g: fare ka alag source jab seats kisi aur provider se aaye (provenance mix nahi). */
  /* Round-33: fare ka web chain CONFIRMTKT → RAILYATRI → ERAIL (webOrder.ts) — dono naye
   * sources bhi honest label ke saath aa sakte hain. */
  fareSource?: "web_confirmtkt" | "web_railyatri" | "web_erail" | "railradar" | "indianrailapi";
  webNote?: string;
  /** Round-18m: web cache SA_MAX_AGE (24h) se purani — "last known", ⚠ stale. */
  stale?: boolean;
  /** Round-18m-26: provider ne ye row kab update ki (ISO) — UI "X din pehle ka data" dikhata hai. */
  updatedAt?: string;
}

export interface TrainResult {
  number: string;
  name: string;
  type: string;
  from: Station;
  to: Station;
  date: string;
  departure: string;
  arrival: string;
  arrivalDayOffset: number;
  durationMinutes: number;
  durationLabel: string;
  runsOn: number[];
  classes: ClassAvailability[];
  /** Round-16m: false = timetable se halt verify nahi ho paaya (provider
   * rate-limit), train provider ke route-result se hai. undefined/true = ok. */
  haltVerified?: boolean;
}

export interface SearchQuery {
  from: string;
  to: string;
  date: string;
}

export interface FareBreakdown {
  trainNumber: string;
  date: string;
  classCode: ClassCode;
  passengerCount: number;
  baseFare: number;
  serviceFee: number;
  total: number;
  currency: "INR";
  /** False when RailKit fareLookup did not return a real railway fare. */
  railwayAvailable?: boolean;
  /** Fare kyun nahi mila (endpoint band / quota khatam) — honest user message. */
  unavailableReason?: string;
  /** Round-7: erail.in web-scrape se aaya (API-fail fallback). */
  source?: "web_erail" | "web_railyatri" | "railradar" | "indianrailapi";
}

export interface PassengerInput {
  name: string;
  age: number;
  gender: "MALE" | "FEMALE" | "OTHER";
  berthPreference: string;
}

export interface CreateBookingRequest {
  trainNumber: string;
  date: string;
  from: string;
  to: string;
  classCode: ClassCode;
  seatPreference: string;
  passengers: PassengerInput[];
}

export interface BookingRecord {
  id: string;
  pnr: string | null;
  mock: boolean;
  status: BookingStatus;
  trainNumber: string;
  trainName: string;
  date: string;
  from: Station;
  to: Station;
  departure: string;
  arrival: string;
  classCode: ClassCode;
  seatPreference: string;
  passengers: PassengerInput[];
  fare: FareBreakdown;
  createdAt: string;
  confirmedAt: string | null;
  failureReason: string | null;
}

export interface CancelResult {
  bookingId: string;
  status: "CANCELLED";
  refundAmount: number;
}

export interface RailwayProvider {
  readonly id: string;
  readonly displayName: string;
  readonly mock: boolean;
  searchTrains(query: SearchQuery): Promise<TrainResult[]>;
  getAvailability(
    trainNumber: string,
    date: string,
    from: string,
    to: string,
    classCode: ClassCode,
    quotaCode?: string,
  ): Promise<ClassAvailability>;
  getFare(
    trainNumber: string,
    date: string,
    from: string,
    to: string,
    classCode: ClassCode,
    passengerCount: number,
  ): Promise<FareBreakdown>;
  createBooking(req: CreateBookingRequest): Promise<BookingRecord>;
  confirmBooking(bookingId: string): Promise<BookingRecord>;
  getBooking(idOrPnr: string): Promise<BookingRecord | null>;
  listBookings(): Promise<BookingRecord[]>;
  cancelBooking(bookingId: string): Promise<CancelResult>;
}

export const CLASS_LABELS: Record<ClassCode, string> = {
  "1A": "AC First Class",
  "2A": "AC 2 Tier",
  "3A": "AC 3 Tier",
  "3E": "AC 3 Economy",
  SL: "Sleeper",
  CC: "AC Chair Car",
  EC: "Executive Chair Car",
  "2S": "Second Sitting",
  EA: "Anubhuti Class",
};

export const BERTH_OPTIONS: Record<ClassCode, string[]> = {
  "1A": ["Cabin", "Coupe", "Lower", "Upper"],
  "2A": ["Lower", "Upper", "Side Lower", "Side Upper"],
  "3A": ["Lower", "Middle", "Upper", "Side Lower", "Side Upper"],
  "3E": ["Lower", "Middle", "Upper", "Side Lower", "Side Upper"],
  SL: ["Lower", "Middle", "Upper", "Side Lower", "Side Upper"],
  CC: ["Window", "Aisle"],
  EC: ["Window", "Aisle"],
  "2S": ["Window", "Aisle"],
  EA: ["Window", "Aisle"],
};

export function isBookable(status: AvailabilityStatus): boolean {
  return status === "AVAILABLE" || status === "RAC" || status === "WAITLIST";
}
