/* Seat-intent samajhna — SERVER side (24 Sep 2026).
 *
 * User: "yeh jo seat intent questions hain AI khud samjhe and filter kare, jaisa tum plan kar rahe the;
 *        jo client side jo tumne build kara hai wo fallback me use karo. Baaki AI ka search karne ka
 *        way, tools calling ka way, API calling ka way, alternatives/connecting journeys ka logic
 *        mat change karna."
 *
 * Ye module SIRF bhasha padhta hai (Hindi / Devanagari / English / Hinglish) — koi provider call nahi,
 * koi LLM call nahi, koi tool/API change nahi. Client ke `src/seatfinder.ts` ke wahi 14 patterns ka
 * server mirror hai, taaki har surface (app, API caller, voice) ek hi vocabulary samjhe.
 *
 * Flag: SEAT_FILTER_SERVER (default ON). Off karo to ye layer sirf log hoti hai, behaviour aaj jaisa.
 */

export type SeatSortBy = "fastest" | "cheapest";

export interface SeatIntentSlots {
  /** User seat/availability ke baare me poochh raha hai? */
  seatIntent: boolean;
  /** Kis class ki baat ho rahi hai (khaali array = "sab class" / koi filter nahi). */
  classCodes: string[];
  /** "AC trains / AC class" (koi ek class nahi batayi) → AC group. 24 Sep 2026 user:
   * "AC trains dikhao" par 2S/SL bhi dikh rahe the — AC bola to sirf AC classes. */
  classGroup: "AC" | null;
  /** "seat wali" = AVAILABLE + RAC (dono me seat pakki hone ke kareeb). */
  onlyAvailable: boolean;
  /** "sirf confirmed" — aaj onlyAvailable jaisa hi treat hota hai. */
  confirmedOnly: boolean;
  /** "sabse jaldi" / "sabse sasta". */
  sortBy: SeatSortBy | null;
  /** "5 baje ke baad" → minute-of-day (17:00 = 1020). */
  departAfterMinute: number | null;
  /** Round-19 (24 Sep 2026, user screenshot: "kal subha ki trains btao" par poori din ki list
   *  aa gayi): "subah / dopahar / shaam / raat" jaisa TIME WINDOW → upper bound (minute-of-day).
   *  "raat" me ye lower bound se chhota hota hai (21:00 → 04:00 wrap). */
  departBeforeMinute: number | null;
  /** Window ka insaani label (jawab me dikhta hai) — jaise "Subah (12 baje se pehle)". */
  windowLabel: string | null;
  /** TQ (tatkal) / PT (premium tatkal) / LD (ladies) — GN default. */
  quota: string | null;
  /** Kin shabdon se samjha (diagnostics; koi PII nahi). */
  matched: string[];
}

/* ── class: Devanagari numerals, Hindi shabd, Hinglish, English ────────────── */
const CLASS_RULES: [RegExp, string][] = [
  [/\b1a\b|\b1ac\b|\b1\s*ac\b|first\s*(?:ac|class)|(?:१|1)\s*(?:ए|एसी)|पहली\s*(?:एसी|श्रेणी)/i, "1A"],
  [/\b2a\b|\b2ac\b|\b2\s*ac\b|second\s*ac|second\s*class|2nd\s*ac|(?:२|2)\s*(?:ए|एसी)|दूसरी\s*(?:एसी|श्रेणी)/i, "2A"],
  [/\b3e\b|3\s*economy|third\s*economy|(?:३|3)\s*economy/i, "3E"],
  [/\b3a\b|\b3ac\b|\b3\s*ac\b|third\s*(?:ac|class)|3rd\s*ac|(?:३|3)\s*(?:ए|एसी)|तीसरी\s*(?:एसी|श्रेणी)/i, "3A"],
  [/sleeper|\bsl\b|स्लीपर|शयनयान/i, "SL"],
  [/executive|\bec\b|एग्ज़ीक्यूटिव|एग्जीक्यूटिव/i, "EC"],
  [/chair\s*car|\bcc\b|चेयर\s*कार/i, "CC"],
  [/\b2s\b|second\s*sitting|sitting\s*class|सेकंड\s*सिटिंग/i, "2S"],
];
/* "sab class / koi bhi class / paise ka farq nahi" → koi class filter nahi. */
const NO_CLASS = /sab\s*class|sabhi\s*(?:class|क्लास)|koi\s*bhi\s*class|किसी\s*भी\s*(?:class|क्लास)|any\s*class|all\s*class/i;
/* "AC trains / AC class / AC wali" — koi ek class nahi, poora AC group (24 Sep 2026). */
const AC_GROUP = /\b(?:ac|एसी|ए\.सी\.|air\s*condition(?:ed|ing)?|वातानुकूलित)\b/i;
/** AC group ki classes — 2S/SL iske bahar (wahi user ki shikayat thi). */
export const AC_CLASSES = ["1A", "2A", "3A", "3E", "CC", "EC"] as const;

const SEAT_WORDS =
  /\b(seat|seats|berth|berths|available|availability|avl|vacant|khali|khaali|jagah)\b|सीट|बर्थ|जगह|खाली|उपलब्ध/iu;
const QUESTION_WORDS = /(hai|hain|है|हैं|क्या|kaun|which|konsi|konsi\s*si|dikha|दिखा|batao|बताओ|chahiye|चाहिए)/iu;
/* Round-26 (26 Sep, user: "SL ho ya koi bhi class, usmein sirf available mat show karo — W/L trains
 * bhi show karo, kyunki user ne specifically nahi bola ki available dikhao"): "available" wale shabd
 * tabhi maane jaate hain jab user ne SAAF maanga ho. Warna default = saari trains (AVL/RAC + WL/N-A). */
const EXPLICIT_AVAILABLE_WORDS =
  /\b(available|availability|avl|vacant|khali|khaali)\b|उपलब्ध|खाली|उपलब्धता/iu;

const CONFIRMED_WORDS =
  /(confirmed|कन्फर्म|confirm|pakki|पक्की|सीट\s*वाली|seat\s*wali|जो\s*पक्की)/i;
const FASTEST_WORDS =
  /sabse\s*(?:jaldi|fast|tez|तेज़)|fastest|kam\s*time|jaldi\s*pahunch|सबसे\s*(?:जल्दी|तेज़)|कम\s*समय/iu;
const CHEAPEST_WORDS =
  /sabse\s*sast|low\s*fare|cheapest|kam\s*kiraya|budget|सस्त|कम\s*किराया/iu;

function classFrom(text: string): string[] {
  if (NO_CLASS.test(text)) return [];
  const out: string[] = [];
  for (const [re, code] of CLASS_RULES) {
    if (re.test(text) && !out.includes(code)) out.push(code);
  }
  return out;
}

/** "AC trains" (koi specific class nahi) → AC group. Specific class boli ho to wahi chalti hai. */
function classGroupFrom(text: string, classCodes: string[]): "AC" | null {
  if (classCodes.length) return null; /* "2A AC" = user ne class bata di */
  return AC_GROUP.test(text) ? "AC" : null;
}

function pmOf(text: string): -1 | 0 | 1 {
  /* -1 = subah (am hi rahega), 1 = shaam/raat (pm banao), 0 = koi hint nahi */
  if (/सुबह|subah|morning|सवेरे/i.test(text)) return -1;
  if (/रात|raat|night|शाम|shaam|sham|evening|दोपहर|dopahar|afternoon/i.test(text)) return 1;
  return 0;
}

/** "5 baje ke baad" → 17:00 (shaam), "after 5" → 05:00 (literal), "17:30 ke baad" → 17:30. */
export function departAfterMinute(text: string): number | null {
  const t = String(text ?? "");
  const hm =
    /(\d{1,2}):(\d{2})\s*(?:ke\s*baad|के\s*बाद|baad|after)/i.exec(t) ||
    /(?:after|baad|बाद)\s*(\d{1,2}):(\d{2})/i.exec(t);
  if (hm) {
    const h = Number(hm[1]);
    const m = Number(hm[2]);
    if (h <= 23 && m <= 59) return h * 60 + m;
  }
  /* "रात 9 के बाद" / "शाम 5 के बाद" / "सुबह 6 के बाद" — baje shabd ke bina bhi. */
  const pref =
    /(?:सुबह|शाम|रात|दोपहर|सवेरे|subah|shaam|sham|raat|dopahar|morning|evening|night|afternoon)\s*(\d{1,2})\s*(?:ke\s*baad|के\s*बाद|baad)/i.exec(t);
  if (pref) {
    const raw = Number(pref[1]);
    if (raw > 23) return null;
    const pm = pmOf(t);
    const h = pm === -1 ? raw : pm === 1 ? (raw % 12) + 12 : raw <= 7 ? raw + 12 : raw;
    return (h % 24) * 60;
  }
  const baje = /(\d{1,2})\s*(?:baje|बजे|bje)\s*(?:ke\s*baad|के\s*बाद|baad)/i.exec(t);
  if (baje) {
    const raw = Number(baje[1]);
    if (raw > 23) return null;
    const pm = pmOf(t);
    const h = pm === -1 ? raw : pm === 1 ? (raw % 12) + 12 : raw <= 7 ? raw + 12 : raw;
    return (h % 24) * 60;
  }
  const en = /(?:after|baad\s*se)\s*(\d{1,2})\b/i.exec(t);
  if (en) {
    const raw = Number(en[1]);
    if (raw <= 23) return raw * 60;
  }
  return null;
}

/** Round-19: "subah / dopahar / shaam / raat" (bina ghadi ke) → poora time WINDOW.
 *  User (screenshot): "Mujhe kal subha ki trains btana amritsar se ludhiana ki" → poora din ki list
 *  aa gayi (16:50, 18:55 bhi). Ab ye window ban jaata hai aur usi par filter lagta hai.
 *  Sab kuch bhasha-padhna hi hai — koi provider/tool/API call nahi. */
export const TIME_WINDOWS: { re: RegExp; after: number; before: number; label: string }[] = [
  { re: /(सुबह|सवेरे|सुभ|subah|subha|savere|saverey|early\s*morning|\bmorning\b)/i, after: 240, before: 720, label: "Subah (04:00–12:00)" },
  { re: /(दोपहर|dopahar|afternoon)/i, after: 720, before: 1020, label: "Dopahar (12:00–17:00)" },
  { re: /(शाम|shaam|sham|evening)/i, after: 1020, before: 1260, label: "Shaam (17:00–21:00)" },
  { re: /(रात|raat|night)/i, after: 1260, before: 240, label: "Raat (21:00 ke baad)" },
];

/** minute-of-day → "HH:MM" (window labels me dikhta hai). */
const clockLabel = (m: number): string =>
  `${String(Math.floor(m / 60)).padStart(2, "0")}:${String(m % 60).padStart(2, "0")}`;

/** "12 baje se pehle" / "before 8" / "8 baje se pahle" → us se pehle ka time (minute-of-day). */
export function beforeMinute(text: string): number | null {
  const t = String(text ?? "");
  const m =
    /(\d{1,2})(?::(\d{2}))?\s*(?:baje\s*)?(?:se\s*)?(?:pehle|pahle|पहले|before)/i.exec(t) ||
    /(?:before|पहले)\s*(\d{1,2})(?::(\d{2}))?/i.exec(t);
  if (!m) return null;
  const raw = Number(m[1]);
  if (raw > 23) return null;
  const mm = Number(m[2] ?? 0);
  if (mm > 59) return null;
  const pm = pmOf(t);
  const h = pm === -1 ? raw : pm === 1 ? (raw % 12) + 12 : raw;
  return (h % 24) * 60 + mm;
}

/** Sirf shabd wala window ("subah ki trains", "shaam ki gaadi") — ghadi boli ho to null. */
export function timeWindowWords(text: string): { after: number; before: number; label: string } | null {
  const t = String(text ?? "");
  /* Ghadi ka zikr ho ("9 baje ke baad", "17:00") to wahi parser jeetta hai. LEKIN sirf koi bhi digit
   * dekh kar window chhod dena bug tha (live, 24 Sep): "kal subha 2A me seat batao" / "1 passenger
   * subah" jaise sawaal me — class/train/passenger ke digits ki wajah se — subah ka window gum ho
   * jaata tha aur poori din ki list aa jaati thi. Ab sirf asli CLOCK reading window ko rokta hai. */
  if (/\d{1,2}\s*:\s*\d{2}|\d{1,2}\s*(?:baje|बजे|bje|o'?clock)/i.test(t)) return null;
  for (const w of TIME_WINDOWS) if (w.re.test(t)) return { after: w.after, before: w.before, label: w.label };
  return null;
}

export function parseSeatIntent(rawText: string): SeatIntentSlots {
  const text = String(rawText ?? "");
  const explicitClasses = classFrom(text);
  const classGroup = classGroupFrom(text, explicitClasses);
  /* AC group boli gayi to filter AC classes ka hai (1A/2A/3A/3E/CC/EC) — 2S/SL nahi. */
  const classCodes = classGroup === "AC" ? [...AC_CLASSES] : explicitClasses;
  const matched: string[] = [];
  const seatWord = SEAT_WORDS.test(text);
  const hasQuestion = QUESTION_WORDS.test(text);
  const confirmedOnly = CONFIRMED_WORDS.test(text);
  /* Sirf tab available-only filter, jab user ne available/khali/confirmed saaf maanga ho. */
  const askedAvailableOnly = EXPLICIT_AVAILABLE_WORDS.test(text) || confirmedOnly;
  const earliest = FASTEST_WORDS.test(text);
  const cheapest = CHEAPEST_WORDS.test(text);
  const explicitAfter = departAfterMinute(text);
  /* Round-19: time window — "subah ki trains" jaisa sawaal. Ghadi boli ho ("9 baje ke baad") to
   * wahi jeetta hai; warna shabd wala window (subah/dopahar/shaam/raat) aur "X se pehle".
   * Dono ho ("subah 8 se pehle") to neeche ka bound "8 se pehle" hi lagta hai (jhooth nahi). */
  const windowWord = explicitAfter == null ? timeWindowWords(text) : null;
  const beforeValue = beforeMinute(text);
  const departedLabel = explicitAfter != null ? `${clockLabel(explicitAfter)} ke baad` : null;
  const departAfterMinuteValue = windowWord ? windowWord.after : explicitAfter;
  const departBeforeMinuteValue = windowWord ? (beforeValue ?? windowWord.before) : beforeValue;
  const windowLabel =
    explicitAfter != null
      ? departedLabel
      : windowWord
        ? beforeValue != null && beforeValue !== windowWord.before
          ? `${windowWord.label.split(" (")[0]} (${clockLabel(windowWord.after)}–${clockLabel(beforeValue)})`
          : windowWord.label
        : beforeValue != null
          ? `${clockLabel(beforeValue)} se pehle`
          : null;
  const quota = /premium\s*tatkal|प्रीमियम\s*तत्काल/i.test(text)
    ? "PT"
    : /tatkal|तत्काल/i.test(text)
      ? "TQ"
      : /ladies|महिला/i.test(text)
        ? "LD"
        : null;

  if (seatWord) matched.push("seat-word");
  if (classGroup) matched.push(`group:${classGroup}`);
  if (explicitClasses.length) matched.push(`class:${explicitClasses.join("+")}`);
  if (confirmedOnly) matched.push("confirmed");
  if (askedAvailableOnly) matched.push("available-only");
  if (earliest) matched.push("sort:fastest");
  if (cheapest) matched.push("sort:cheapest");
  if (departAfterMinuteValue != null) matched.push(`after:${departAfterMinuteValue}`);
  if (departBeforeMinuteValue != null) matched.push(`before:${departBeforeMinuteValue}`);
  if (windowLabel) matched.push(`window:${windowLabel}`);
  if (quota) matched.push(`quota:${quota}`);

  /* Seat intent = seat ka zikr, ya AC group, ya class + sawaal ("2A hai?"), ya sirf-confirmed / sort
   * maanga gaya. Round-19: time window ("kal subah ki trains") + trains/sawaal bhi seat intent hai —
   * tabhi us window ka live seat jawab upar dikhta hai (warna poori din ki list aati thi). */
  const asksTrains = /(train|trains|गाड़ी|गाडी|ट्रेन|gaadi|gadi|गाड़ियां|express|exp\b|mail)/i.test(text);
  const seatIntent =
    seatWord ||
    confirmedOnly ||
    classGroup != null ||
    (explicitClasses.length > 0 && hasQuestion) ||
    (windowLabel != null && (asksTrains || hasQuestion));

  return {
    seatIntent,
    classCodes,
    classGroup,
    /* Round-26: default me WL/N-A bhi (user ne specifically available nahi maanga). */
    onlyAvailable: askedAvailableOnly,
    confirmedOnly,
    sortBy: cheapest ? "cheapest" : earliest ? "fastest" : null,
    departAfterMinute: departAfterMinuteValue,
    departBeforeMinute: departBeforeMinuteValue,
    windowLabel,
    quota,
    matched,
  };
}
