import type { Station, TrainResult } from "../providers/types.js";
import type { ServedProvider } from "../railway/router.js";
import { aiPhraseGate, type ChoiceBlock } from "./agentic.js";
import { runUnderstand } from "../understand/index.js";
import { generalRailwayAnswer } from "../understand/llm.js";
import { understand as deterministicUnderstand, type DialogSlot, type KnownSlots, type NluResult } from "../understand/legacy-nlu.js";
import {
  GENERAL_FACT_RE,
  CONCEPT_QUESTION_RE,
  TRAIN_NAME_SUFFIX_RE,
  TRAIN_TYPE_KEYWORD_RE,
  bookingInProgress,
  classifyFollowUp,
  isQuestionPhraseNotTrainName,
  matchTrainNameInList,
  mentionsTrainName,
  trainNamePhrase,
  decideTool,
  emptyAgentContext,
  factReplyUnavailable,
  mergeAgentContext,
  neverAutoBook,
  resolveTrainNumber,
  type AgentContext,
  type AgentToolName,
} from "./context.js";
import { executeTool, livePositionLabel, type ToolName } from "./tools.js";
import { checkStationsOnRoute, normalizeRouteSegment } from "./routeCheck.js";
import { parseStatusDate } from "../understand/legacy-dates.js";
import {
  agenticConfigured,
  asksSingleTrainAvailability,
  ensureBookingOffer,
  executeApprovedTool,
  runAgenticTurn,
  webRescueEligible,
  type AgentTrainRow,
  type AgentTrainTable,
  type AgenticHistoryTurn,
  type SearchCapture,
  type ToolTraceStep,
} from "./agentic.js";
import { routedClassBoard, routedLiveDates, routedLiveStatus, routedSchedule, routedStationSearch, routedTrainInfo, searchTrainsRouted } from "../railway/router.js";
import { pickTrains, type TrainPickerResult } from "../journey/trainpicker.js";
import { planJourney } from "../journey/engine.js";
import type { JourneyPlan } from "../journey/types.js";
import { webSourceLabel } from "../railway/webscrape.js";
import {findWikipediaPage, webSearch, generalWebSearch, scrapeWebPage } from "./websearch.js";
import { railKbAnswer } from "./railkb.js";
import { runFindSeatsTool } from "./seatFinderTool.js";
import { isPickFollowup, previousListTrains } from "./seatPick.js";
import type { SeatFilterRow } from "./seatFilter.js";
type SeatRowLike = SeatFilterRow;
import { wikiTableForPage } from "./websearch.js";

/** Atlas analyse intents — decideTool inhe map nahi karta (model ki zimmedari hai),
 *  par agentic engine fail ho to deterministic fallback bhi inka honest answer deta hai. */
const ATLAS_PREF: Record<string, "fastest" | "cheapest" | "best"> = {
  SELECT_FASTEST: "fastest",
  SELECT_CHEAPEST: "cheapest",
  SELECT_BEST: "best",
  /* 2026-09-06: "12014 vs 12054 kon si better" — deterministic compare
   * (atlasFallback ke andar compareTrainsDeterministic). */
  COMPARE_TRAINS: "best",
};

/**
 * Deterministic Atlas fallback — SELECT_FASTEST / SELECT_CHEAPEST / SELECT_BEST.
 * Contract wahi: ya REAL provider evidence se grounded answer, ya honest
 * clarification (ambiguous city / missing slot). Kabhi guess nahi, kabhi
 * empty reply nahi (pehle yeh intents fallback mein chup ho jaate the).
 */
/* ── Deterministic train compare (2026-09-06): "12014 and 12054 mein se kon
 * si better hai" — dono ka REAL timetable lekar honest comparison. Ek ka data
 * na mile to doosre ka data + saaf batana kaunsa nahi mila (poora cancel nahi). */
async function compareTrainsDeterministic(numbers: string[]): Promise<{
  reply: string;
  ok: boolean;
  trace: ToolTraceStep;
}> {
  const uniq = numbers.filter((v, i, a) => a.indexOf(v) === i).slice(0, 3);
  const rows: {
    num: string;
    name: string;
    stops: { code: string; name: string; arrival?: string | null; departure?: string | null }[];
    durationMinutes: number | null;
    classes: string[];
  }[] = [];
  const missing: string[] = [];
  for (const num of uniq) {
    const sched = await routedSchedule(num);
    const schedule = sched.schedule;
    if (!schedule || !("stops" in schedule) || !schedule.stops?.length) {
      missing.push(num);
      continue;
    }
    const stops = schedule.stops;
    const first = stops[0];
    const last = stops[stops.length - 1];
    const dep = first?.departure ?? first?.arrival ?? null;
    const arr = last?.arrival ?? last?.departure ?? null;
    let dur: number | null = "durationMinutes" in schedule && typeof schedule.durationMinutes === "number" ? schedule.durationMinutes : null;
    if (dur == null && dep && arr) {
      const toMin = (x: string) => {
        const m = x.match(/(\d{1,2}):(\d{2})/);
        return m ? Number(m[1]) * 60 + Number(m[2]) : null;
      };
      const a = toMin(dep);
      const b = toMin(arr);
      if (a != null && b != null) dur = b >= a ? b - a : b + 1440 - a;
    }
    rows.push({
      num,
      name: "trainName" in schedule ? String(schedule.trainName || num) : num,
      stops,
      durationMinutes: dur,
      classes: "classes" in schedule ? (schedule.classes ?? []).filter((c) => c && c !== "UNKNOWN") : [],
    });
  }
  const trace = (ok: boolean, summary: string): ToolTraceStep => ({
    step: 1,
    tool: "getTimetable",
    args: { compare: uniq.join(","), trains: rows.map((r) => r.num) },
    ok,
    source: "railcore",
    summary,
    latencyMs: 0,
  });
  if (!rows.length) {
    return {
      reply: `${uniq.join(", ")} — kisi ki bhi timetable nahi mil paayi. Main guess nahi karunga.`,
      ok: false,
      trace: trace(false, "compare: timetables unavailable"),
    };
  }
  const line = (r: (typeof rows)[number]) => {
    const first = r.stops[0];
    const last = r.stops[r.stops.length - 1];
    const dep = first?.departure ?? first?.arrival ?? "??:??";
    const arr = last?.arrival ?? last?.departure ?? "??:??";
    const durLabel =
      r.durationMinutes != null
        ? `${Math.floor(r.durationMinutes / 60)}h ${String(r.durationMinutes % 60).padStart(2, "0")}m`
        : "duration nahi pata";
    return `${r.num} ${r.name} — ${r.stops.length} stops, ${first?.code ?? "?"} ${dep} → ${last?.code ?? "?"} ${arr} (${durLabel})${r.classes.length ? `, classes ${r.classes.join("/")}` : ""}`;
  };
  let reply: string;
  if (rows.length >= 2) {
    const [a, b] = rows;
    const routeNote =
      a.stops[a.stops.length - 1]?.code !== b.stops[b.stops.length - 1]?.code
        ? ` Dhyan: route alag hai — ${a.num} ${a.stops[a.stops.length - 1]?.code} tak, ${b.num} ${b.stops[b.stops.length - 1]?.code} tak.`
        : "";
    let verdict = "Dono ka data upar hai; apni zaroorat (time/class/stops) ke hisaab se chuno.";
    if (a.durationMinutes != null && b.durationMinutes != null && a.durationMinutes !== b.durationMinutes) {
      const faster = a.durationMinutes < b.durationMinutes ? a : b;
      const slower = faster === a ? b : a;
      verdict = `Time mein ${faster.num} better hai (${Math.abs(a.durationMinutes - b.durationMinutes)} min kam)${a.stops.length !== b.stops.length ? `, ${faster.stops.length} stops vs ${slower.num} ki ${slower.stops.length}` : ""}.`;
    } else if (a.stops.length !== b.stops.length) {
      const fewer = a.stops.length < b.stops.length ? a : b;
      verdict = `Kam stops wali ${fewer.num} hai (${fewer.stops.length} stops).`;
    }
    reply = `${rows.map(line).join("\n")}${routeNote ? "\n" + routeNote.trim() : ""}\n${verdict}`;
  } else {
    reply = `${line(rows[0])}${missing.length ? `\n${missing.join(", ")} ki timetable nahi mil paayi — jo mila wo upar hai.` : ""}`;
  }
  return {
    reply,
    ok: true,
    trace: trace(true, `compare: ${rows.map((r) => r.num).join(" vs ")}${missing.length ? ` (${missing.join(",")} missing)` : ""}`),
  };
}

async function atlasFallback(
  pref: "fastest" | "cheapest" | "best",
  ctx: AgentContext,
  nlu: NluResult,
): Promise<{ reply: string; ok: boolean; trace: ToolTraceStep; grounded: boolean; trains: AgentTrainTable | null; journey?: JourneyPlan | null; choice?: import("./agentic.js").ChoiceBlock | null }> {
  /* 2026-09-06: "12014 vs 12054 kon si better" — deterministic compare pehle. */
  if (nlu.intent === "COMPARE_TRAINS" && (nlu.compareNumbers?.length ?? 0) >= 2) {
    const cmp = await compareTrainsDeterministic(nlu.compareNumbers!);
    return { reply: cmp.reply, ok: cmp.ok, trace: cmp.trace, grounded: true, trains: null };
  }
  const trace = (ok: boolean, source: string | null, summary: string, dataPreview?: string): ToolTraceStep => ({
    step: 1,
    tool: "JOURNEY_ANALYZE",
    args: {
      origin: ctx.origin?.code ?? nlu.unresolvedFrom ?? null,
      destination: ctx.destination?.code ?? nlu.unresolvedTo ?? null,
      date: ctx.date ?? null,
      preference: pref,
    },
    ok,
    source,
    summary,
    latencyMs: 0,
    ...(dataPreview ? { dataPreview } : {}),
  });

  /* 1) Ambiguous city → REAL station options ke saath clarification.
   * Round-9 (Agra-bug): pending cluster-city bhi — "agra se delhi" mein
   * Delhi ka choice dene ke baad Agra bhool jaata tha. */
  const unresolved =
    nlu.unresolvedTo ??
    nlu.unresolvedFrom ??
    ctx.pendingDestinationChoice ??
    ctx.pendingOriginChoice ??
    null;
  if (unresolved) {
    const res = await routedStationSearch(unresolved);
    /* Round-16j (screenshot: "koaa" → "KOLKATA ke liye kaunsa station? 1. KOAA"):
     * provider ne EXACTLY ek station diya aur choice nahi maangi → wahi hai,
     * poochhne ka matlab nahi. Slot bhar ke aage badho. */
    if (res.stations.length === 1 && !res.needChoice) {
      const only = res.stations[0];
      const st = { code: only.code, name: only.name, city: only.city ?? only.name };
      if (nlu.unresolvedTo || (!nlu.unresolvedFrom && ctx.pendingDestinationChoice)) {
        ctx.destination = st;
        ctx.pendingDestinationChoice = null;
      } else {
        ctx.origin = st;
        ctx.pendingOriginChoice = null;
      }
      return atlasFallback(pref, ctx, { ...nlu, unresolvedFrom: undefined, unresolvedTo: undefined });
    }
    const list = res.stations.slice(0, 6).map((s, i) => `${i + 1}. ${s.code} – ${s.name}`).join(", ");
    const question = list
      ? `${res.city ?? unresolved} mein kaun sa station chahiye? Options: ${list}`
      : `"${unresolved}" ke liye exact station chahiye — station ka naam ya code bataiye.`;
    return {
      reply: question,
      ok: false,
      trace: trace(
        false,
        res.provider,
        `${unresolved} ambiguous — station clarification`,
        JSON.stringify({ needs_choice: true, city: res.city ?? unresolved }).slice(0, 400),
      ),
      grounded: true, // sirf sawaal — koi factual claim nahi
      trains: null,
      choice: res.stations.length ? { kind: "station", title: `${res.city ?? unresolved} — kaunsa station?`, options: res.stations.slice(0, 8).map((st) => ({ label: `${st.code} – ${st.name}`, value: st.code, sub: null })), sendTemplate: "{value}" } : null,
    };
  }

  /* 2) Missing slots → honest ask, koi silent assumption nahi. */
  const missingAsk = !ctx.origin
    ? "Kahan se jaana hai? Departure station bataiye."
    : !ctx.destination
      ? "Kahan jaana hai? Station bataiye."
      : !ctx.date || !ctx.dateProvided
        ? nlu.dateAmbiguous?.length
          ? /* Round-18l: "is weekend" → real Sat/Sun options, user chune (date kabhi assume nahi). */
            `${ctx.origin.code} → ${ctx.destination.code} — weekend mein kaunsa din? ${nlu.dateAmbiguous.map((d) => `${d.label} (${d.date})`).join(" ya ")}?`
          : `${ctx.origin.code} → ${ctx.destination.code} — kis date ko jaana hai? (aaj/kal/parso ya tareekh)`
        : !(ctx.paxProvided && ctx.passengers) && !(nlu.passengerCount && nlu.passengerCount >= 1) && !ctx.selectedTrainNumber
          /* Round-18m-30t: route-level planner passengers ke bina kabhi nahi (same rule as tools).
           * Round-43: par khaas train selected ho to availability pax ke bina bhi jawab hai (ChatGPT jaisa). */
          ? `${ctx.origin.code} → ${ctx.destination.code}, ${ctx.date} — kitne passengers hain? (1–6) Seats usi hisaab se check karunga.`
          : null;
  if (missingAsk) {
    if (/kitne passengers/.test(missingAsk)) ctx.bookingStage = "collecting";
    return { reply: missingAsk, ok: false, trace: trace(false, null, "slot missing — clarification"), grounded: true, trains: null };
  }
  if (!(ctx.paxProvided && ctx.passengers) && nlu.passengerCount) { ctx.passengers = nlu.passengerCount; ctx.paxProvided = true; }

  /* 3) REAL search + bounded fare probe — numbers sirf provider evidence se. */
  const search = await searchTrainsRouted({ from: ctx.origin!.code, to: ctx.destination!.code, date: ctx.date! });
  let siblingNote = "";
  if (!search.trains.length) {
    const sib = await sameCityFallbackSearch(ctx.origin!.code, ctx.destination!.code, ctx.date!);
    if (sib) {
      const newCode = sib.changed === "destination" ? sib.to : sib.from;
      const nm = (sib.changed === "destination" ? sib.trains[0]?.to.name : sib.trains[0]?.from.name) || newCode;
      siblingNote = `${ctx.origin!.code} → ${ctx.destination!.code} ke liye seedhi train nahi — usi shehar ke ${newCode} (${nm}) ki trains dikha raha hoon (station badla hai). `;
      if (sib.changed === "destination") ctx.destination = { code: newCode, name: nm, city: ctx.destination!.city ?? ctx.destination!.name }; else ctx.origin = { code: newCode, name: nm, city: ctx.origin!.city ?? ctx.origin!.name };
      search.trains = sib.trains; search.provider = sib.provider;
    }
  }
  const trains = search.trains;
  void siblingNote;
  if (!trains.length) {
    return {
      reply: `${ctx.origin!.code} → ${ctx.destination!.code} (${ctx.date!}) ke liye koi train nahi mili — main andaza nahi lagaunga.`,
      ok: false,
      trace: trace(
        false,
        search.provider,
        "0 trains — honest unavailable",
        JSON.stringify({ trains: 0, provider: search.provider }).slice(0, 400),
      ),
      grounded: true, // "0 trains" claim provider evidence se hi aaya
      trains: null,
    };
  }

  // Bounded REAL fare probe (agentic journeyAnalyze jaisa): top-3 shortest
  // candidates ko ek class-board each — searched class codes hi hint, koi
  // extra schedule round-trip nahi.
  const probe = new Map<string, { fare: number; classCode: string; status: string; seats: number | null } | null>();
  await Promise.all(
    [...trains]
      .sort((a, b) => a.durationMinutes - b.durationMinutes)
      .slice(0, 3)
      .map(async (t) => {
        try {
          const board = await routedClassBoard(
            t.number,
            ctx.date!,
            ctx.origin!.code,
            ctx.destination!.code,
            "GN",
            t.classes.map((c) => c.code),
          );
          const available = board.classes.filter((c) => c.status === "AVAILABLE" && c.fare > 0);
          const usable = [...available].sort((a, b) => a.fare - b.fare)[0];
          probe.set(
            t.number,
            usable ? { fare: usable.fare, classCode: usable.code, status: usable.status, seats: usable.seats ?? null } : null,
          );
        } catch {
          probe.set(t.number, null);
        }
      }),
  );

  const fareOf = (n: string) => probe.get(n)?.fare ?? Number.MAX_SAFE_INTEGER;
  const ranked =
    pref === "fastest"
      ? [...trains].sort((a, b) => a.durationMinutes - b.durationMinutes || a.departure.localeCompare(b.departure))
      : [...trains].sort((a, b) => fareOf(a.number) - fareOf(b.number) || a.durationMinutes - b.durationMinutes);
  const train = ranked[0];
  const pr = probe.get(train.number) ?? null;
  const label = pref === "cheapest" ? "Sabse sasti train" : pref === "fastest" ? "Sabse fast train" : "Best option";
  const fareLine = pr
    ? `Cheapest available class: ${pr.classCode} ₹${pr.fare.toLocaleString("en-IN")}${pr.seats != null ? ` (${pr.seats} seats)` : ""}.`
    : `Is train ka live fare/availability abhi confirm nahi ho paya — bol do to fresh check karta hoon.`;
  const others = ranked
    .slice(1, 3)
    .map((t) => {
      const c = probe.get(t.number) ?? null;
      return `${t.number} ${t.name} (${c ? `${c.classCode} ₹${c.fare.toLocaleString("en-IN")}` : `dur. ${t.durationLabel}`})`;
    });
  // Sabse fast UPFRONT (user feedback 2026-09-05): lead train fast se different
  // ho to bhi fastest line reply mein top ke paas rahe — table mein bhi highlight hai.
  const fastestAll = [...trains].sort((a, b) => a.durationMinutes - b.durationMinutes)[0];
  const fastestLine =
    fastestAll && fastestAll.number !== train.number
      ? `Sabse fast: ${fastestAll.number} ${fastestAll.name} (${fastestAll.durationLabel}).`
      : "";
  const reply = [
    `${label} ${ctx.origin!.code} → ${ctx.destination!.code} (${ctx.date!}): ${train.number} ${train.name} — ${train.departure} → ${train.arrival} (${train.durationLabel}).`,
    fareLine,
    fastestLine,
    others.length ? `Aur options: ${others.join("; ")}.` : "",
    `Poora comparison neeche table mein hai.`,
    `(Real ${search.provider} data — guess nahi.)`,
  ]
    .filter(Boolean)
    .join("\n");
  const fares = new Map<string, { classCode: string; amount: number } | null>(
    [...probe.entries()].map(([n, f]) => [n, f ? { classCode: f.classCode, amount: f.fare } : null]),
  );
  /* Round-18 §5: deterministic path bhi proactive BEST FOR YOU + YOU MAY ALSO
   * CONSIDER plan deta hai (searched trains reuse — extra search nahi). */
  let journey: JourneyPlan | null = null;
  try {
    journey = await planJourney({ from: ctx.origin!.code, to: ctx.destination!.code, date: ctx.date!, travelClass: ctx.classCode ?? null, preference: pref === "cheapest" ? "cheapest" : pref === "fastest" ? "fastest" : "best_overall", includeConnections: true /* Round-18m-30g: leg-1/leg-2 HAMESHA (user rule) */, includeAlternativeDates: false, trains, searchProvider: search.provider, passengers: ctx.paxProvided ? ctx.passengers : null });
  } catch {
    journey = null;
  }
  return {
    reply,
    ok: true,
    journey,
    trains: tableFromSearch(ctx.origin!.code, ctx.destination!.code, ctx.date!, ranked.slice(0, 12), fares),
    trace: trace(
      true,
      search.provider,
      `${train.number} ${train.name} — ${train.durationLabel}${pr ? `, ${pr.classCode} ₹${pr.fare.toLocaleString("en-IN")}` : ""}`.slice(0, 300),
      JSON.stringify({
        top: train.number,
        trains: trains.length,
        provider: search.provider,
        probed: [...probe.entries()].map(([n, f]) => `${n}:${f ? f.classCode + "@" + f.fare : "null"}`),
      }).slice(0, 400),
    ),
    grounded: true,
  };
}

export type AgentRequest = {
  text: string;
  lastAsked?: DialogSlot | null;
  known?: {
    from?: { code: string; name: string; city: string } | null;
    to?: { code: string; name: string; city: string } | null;
    date?: string | null;
    passengerCount?: number | null;
  };
  context?: AgentContext;
  now?: string;
  bookingFlow?: string;
  /** Prior conversation turns — multi-turn state for the AI tool-calling layer. */
  history?: AgenticHistoryTurn[];
};

export type AgentResponse = {
  nlu: NluResult;
  source: "ai" | "nlu";
  context: AgentContext;
  tool: AgentToolName;
  toolOk: boolean | null;
  reply: string | null;
  interrupt: boolean;
  resumeAsk: DialogSlot | null;
  resumeText: string | null;
  confirmBook: false;
  missingFields: string[];
  modelUsed: string | null;
  modelFallbacks?: { model: string; reason: string; ms: number; round: number }[];
  latencyMs: number;
  failureReason: string | null;
  engine?: "agentic_tool_calling" | "deterministic";
  toolTrace?: ToolTraceStep[];
  /** Structured search results — client isse organized TABLE banata hai (2026-09-05 feedback). */
  trains?: AgentTrainTable | null;
  /** Round-17: RANK_JOURNEY_OPTIONS ka full deterministic plan (BEST OPTION + alternatives card). */
  journey?: import("../journey/types.js").JourneyPlan | null;
  /** Round-18: alternatives card + SELECT TRAIN picker. */
  alternatives?: import("../journey/types.js").AlternativeTrainsResult | null;
  trainPicker?: import("../journey/trainpicker.js").TrainPickerResult | null;
  /** Round-18m-33: dropdown choice (station / run-day / train) — client renders select + "Chuno". */
  choice?: import("./agentic.js").ChoiceBlock | null;
  /** Round-18m: live-status run-date chooser — ONLY dates a provider actually has a run for. */
  liveDates?: { trainNumber: string; trainName: string | null; options: import("../railway/router.js").LiveDateOption[] } | null;
  grounded?: boolean;
  /** Agentic turn chala par model/provider fail hua to wajah (observability; success par null). */
  agenticFailureReason?: string | null;
  /** Round-32: model ka khud chuna hua "agla kadam" (us turn ke verified data se validate hokar). */
  nextActions?: import("./agentic.js").NextAction[] | null;
  /** Round-53 (user: "Green portion wali trains card mein nahi dikh rahi"): model ne jo FIND_SEATS
   * chalaya usi ka poora live data — app isi se cards banata hai, isliye jawab ka text aur cards
   * bilkul ek hi snapshot ke hote hain (pehle cards ke liye dobara board fetch hota tha). */
  seatCapture?: SearchCapture["seat"] | null;
};

/**
 * ARCHITECTURE (AI-first tool calling):
 *
 *   USER → NVIDIA GPT-OSS-20B (understands request, SELECTS approved tools)
 *        → SERVER executes each tool call securely (keys never reach the model)
 *        → RailCore PRIMARY → RailKit FALLBACK (every result carries `source`)
 *        → tool result returned to the model → model may chain the next tool
 *        → final grounded response (numbers must exist in tool evidence)
 *
 * Koi deterministic classifier pehle se tool calls decide NAHI karta — jo
 * tool chahiye, kitne chahiye, kis order mein chahiye, yeh MODEL decide
 * karta hai (multi-step). Deterministic NLU/tool-routing sirf FALLBACK hai:
 * model missing/timeout/error/ungrounded ho tab chalta hai. Booking mutations
 * (payment/confirm/passengers) hamesha deterministic booking engine ke paas
 * rehte hain — model ke paas booking tool hai hi nahi, confirmBook kabhi true
 * nahi hota.
 */

/** Booking stages where the deterministic booking engine must own the turn. */
const BOOKING_MUTATION_STAGES = new Set([
  "PASSENGERS_PENDING",
  "FARE_REVIEW",
  "PAYMENT_PENDING",
  "BOOKING_PENDING",
  "PASSENGERS",
  "REVIEW",
  "PAYMENT",
  "CONFIRM",
]);

/** Hard booking-action phrases — never routed to the model (defense in depth). */
/* Round-52 (29 Sep 2026, user: "Bss AI pe hi har query jaaye … deterministic path chale hi na"):
 * pehle ye regex akela "confirm" shabd par bhi match kar leta tha — isliye "confirm seat find out karke
 * do na" jaise SEAT SAWAAL booking-hukm maan liye jaate the aur poora AI-first flow skip ho jaata tha
 * (jawab deterministic path se aata tha). Ab mutation = ASLI booking hukm hi:
 *   ✓ "book kar do" · "12919 book krdo" · "ticket book kar" · "booking karo" · "confirm karo kar do"
 *   ✓ "confirm & book" · "payment kar do" · "paise de do" · "haan book"
 *   ✗ "confirm seat find out karke do" · "2S confirm hai kya" · "confirmed ticket wali trains" */
const BOOKING_MUTATION_TEXT =
  /\b(book\s*(?:kar(?:\s*(?:do|de|dijiye|dena))?|kardo|krdo|kro)|ticket\s*(?:book|kata|kat\s*do)|booking\s*(?:kar|karo|kardo|krdo)|confirm\s*(?:&|and|\+)?\s*book|pay(?:ment)?\s*(?:kar(?:\s*do)?|karo|kardo|krdo)|paise\s*(?:de|do)|payment|haan\s*book|yes\s*book|book\s*it)\b/i;

/* Round-52: akela "confirm karo" tab booking-hukm hai jab wo khud command ho — sawaal me
 * seat/availability ka zikr ho to wo SEAT sawaal hai ("2S confirm hai kya", "seat availability
 * confirm karo", "kal ki confirmed seat wali trains"). */
const CONFIRM_IMPERATIVE_TEXT = /\bconfirm\s*(?:kar(?:\s*(?:do|de|dijiye|dena))?|karo|kardo|krdo|kro|kiya|kijiyega)\b/i;
const SEAT_CONTEXT_TEXT = /\b(seat|seats|berth|avl|availability|available|khaali|khali|rac|wl|waitlist|waiting|confirmed)\b/i;

/** Station-options content detector — numbered list, "Options:" list, ya
 *  bare paren codes "(DLI, DEC, NDLS…)" — model ka format vary karta hai. */
function mentionsStationOptions(content: string | null | undefined): boolean {
  const c = String(content ?? "");
  return (
    /options?\s*:/i.test(c) ||
    /kaunse?\s+station|kaun\s*sa\s+station|kis\s+station|kis\s+delhi\s+station|station chahiye|stations?\s+hain?\s*[—–-]?\s*kaun|kaunsa\s+chahiye|konsa\s+chahiye|kaunsa\s+station|konsa\s+station|which\s+station/i.test(c) ||
    /* Round-18m-30l: AI-written options ("1. LKO — Lucknow NR\n2. LJN — …") — 2+ numbered CODE – Name items = options. */
    ((c.match(/(?:^|\s)\d{1,2}[.)]\s*[A-Z]{2,5}\s*[–—-]\s*[A-Za-z]/g) ?? []).length >= 2) ||
    ((c.match(/(?:^|\s|\()\d{1,2}[.)]\s*[A-Z]{2,5}(?=\s|,|\)|\.|$)/g) ?? []).length >= 2 && /station/i.test(c)) ||
    /\(\s*[A-Z]{2,5}(?:\s*,\s*[A-Z]{2,5}){2,}\s*\)/.test(c)
  );
}

/** Reply khud koi sawaal pooch raha ho (station options ya koi bhi "?") to
 *  booking-resume bubble (doosra conflicting sawaal — "Kahan jaana hai?")
 *  suppress karo — ek turn mein AI ka EK hi sawaal user tak jaata hai. */
function asksStationChoice(reply: string | null | undefined): boolean {
  const r = String(reply ?? "");
  return mentionsStationOptions(r) || /\?/.test(r);
}

export function isBookingMutation(req: AgentRequest): boolean {
  if (req.bookingFlow && BOOKING_MUTATION_STAGES.has(String(req.bookingFlow).toUpperCase())) return true;
  const t = String(req.text ?? "").trim();
  if (BOOKING_MUTATION_TEXT.test(t)) return true;
  return CONFIRM_IMPERATIVE_TEXT.test(t) && !SEAT_CONTEXT_TEXT.test(t);
}

/* ── Station-choice reply resolution ────────────────────────────────
 * Jab pichhla AI turn station OPTIONS pooch raha tha ("kaunsa Delhi
 * station? 1. DLI – DELHI …") aur user sirf "4" / "NDLS" / "New Delhi"
 * bolta hai — dono engines ke liye slot pre-fill karo. Model history
 * se map na kar paye ya agentic fail ho jaye, tab bhi flow aage badhta
 * hai aur DETERMINISTIC path kabhi khali reply nahi deta. */

export type StationPick = { code: string; name: string; city: string; side: "to" | "from" } | null;

/** Words jo station pick KABHI nahi ho sakte (dates/affirmations). */
const NON_STATION_WORDS =
  /^(kal|aaj|parson|haan|nahi|na|no|yes|ok|okay|done|thik|theek|accha|acha|sahi|aur|kitne|ek|do|teen|char|paanch)$/i;

function parseNumberedOptions(content: string): { n: number; code: string; label: string }[] {
  /* Round-18m-30m (prod: model ne "1. LKO 2. LJN (Please reply with 1 or 2.)" likha — bina naam/dash — "2" map
   * nahi hua → "Kahan jana hai?"): bare "N. CODE" bhi options hain. Dash/naam optional. */
  const bare = [...content.matchAll(/(?:^|\s|\()(\d{1,2})[.)]\s*([A-Z]{2,5})(?=\s|,|\)|\.|$)/g)].map((m) => ({ n: Number(m[1]), code: m[2].toUpperCase(), label: m[2].toUpperCase() }));
  const re = /(\d{1,2})[.)]\s*([A-Za-z]{2,5})\s*[–—-]\s*/g;
  const items: { n: number; code: string; label: string }[] = [];
  let m: RegExpExecArray | null;
  while ((m = re.exec(content))) {
    const start = re.lastIndex;
    const rest = content.slice(start);
    const next = rest.search(/\d{1,2}[.)]\s*[A-Za-z]{2,5}\s*[–—-]/);
    const label = (next >= 0 ? rest.slice(0, next) : rest.slice(0, 60)).replace(/[\n\r].*$/s, "").trim();
    /* Round-18m-30h: label = sirf station naam ("Ayodhya", "Ayodhya Cantt"), trailing ", " / "." / baaki sentence hataao. */
    items.push({ n: Number(m[1]), code: m[2].toUpperCase(), label: label.split(/[,.](?=\s|$)/)[0].trim().slice(0, 40) });
  }
  if (items.length >= 2) return items;
  if (bare.length >= 2) {
    /* "LKO (Lucknow NR)" / "LKO – Lucknow NR" kahin aur text mein ho to naam wahan se. */
    return bare.map((b) => {
      const nm = content.match(new RegExp(`\\b${b.code}\\s*(?:\\(|[–—-]\\s*)([A-Za-z][A-Za-z .'&]{1,40}?)(?:\\)|,|\\.|\\n|$)`));
      return { ...b, label: nm?.[1]?.trim() || b.code };
    });
  }
  return items;
}

function parseCodePairs(content: string): { code: string; label: string }[] {
  return [...content.matchAll(/\b([A-Za-z]{2,5})\s*[–—-]\s*([A-Za-z][A-Za-z .'&]{1,40}?)(?=\s*,|\s*\n|$)/g)].map((m) => ({
    code: m[1].toUpperCase(),
    label: m[2].trim(),
  }));
}

/** Compact format: "(Options: DLI, DEC, DEE, NDLS, NZM, ANVT, DAZ, DE)" —
 *  model kabhi numbered list deta hai, kabhi sirf ordered comma codes. */
function parseCompactCodes(content: string): string[] {
  // "Options: DLI, DEC…" YA bare "(DLI, DEC, …)" — dono; par codes SIRF
  // uppercase aur keyword/paren zaroori (random "(CC, EC)" class-lists nahi).
  const m = content.match(/(?:[Oo]ptions?\s*[:\-]?\s*\(?|\(\s*)([A-Z]{2,5}(?:\s*,\s*[A-Z]{2,5}){1,11})/);
  if (!m) return [];
  return m[1]
    .split(/\s*,\s*/)
    .map((c) => c.toUpperCase())
    .filter((c) => /^[A-Z]{2,5}$/.test(c));
}

/** Paren-per-code format: "New Delhi (NDLS), Delhi Junction (DLI), …" —
 *  unnumbered, par ORDER se numeric pick map ho jata hai. */
function parseParenCodes(content: string): string[] {
  return [...content.matchAll(/\(([A-Z]{2,5})\)/g)].map((m) => m[1]).filter((c, i, arr) => arr.indexOf(c) === i);
}

async function verifyStationCode(code: string, label: string, side: "to" | "from", fromHistory: boolean): Promise<StationPick> {
  let apiAnswered = false;
  try {
    const res = await routedStationSearch(code);
    // "none" = koi provider jawab nahi de paya; railcore/railkit/kb = real jawab mila.
    apiAnswered = res.provider !== "none";
    const st = res.stations?.[0];
    /* Round-18m-30h (prod screenshot: options "1. AY – Ayodhya" → user "1" → "LDH → BZA"!): local fuzzy
     * search "AY" ko Vijayawada (BZA) de raha tha aur "single result" branch ne use accept kar liya.
     * Rule: user ne jo CODE chuna, EXACT wahi code match ho — kisi bhi doosre code ko kabhi accept nahi. */
    const exact = (res.stations ?? []).find((x) => x.code.toUpperCase() === code.toUpperCase());
    if (exact) {
      const placeholder = !exact.name || exact.name.toUpperCase() === exact.code.toUpperCase();
      const name = placeholder && label && label.toUpperCase() !== code.toUpperCase() ? label : exact.name;
      return { code: exact.code, name, city: placeholder ? name : exact.city ?? name, side };
    }
    if (st && st.code.toUpperCase() !== code.toUpperCase()) {
      /* Provider ne koi AUR station diya — ye confirm nahi, mismatch hai. History (server ne khud options
       * diye the) hi asli proof hai → history label ke saath user ka code lo. */
      if (fromHistory && /^[A-Za-z]{2,5}$/.test(code)) return { code: code.toUpperCase(), name: label && label !== code.toUpperCase() ? label : code.toUpperCase(), city: label || code.toUpperCase(), side };
      return null;
    }
  } catch {
    /* network fail — history evidence fallback (neeche) */
  }
  // API UP hai aur code confirm NAHI hua → model ka invented/garbage code reject.
  // History fallback: server ne khud ye options diye the (fromHistory) — code lo, label ke saath.
  if (fromHistory && /^[A-Za-z]{2,5}$/.test(code)) {
    return { code: code.toUpperCase(), name: label && label !== code.toUpperCase() ? label : code.toUpperCase(), city: label || code.toUpperCase(), side };
  }
  void apiAnswered;
  return null;
}

/* Round-18m-30l (prod screenshot LDH→LJN: "koi train nahi mili" jabki ConfirmTkt LDH→LKO ki trains dikha raha
 * tha): chune station par 0 trains → usi city ke sibling stations (LKO↔LJN, NDLS↔DLI↔NZM…) par search karke
 * user ko SAAF bata kar suggest karo — route chupke se kabhi nahi badalta (user rule), sirf bataya jaata hai. */
async function sameCityFallbackSearch(from: string, to: string, date: string): Promise<{ from: string; to: string; changed: "origin" | "destination"; trains: TrainResult[]; provider: ServedProvider } | null> {
  const { clusterSiblings } = await import("../journey/engine.js");
  const pairs = [
    ...clusterSiblings(to).map((t) => ({ from, to: t, changed: "destination" as const })),
    ...clusterSiblings(from).map((f) => ({ from: f, to, changed: "origin" as const })),
  ];
  for (const p of pairs.slice(0, 4)) {
    try {
      const r = await searchTrainsRouted({ from: p.from, to: p.to, date });
      if (r.trains.length) return { ...p, trains: r.trains, provider: r.provider };
    } catch {
      /* next sibling */
    }
  }
  return null;
}

export async function resolveStationPick(
  text: string,
  history: AgenticHistoryTurn[] | undefined,
  ctx: AgentContext,
): Promise<StationPick> {
  const t = String(text ?? "").trim();
  if (!t || t.length > 40) return null;
  if (/\d{5}/.test(t)) return null; // train number
  if (NON_STATION_WORDS.test(t)) return null;
  if (/\bse\b|\bfrom\b/i.test(t)) return null; // "NDLS se ASR" jaisa direction-wala text pick nahi
  if (t.split(/\s+/).length > 4) return null; // lambi baat normal NLU handle karegi
  // Sirf tab jab exactly ek side pending ho
  const side: "to" | "from" | null = !ctx.destination && ctx.origin ? "to" : !ctx.origin && ctx.destination ? "from" : null;
  if (!side) return null;

  // History (latest-first) mein station-options waala aakhri assistant message
  let numbered: { n: number; code: string; label: string }[] = [];
  let pairs: { code: string; label: string }[] = [];
  let compact: string[] = [];
  for (const h of [...(history ?? [])].reverse()) {
    if (h.role !== "assistant" || !h.content) continue;
    const c = String(h.content);
    if (!mentionsStationOptions(c)) continue;
    numbered = parseNumberedOptions(c);
    pairs = parseCodePairs(c);
    compact = parseCompactCodes(c);
    if (compact.length < 2) compact = parseParenCodes(c); // "(NDLS), (DLI), …" ordered
    if (numbered.length >= 2 || pairs.length >= 2 || compact.length >= 2) break;
  }

  // 1) Numeric pick: "4", "option 4", "4 chuniye" — numbered list ya compact
  //    comma-list (position se) dono se map hota hai.
  const numMatch = t.match(/^(?:option\s*)?(\d{1,2})\s*(?:number|chuniye|lijiye|vala|wala)?[.!]?$/i);
  const n = Number(numMatch?.[1]);
  if (Number.isFinite(n) && n >= 1) {
    if (numbered.length && n <= numbered.length) {
      const chosen = numbered[n - 1];
      return verifyStationCode(chosen.code, chosen.label, side, true);
    }
    if (compact.length && n <= compact.length) {
      return verifyStationCode(compact[n - 1], compact[n - 1], side, true);
    }
    // "DLI – DELHI, DEC – DELHI CANTT, …" ordered pairs list — position se map.
    if (pairs.length && n <= pairs.length) {
      return verifyStationCode(pairs[n - 1].code, pairs[n - 1].label, side, true);
    }
  }
  // 2) Bare station code: "NDLS"
  if (/^[A-Za-z]{2,5}[.!]?$/.test(t)) {
    const code = t.replace(/[.!]$/, "").toUpperCase();
    const inHistory = numbered.some((o) => o.code === code) || pairs.some((o) => o.code === code) || compact.includes(code);
    return verifyStationCode(code, code, side, inHistory);
  }
  // 3) Naam jo history options se match ho: "new delhi", "nizamuddin"
  const lower = t.toLowerCase().replace(/[.!]$/, "");
  if (pairs.length) {
    const hit =
      pairs.find((o) => o.code.toLowerCase() === lower) ??
      pairs.find((o) => o.label.toLowerCase().includes(lower) || lower.includes(o.label.toLowerCase()));
    if (hit) return verifyStationCode(hit.code, hit.label, side, true);
  }
  return null;
}

/** Train NAAM se resolve (user feedback 2026-09-05: "kisi aur train ka naam
 * se poocha, vande bharat hi bata diya"). (1) pichhli search list mein se naam
 * match, (2) nahi to RailCore /trains/search API se. Ek solid match → number;
 * multiple/zero → honest clarify (galat train ka data KABHI nahi). */
/* Round-13 (prod incident 2026-09-07): explicit ROUTE pattern — "munbai se
 * dilli kal ki train" jaisi journey query par fuzzy train-name search
 * "munbai"→"MUMBAI MAIL" hijack kar raha tha (engine ko milta hi nahi).
 * Word-word "se"/से (ya "from X to Y") = route query — bina train-type/naam
 * keyword ke train-NAME resolve skip, engine (NLU/agentic) route samjhe. */
const ROUTE_QUERY_RE = /(?:^|\s)\S+\s+se\s+\S+|(?:^|\s)\S+\s+से\s+\S+|\bfrom\s+\S+\s+to\s+\S+/i;

/** Phrase user ke apne origin/destination station se match karti hai? ("amritsar ka
 * time" = station context, train-name search NAHI chalana). */
function phraseMatchesStation(phrase: string, ctx: AgentContext): boolean {
  if (!phrase) return true;
  const ptoks = phrase.toLowerCase().split(/\s+/).filter(Boolean);
  for (const st of [ctx.origin, ctx.destination]) {
    if (!st) continue;
    const stoks = `${st.city} ${st.name} ${st.code}`
      .toLowerCase()
      .split(/[^a-z0-9]+/)
      .filter(Boolean);
    if (ptoks.length && ptoks.every((t) => stoks.includes(t))) return true;
  }
  return false;
}


/* "AMRITSAR SHATABDI" -> "Amritsar Shatabdi" — web queries case-sensitivity
 * ke liye (DDG/Wikipedia titlecase par better milti hain). */
function titleCaseWords(s: string): string {
  return String(s ?? "")
    .toLowerCase()
    .split(/\s+/)
    .map((w) => (w ? w[0].toUpperCase() + w.slice(1) : w))
    .join(" ");
}

async function resolveTrainByName(
  text: string,
  ctx: AgentContext,
): Promise<{ trainNumber: string; trainName: string } | { clarify: string; picker?: TrainPickerResult } | null> {
  if (/\b\d{4,6}\b/.test(text)) return null; // number already diya
  const list = ctx.lastTrains ?? [];

  const listHit = list.length ? matchTrainNameInList(text, list) : null;
  if (listHit && !("ambiguous" in listHit)) {
    return { trainNumber: listHit.number, trainName: listHit.name };
  }
  if (listHit && "ambiguous" in listHit) {
    const lines = listHit.ambiguous.slice(0, 4).map((t) => `${t.number} ${t.name}`).join("; ");
    return { clarify: `Kaunsi train — ${lines}? Train number bata dijiye.` };
  }

  /* Gate (user feedback: "AI ko khud samjhna chahiye"): train-NAME jaisi phrase
   * + train-info follow-up — aur phrase koi STATION nahi (route query se bachne
   * ke liye). Keyword (shatabdi/rajdhani/…) ho to follow-up ki zaroorat nahi. */
  const hasNameKeyword = TRAIN_TYPE_KEYWORD_RE.test(text) || TRAIN_NAME_SUFFIX_RE.test(text);
  const phrase = trainNamePhrase(text) ?? "";
  /* Round-13: route query ("munbai se dilli ...") — lastTrains list-hit ke
   * BAAAD check karo (list wale "us wali" resolve बचे रहें), par generic
   * fuzzy name-search se journey ko hijack mat karo. */
  if (!hasNameKeyword && ROUTE_QUERY_RE.test(text)) return null;
  /* 2026-09-06: "kon kon se stops hai" jaise follow-up question-phrases train
   * naam nahi — fuzzy search se hijack MAT ("kon kon" → KONKAN KANYA thi). */
  if (!hasNameKeyword && !/\d{4,6}/.test(text) && isQuestionPhraseNotTrainName(text)) return null;
  /* 2026-09-06 (screenshot): "vande bharat ki top speed" GENERAL-FACT sawaal
   * hai — train-number resolve karke "kaunsi?" poochna hi nahi. Fact words +
   * no number → naam-resolution skip, general-fact web path jawab dega. */
  if ((GENERAL_FACT_RE.test(text) || CONCEPT_QUESTION_RE.test(text)) && !/\b\d{5}\b/.test(text)) return null;
  /* Round-18m-30z (screenshot: "Kya vande bharat mein khaana milta hai?" → 6-train picker, phir Wikipedia dump):
   * "vande bharat/rajdhani mein khaana/pantry/catering/wifi/charging…" = TRAIN-TYPE ka GENERAL sawaal (kisi ek
   * train ka nahi) — picker nahi; KB/web jawab dega. Aur agar ek train pehle se selected hai to wahi train. */
  if (/\b(khaana|khana|food|meal|meals|pantry|catering|wifi|wi-fi|charging|bedding|blanket|toilet|washroom|ac\b|luggage|saman|samaan)\b/i.test(text) && !/\b\d{5}\b/.test(text)) return null;
  if (!hasNameKeyword) {
    const followish =
      /^(timetable|live|fare|availability|coach|train_pick)$/.test(classifyFollowUp(text) ?? "") ||
      /\btrains?\b/i.test(text);
    const phraseIsStation = phraseMatchesStation(phrase, ctx);
    if (!followish || phrase.length < 4 || phraseIsStation) return null;
  }
  if (!phrase || phrase.length < 3) return null;
  /* Phrase koi STATION to nahi? ("amritsar ka time" jaisi journey query ko
   * train-search se hijack mat karo — live station API se verify karo.) */
  try {
    const stRes = await routedStationSearch(phrase);
    const p = phrase.toLowerCase();
    const isStation = stRes.stations.some(
      (st) => st.city.toLowerCase() === p || st.name.toLowerCase().includes(p),
    );
    if (isStation) return null;
  } catch {
    /* station check fail — train search chalne do */
  }
  let results: { number: string; name: string; from: string; to: string }[] = [];
  let pickerResult: TrainPickerResult | null = null;
  try {
    /* Round-18: routed chain (RailCore → RailRadar → IndianRailAPI → erail list)
     * + normalized/fuzzy ranking; ambiguity → SELECT TRAIN picker for the UI. */
    pickerResult = await pickTrains(phrase, { context: { from: ctx.origin?.code ?? null, to: ctx.destination?.code ?? null }, limit: 6 });
    results = pickerResult.matches.map((m) => ({ number: m.number, name: m.name, from: m.from ?? "", to: m.to ?? "" }));
  } catch {
    return null; // API fail — engine seedha jaane de (deterministic honest ask)
  }
  /* 0 results → KUCH mat karo (hijack nahi) — normal model/deterministic flow.
   * Phrase generic ho sakta hai; honest clarify sirf real train-name conflict par. */
  if (!results.length) return null;
  // Route context se relevance: user ke EXACT origin→destination direction wali
  // train pehle (up/down pair "SHANE PUNJAB" 12498/12497 mein sahi direction).
  const o = ctx.origin?.code?.toUpperCase();
  const d = ctx.destination?.code?.toUpperCase();
  const exact = o && d ? results.filter((t) => t.from === o && t.to === d) : [];
  const pool = exact.length === 1 ? exact : exact.length > 1 ? exact : results;
  if (pool.length === 1) return { trainNumber: pool[0].number, trainName: pool[0].name };
  const lines = pool.slice(0, 4).map((t) => `${t.number} ${t.name}${t.from && t.to ? ` (${t.from}→${t.to})` : ""}`).join("; ");
  return {
    clarify: `\"${phrase}\" se ${pool.length} trains mili — kaunsi? ${lines}. Neeche list se select karo ya train number bata dijiye.`,
    picker: pickerResult && pickerResult.matches.length ? { ...pickerResult, matches: pickerResult.matches.filter((m) => pool.some((t) => t.number === m.number)) } : undefined,
  };
}

/** Search memory (2026-09-05 user feedback: "memory yaad nahi rehti"):
 * successful search ke baad ctx mein trains yaad rakho — agle turn par
 * "yeh wali / dusri wali / sabse fast wali" resolve ho sake, aur known
 * context model tak pahunchta rahe. */
function rememberSearch(ctx: AgentContext, table: AgentTrainTable | null | undefined): void {
  if (!table?.rows?.length) return;
  ctx.lastTrainNumbers = table.rows.map((r) => r.number);
  ctx.lastTrains = table.rows.map((r) => ({ number: r.number, name: r.name }));
  ctx.fastestTrainNumber = table.fastest;
  // Highlighted (fastest) train hi reply mein sabse prominent thi — "us wali" default wahi.
  if (!ctx.selectedTrainNumber) {
    ctx.selectedTrainNumber = table.fastest ?? table.rows[0].number ?? null;
    ctx.selectedTrainName = table.rows.find((r) => r.number === ctx.selectedTrainNumber)?.name ?? null;
  }
  ctx.bookingStage = "results";
}

/** TrainResult[] → AgentTrainTable (deterministic paths ke liye). */
function tableFromSearch(
  from: string,
  to: string,
  date: string,
  trains: { number: string; name: string; departure: string; arrival: string; arrivalDayOffset: number; durationMinutes: number; durationLabel: string; classes: { code: string }[] }[],
  fares?: Map<string, { classCode: string; amount: number } | null>,
): AgentTrainTable {
  const rows: AgentTrainRow[] = trains.map((t) => ({
    number: t.number,
    name: t.name,
    departure: t.departure,
    arrival: t.arrival,
    arrivalDayOffset: t.arrivalDayOffset,
    durationMinutes: t.durationMinutes,
    durationLabel: t.durationLabel,
    classes: t.classes.map((c) => c.code),
    fare: fares?.get(t.number) ?? null,
  }));
  const withDur = rows.filter((r) => r.durationMinutes != null);
  const fastest = withDur.length
    ? withDur.reduce((best, r) => ((r.durationMinutes ?? Infinity) < (best.durationMinutes ?? Infinity) ? r : best))
    : null;
  return { from, to, date, fastest: fastest?.number ?? null, rows };
}

function seedContext(req: AgentRequest): AgentContext {
  /* Round-8: partial client-context bhi safe — empty base par overlay
   * (warna missing lastTrainNumbers par [...undefined] crash). */
  const base: AgentContext = { ...emptyAgentContext(), ...(req.context ?? {}) };
  /* Round-8: justReset one-shot flag hai — client ke stored context se
   * dobara input par nahi aana chahiye. */
  delete base.justReset;
  if (req.known?.from) base.origin = req.known.from;
  if (req.known?.to) base.destination = req.known.to;
  /* Round-18m-30n (prod screenshot: "ludhiana se lucknow" → "1" → seedha 14 Sept ka plan, na date poochhi na
   * pax): client ka `known.date/passengerCount` sessionStorage se PURANI journey ka tha. Server ka agent
   * context (req.context) is journey ke liye date/pax reset kar chuka tha — wahi sach hai. Rule: agar server
   * context mein dateProvided/paxProvided FALSE hai (yaani is route ke liye user ne abhi nahi bataya), to client
   * ka stale known slot use NAHI hoga. Sirf tab seed karo jab server context khaali ho (pehla turn / reload). */
  const srvCtx = req.context ?? null;
  const ctxHasRoute = Boolean(srvCtx && (srvCtx.origin || srvCtx.destination || srvCtx.pendingDestinationChoice || srvCtx.pendingOriginChoice));
  /* Is message mein user ne khud koi ROUTE bola ("X se Y") → ye nayi journey ho sakti hai; client ki purani
   * date/pax tab tak nahi jab tak isi message mein na ho (mergeAgentContext NLU se nayi date/pax laata hai). */
  const speaksRoute = /\b(se|from)\b[\s\S]{1,40}\b(jaana|jana|jaunga|jaungi|tak|ko|to|ke liye|train|trains|seat|seats|ticket)\b/i.test(String(req.text ?? "")) && !/^\s*\d{1,2}\s*$/.test(String(req.text ?? ""));
  const allowClientDate = !speaksRoute && (!ctxHasRoute || srvCtx?.dateProvided === true);
  const allowClientPax = !speaksRoute && (!ctxHasRoute || srvCtx?.paxProvided === true);
  if (req.known?.date && allowClientDate) {
    base.date = req.known.date;
    base.dateProvided = true;
  }
  if (req.known?.passengerCount && allowClientPax) {
    base.passengers = req.known.passengerCount;
    base.paxProvided = true;
  }
  return base;
}

/* ── ChatGPT-jaisa SOURCE-SCRAPE (user request 2026-09-06): har popular
 * train ka Wikipedia page hota hai (e.g. "Haridwar–Amritsar Jan Shatabdi
 * Express" — speed/rake/history/slip-coach sab likha hota hai). Train ka
 * naam dhoondh kar us page ka POORA text laate hain aur question-relevant
 * paragraph dete hain — snippet se kaafi zyada, ChatGPT jaisa "scraped"
 * jawab. Fail/safe par null (caller apna fallback chalata hai). */
async function answerFromTrainPage(
  trainName: string,
  trainNumber: string | null,
  questionText: string,
): Promise<string | null> {
  const name = trainName.trim();
  if (name.length < 4) return null;
  try {
    /* Wikipedia full-text search naam+number par best chalta hai (RailCore
     * ka naam "Hw Janshatabdi" abbreviated hota hai — "Hw Janshatabdi 12054"
     * se "Haridwar–Amritsar Jan Shatabdi Express" milta hai, sirf naam se
     * galat Una-Link page bhi aati hai — number-verify usse reject karega). */
    /* Number-verify search ke ANDAR hota hai (mustInclude) — galat pehli
     * hit reject hoke sahi page next hit se milti hai. */
    let page = await findWikipediaPage(trainNumber ? `${name} ${trainNumber}` : name, trainNumber ?? undefined);
    if (!page && trainNumber) page = await findWikipediaPage(name, trainNumber);
    if (!page && !trainNumber) page = await findWikipediaPage(name);
    if (!page) return null;
    const paras = page.extract
      .split(/\n\n+/)
      .map((p) => p.replace(/\s+/g, " ").trim())
      .filter((p) => p.length > 40);
    if (!paras.length) return null;
    /* Question ke hisaab se best paragraph (ChatGPT jaisa "samajh ke"). */
    const TOPIC: { q: RegExp; p: RegExp }[] = [
      { q: /top speed|max speed|average speed|kitni tez|kitna tez|speed kya|speed kitni/i, p: /speed|km\/h|kmph|kph/i },
      { q: /history|kab chalu|kab shuru|kab start|kitne saal|kab bani|pehli|introduced/i, p: /introduced|inaugurat|started|commenced|began|flagged|history/i },
      { q: /coach|rake|composition|kitne coach/i, p: /coach|rake|LHB|composition|Vande Bharat|sp ray/i },
      { q: /catering|pantry|food|khana|khana/i, p: /pantry|catering|food|e-catering|onboard|on-board/i },
      { q: /slip|link coach|attach/i, p: /slip|link|attach|detach/i },
      { q: /halt|stops|route|kahan se kahan|kitne station/i, p: /halt|stop|route|station/i },
      { q: /timing|schedule|kab nikalti|kab pahunchti/i, p: /depart|arriv|timing|schedule/i },
    ];
    /* Section-title leak ("Service It covers..." mein "Service" heading tha)
     * strip karo — paragraph natural shuru ho. */
    const stripSectionTitle = (p: string) => p.replace(/^(Service|Overview|Introduction|Background|History|Route|Timetable|Timing|Rake|Coaches|Loco link|Stops|Facilities|See also|Notes|References)\s+([A-Z])/, "$2");
    for (const t of TOPIC) {
      if (t.q.test(questionText)) {
        const hit = paras.find((p) => t.p.test(p));
        if (hit) {
          return `Web se mila (Wikipedia — ${page.title}): ${stripSectionTitle(hit).slice(0, 700)}\n(Source: ${page.url})\n(Ye railway API ka data nahi, web-scrape ka jawab hai.)`;
        }
      }
    }
    /* Koi topic-match nahi — train ka intro (pehle 2 paragraphs). */
    const intro = paras.slice(0, 2).map(stripSectionTitle).join(" ").slice(0, 800);
    return `Web se mila (Wikipedia — ${page.title}): ${intro}\n(Source: ${page.url})\n(Ye railway API ka data nahi, web-scrape ka jawab hai.)`;
  } catch {
    return null;
  }
}

/* ══ GENERAL TOPIC-PAGE ANSWER (round-4: "jaise ChatGPT answer karta hai").
 * "sabse tez train kaunsi hai" / "railway ki shuruaat kab hui" jaise general
 * sawaal — Hinglish query ko English mein translate karke Wikipedia ka FULL
 * page uthata hai (snippet se kaafi zyada), relevance-verify ke saath. */

import {
  answerFromTopicPage,
  cleanQueryEn,
  GENERIC_WIKI_WORDS,
  HINGLISH_TOPIC_WORDS,
  significantWords,
  TOPIC_EN_WORDS,
  wikiRelevant,
  wordHit,
} from "./topicpage.js";
export { answerFromTopicPage, cleanQueryEn } from "./topicpage.js";

/* (topic-page engine → ./topicpage.ts, Round-15) */

/* ══ GENERAL WEB SCRAPE (round-5: "jaise ChatGPT kahin se bhi scrap karke
 * le aata hai"). Wikipedia/topic-page sab fail → general web search
 * (DDG-lite/Bing) → top relevant pages SCRAPE → question-keyword scored
 * best paragraph → labeled jawab. Sirf universal fallback mein — API/tool
 * ke answer na milne par hi, booking-critical kabhi nahi. */

const RAILWAY_DOMAIN_HINT_RE =
  /irctc|indianrail|erail\.|etrain\.|ixigo|confirmtkt|railyatri|railrestro|findmytrain|travelkhana|zoop|railrecipe|\.in\//i;

async function answerFromWebScrape(questionText: string): Promise<string | null> {
  try {
    if (/\b\d{5}\b/.test(questionText)) return null; // train-number sawaal train-page se
    const contentWords = significantWords(questionText).filter((w) => !HINGLISH_TOPIC_WORDS.has(w));
    const q0 = cleanQueryEn(questionText);
    if (q0.length < 4) return null;
    /* Query: content-words AAGE (engines leading keywords ko heavy weight
     * dete hain) + "indian railways" anchor — warna "railway luggage" par
     * Amtrak/BNSF jaise US results aate hain. */
    const rest = q0.split(/\s+/).filter((w) => w.length >= 3 && !contentWords.includes(w));
    const q = [...contentWords, ...rest.slice(0, 3), "indian railways"].join(" ").slice(0, 120);
    const topicWords = q0.split(/\s+/).filter((w) => TOPIC_EN_WORDS.has(w));
    const genericWords = q0.split(/\s+/).filter((w) => GENERIC_WIKI_WORDS.has(w) && w.length >= 4);
    const results = await generalWebSearch(q, 6);
    if (!results.length) return null;
    /* SNIPPET-RANKING: result ka title+snippet sawaal ke words ko address
     * na kare (US-railway / Amazon-luggage jaisa noise) to SCRAPE hi mat
     * karo — engine ranking par bharosa nahi. Score 0 = filter out. */
    const ranked = results
      .map((r) => {
        const hay = `${r.title} ${r.snippet}`;
        let s = 0;
        for (const w of contentWords) if (wordHit(hay, w)) s += 2;
        for (const w of topicWords) if (wordHit(hay, w)) s += 2;
        for (const w of genericWords) if (wordHit(hay, w)) s += 1;
        if (RAILWAY_DOMAIN_HINT_RE.test(r.url)) s += 2;
        return { r, s };
      })
      .filter((x) => x.s >= 2)
      .sort((a, b) => b.s - a.s)
      .map((x) => x.r);
    if (!ranked.length) return null;
    let best: { para: string; url: string; title: string; score: number } | null = null;
    for (const r of ranked.slice(0, 2)) {
      const text = await scrapeWebPage(r.url);
      if (!text) continue;
      const paras = text
        .split("\n")
        .map((p) => p.replace(/\s+/g, " ").trim())
        .filter((p) => p.length > 60 && p.length < 1200);
      for (const p of paras) {
        let score = 0;
        for (const w of contentWords) if (wordHit(p, w)) score += 3;
        for (const w of topicWords) if (wordHit(p, w)) score += 3;
        for (const w of genericWords) if (wordHit(p, w)) score += 1;
        if (score > (best?.score ?? 0)) best = { para: p, url: r.url, title: r.title, score };
      }
    }
    /* Threshold: kam se kam 2 strong hits (ya 1 content + kuch generic). */
    if (!best || best.score < 6) return null;
    let host = best.url;
    try {
      host = new URL(best.url).hostname.replace(/^www\./, "");
    } catch {
      /* keep url */
    }
    return `Web se scrape karke mila (${host}): ${best.para.slice(0, 700)}\n(Source: ${best.title} — ${best.url})\n(Ye railway API ka data nahi — web-scrape ka jawab hai; important details official source se verify karein.)`;
  } catch {
    return null;
  }
}

/* Round-18m-9 (user: "kitni seats chahiye ye pata ho tabhi train dhoondho"):
 * journey search se PEHLE passenger count — origin+destination+date lock hone ke
 * baad, train-specific (number) sawaal par nahi, info-only follow-ups par nahi. */
/* Round-18m-30f (user: "passenger khud assume kar raha, har baar nahi poochta"): pehle allow-list thi
 * (SEARCH/BOOK/NONE) — station-pick "1" (SELECT_TRAIN), "seat availability", "fastest", "compare",
 * "alternate" jaise turns gate se bach jaate the → pax null → planner 1 assume. Ab EXCLUDE-list: sirf
 * non-journey intents (live/PNR/wallet/schedule/knowledge…) gate skip karte hain; baaki sab route-level
 * journey sawaal (route+date lock, pax unknown, train number nahi) → pehle "kitne passengers?". */
const PAX_GATE_SKIP_INTENTS = new Set(["LIVE_TRAIN_STATUS", "CHECK_PNR", "VIEW_BOOKINGS", "CANCEL_BOOKING", "VIEW_WALLET", "ADD_MONEY", "HELP", "COACH_POSITION", "TRAIN_SCHEDULE", "LIST_CITIES", "RAIL_POLICY", "ABOUT_ASSISTANT", "CANCELLED_TRAINS", "GENERAL_RAILWAY_KNOWLEDGE", "TRAIN_HISTORY", "OUT_OF_DOMAIN", "CONFIRM_YES", "CONFIRM_NO"]);
function passengerGateAsk(ctx: AgentContext, det: { intent?: string | null; trainNumber?: string | null }, text: string, opts: { trainNo?: string | null; stationPick?: unknown } = {}): string | null {
  if (opts.trainNo || det.trainNumber) return null;
  /* Round-43: khaas train selected hai (single-train availability) → pax ki shart nahi — us train ka
   * availability data pax ke bina bhi jawab hai (jaise ChatGPT). Route-level board par gate waise hi. */
  if (ctx.selectedTrainNumber) return null;
  if (!ctx.origin || !ctx.destination || !ctx.date || !ctx.dateProvided) return null;
  if (ctx.paxProvided && ctx.passengers) return null;
  if (PAX_GATE_SKIP_INTENTS.has(String(det.intent ?? "NONE"))) return null;
  /* Round-18m-30f: "alternate route", "connecting route", "route par seat" = journey sawaal (gate lagta hai);
   * sirf "train ka route/stops" (schedule) info-ask skip. "fare/kiraya" bhi party-size par depend karta hai → gate. */
  if (/\b(live|status|kahan hai|platform|timetable|schedule|time table|pnr|coach|cancel)\b/i.test(text) && !opts.stationPick) return null;
  if (/\b(route|stops?)\b/i.test(text) && !/\b(alternate|alternative|connecting|doosra|dusra|via|seat|seats|jaana|jana|ticket|book)\b/i.test(text) && !opts.stationPick) return null;
  const when = ctx.date ? ` ${ctx.date} ko` : "";
  return `${ctx.origin.code} → ${ctx.destination.code}${when} — kitne passengers hain? (1–6) Seats usi hisaab se check karunga.`;
}

function missingOf(known: KnownSlots): string[] {
  const missing: string[] = [];
  if (!known.from) missing.push("from");
  if (!known.to) missing.push("to");
  if (!known.date) missing.push("date");
  if (!known.passengerCount) missing.push("passengers");
  return missing;
}

/* ═══════════════════════════════════════════════════════════════════
 * ROUND-8 (2026-09-06, screenshot-driven fixes):
 *  (a) "nayi baat/reset" topic-switch command
 *  (b) "{train} {station} kitne baje pahunchegi / arrival / reach" —
 *      deterministic arrival-at-station jawab (LLM ise live-status bana
 *      deta tha / "Kahan se jana hai?" pooch deta tha)
 * ═══════════════════════════════════════════════════════════════════ */

/** "nayi baat" / "reset" / "shuru se" — poora context reset. */
const RESET_COMMAND_RE =
  /^(?:(?:nayi|nayaa|naya|navi)\s+(?:baat|baatcheet|topic|shuruaat|shuruat)|reset(?:\s+kar)?(?:\s+(?:do|doon|dijiye|doonga))?(?:\s+do)?|shuru\s+se|start\s+over|fresh\s+start|sab\s+bhul\s+(?:jao|gaye|jaao)|bhul\s+jao\s+sab|naya\s+session)[\s.!]*$/i;

export function isResetCommand(text: string): boolean {
  return RESET_COMMAND_RE.test(String(text ?? "").trim());
}

/** Arrival-at-station sawaal (live-status "kahan hai" isse match nahi hota —
 * "kab/kitne baje + pahunchegi" arrival hai, "kahan hai" live). */
const ARRIVAL_QUESTION_RE =
  /\b(aa?rr?iv\w*|arriv\w*|reach(?:es|ed|ing)?|pahunch\w*|pahuch\w*|pohnch\w*|kitne\s+baje|kab\s+pahunch|what\s+time|kya\s+time|time\s+kya|kab\s+aayegi|eta)\b/i;

/* Token-extraction fillers — inme se koi station nahi hota. */
const ARRIVAL_FILLER = new Set([
  "ka","ki","ke","ko","kya","kitne","kitna","kitni","baje","batao","btao","btana","btado","bata","batado","hai","hain","hogi","hoga","hongi","kar","karo","kab","time","sirf","bass","bas","meri","mera","tell","me","please","train","trains","se","par","pe","pr","at","what","the","of","in","on","is","ye","yeh","wali","wala","aaj","kal","jaa","jana","jaana","gaadi","gadi","express","mail","superfast","rajdhani","shatabdi","vande","jan","spl","cc","ec","sl","ea","2a","3a","1a","gen","general","ac","chair","car","sleeper","pahunchegi","pahunchega","pahuchegi","pahuchega","pahunchne","pahuchne","pahunchti","pahunchta","pahunchengi","pahunchenge","arrival","arrive","arrives","reach","reaches","reached","will","would","she","he","it","this","that","when","how","much","hour","hours","der","late","approximately","approx","around","about","mujhe","hai","ka","ki","tha","thi","the","hui","hua","gaya","gayi","pahunchi","pahuncha","pahunche","pohnchi","pohncha","pahonchi","pahuncha","there","it's","completed","run","trip","journey","date","tareekh","ko","ki","se",
]);

/** Train-number hatake, filler hatake bache hue alpha tokens — inhe schedule
 * stops ke codes/naamon se match karenge (code "cdg" ya naam "chandigarh"). */
function arrivalStationTokens(text: string): string[] {
  const t = String(text ?? "").replace(/\d{5}/g, " ").toLowerCase();
  return (t.match(/[a-z\u0900-\u097F]{2,}/g) ?? []).filter((w) => !ARRIVAL_FILLER.has(w));
}

export type ArrivalBinary = {
  reply: string;
  trainNumber: string;
  trainName: string | null;
};

export type ArrivalAtStation = {
  reply: string;
  trainNumber: string;
  trainName: string | null;
};

/* ── Round-11 (screenshot 2026-09-07): "12411 kya ludhiana departure kar
 * gyi?" — app pehle SEARCH_TRAIN bana raha tha ("Kahan jaana hai?" /
 * '"Depart" ke liye exact station chahiye'). Deterministic direct jawab:
 * live position + route-order se Haan/Abhi-nahi, schedule se dep-time. */
const DEPART_QUESTION_RE =
  /\bdepart(?:ed|ure)?\b|(?:nikal|nikli|chhoot|chhuti|chali)\s+(?:chuki|chuka|gayi|gyi)|(?:nikli|chali|chalta|chalti|chalte)\s+hai|(?:niklegi|niklega|niklengi|niklenge)|kab\s+(?:chalti|chalta|chalte|nikalti|nikalta)/i;

const DEPART_VERB_WORDS = new Set([
  "depart", "departed", "departure", "nikal", "nikli", "nikalna", "nikalke", "chali", "chhoot", "chhuti", "chuki", "chuka", "gayi", "gyi", "niklegi", "niklega", "niklengi", "niklenge", "kya", "abhi", "ho", "hui", "tha", "thi", "waqt", "se",
]);

export type DepartureFromStation = {
  reply: string;
  trainNumber: string;
  trainName: string | null;
};

export async function departureFromStationTurn(
  text: string,
  ctx: AgentContext,
): Promise<DepartureFromStation | null> {
  const raw = String(text ?? "");
  if (!DEPART_QUESTION_RE.test(raw)) return null;
  const trainNo = resolveTrainNumber(raw, ctx);
  if (!trainNo) return null;
  const tokens = arrivalStationTokens(raw).filter((w) => !DEPART_VERB_WORDS.has(w));
  if (tokens.length === 0) return null;

  /* Route (schedule) — asked stop dhundhne + dep-time ke liye. */
  const sched = await routedSchedule(trainNo);
  const stops = sched.schedule && "stops" in sched.schedule ? sched.schedule.stops ?? [] : [];
  const clean = (s: string) => s.toLowerCase().replace(/[^a-z\u0900-\u097F]/g, "");
  const matchStop = (tok: string) =>
    stops.find(
      (st) =>
        st.code.toLowerCase() === tok ||
        (tok.length >= 4 && (clean(st.name).includes(clean(tok)) || clean(st.name).startsWith(clean(tok)))),
    );
  let stop: (typeof stops)[number] | null = null;
  for (const tok of tokens) {
    const m = matchStop(tok);
    if (m) stop = m;
  }
  if (!stop) {
    /* Round-45: route me nahi hone wala station — "se chalti hi nahi" (warna live dump aa jaata tha). */
    const chk = await checkStationsOnRoute(trainNo, {}, raw).catch(() => null);
    if (chk && chk.stops.length >= 2 && chk.bad) {
      const name0 = "trainName" in (sched.schedule ?? {}) ? String((sched.schedule as { trainName?: string }).trainName ?? "") : "";
      return { reply: `${trainNo}${name0 ? ` ${name0}` : ""} — ${routeMismatchTail(chk.bad, "se chalti hi nahi")}`, trainNumber: trainNo, trainName: name0 || null };
    }
    return null; // station resolve hi nahi hua — normal flow honest jawab dega
  }
  const name = "trainName" in (sched.schedule ?? {}) ? String((sched.schedule as { trainName?: string }).trainName ?? "") : "";
  const depTime = stop.departure && !(stop === stops[stops.length - 1] && stop.departure === "00:00") ? stop.departure : null;

  const routed = await routedLiveStatus(trainNo);
  const live = routed.live as
    | { trainName?: string; status?: string; currentStation?: string | null; nextStation?: string | null; delayMinutes?: number | null }
    | null;
  const norm = (s: string) => s.toLowerCase().replace(/junction|jn\b|[^a-z]/g, "");
  const title = live?.trainName?.trim() || name || "";

  /* 1) NTES-style status: "Departed from LUDHIANA JN(LDH) at 09:11" — seedha
   *    evidence: HAAN + nikalne ka waqt. */
  const dep = /departed\s+from\s+([^(]+?)\s*\((\w+)\)\s*at\s*([\d:]+)/i.exec(String(live?.status ?? ""));
  if (dep && (norm(dep[1]) === norm(stop.name) || dep[2].toLowerCase() === stop.code.toLowerCase())) {
    const extra = live && live.currentStation && norm(live.currentStation) !== norm(stop.name) ? ` Abhi: current status ${live.currentStation}${live.nextStation ? `, next ${live.nextStation}` : ""}.` : "";
    return {
      reply: `Haan — ${trainNo}${title ? ` ${title}` : ""} ${stop.name} se ${dep[3]} par nikal chuki hai.${live?.delayMinutes != null ? ` (delay ~${live.delayMinutes} min)` : ""}${extra}`,
      trainNumber: trainNo,
      trainName: title || null,
    };
  }

  /* 2) Live current position vs asked stop — route-order se Haan/Abhi-nahi. */
  if (live?.currentStation) {
    /* Round-11b: live aur schedule ke naam alag hote hain ("Jalandhar Cant"
     * vs "JALANDHAR CITY") — station-type suffix strip karke match karo,
     * warna order compare hi nahi hota tha. */
    const strip = (s: string) => norm(s).replace(/(?:city|cantt|cant|junction|jn|terminal|road|east|west|north|south)+$/g, "");
    const curNorm = norm(live.currentStation);
    const curBase = strip(live.currentStation);
    const curIdx = stops.findIndex((st) => {
      const n = norm(st.name);
      if (n === curNorm) return true;
      if (curNorm.length >= 5 && (n.startsWith(curNorm) || curNorm.startsWith(n))) return true;
      const b = strip(st.name);
      return b.length >= 5 && curBase.length >= 5 && (b === curBase || b.startsWith(curBase) || curBase.startsWith(b));
    });
    const askedIdx = stops.findIndex((st) => st === stop);
    if (curIdx >= 0 && askedIdx >= 0) {
      const nextBit = live.nextStation ? `, next ${live.nextStation}` : "";
      const delayBit = live.delayMinutes != null ? `, delay ${live.delayMinutes} min` : "";
      if (askedIdx === curIdx) {
        return {
          reply: `Abhi nahi — ${trainNo}${title ? ` ${title}` : ""} is waqt ${stop.name} par hai (current status${delayBit})${nextBit}.${depTime ? ` ${stop.name} se ${depTime} ka departure hai.` : ""}`,
          trainNumber: trainNo,
          trainName: title || null,
        };
      }
      if (askedIdx < curIdx) {
        return {
          reply: `Haan — ${trainNo}${title ? ` ${title}` : ""} ${stop.name} cross kar chuki hai. Abhi: current status ${live.currentStation}${nextBit}${delayBit}.${depTime ? ` (${stop.name} se scheduled ${depTime})` : ""}`,
          trainNumber: trainNo,
          trainName: title || null,
        };
      }
      return {
        reply: `Abhi nahi — ${trainNo}${title ? ` ${title}` : ""} abhi ${live.currentStation} par hai${nextBit}${delayBit}.${stop.name} abhi baaki hai${depTime ? ` — wahan se ${depTime} ka departure hai` : ""}.`,
        trainNumber: trainNo,
        trainName: title || null,
      };
    }
    /* 3) Current position route mein nahi mili — live position bata do. */
    const position = livePositionLabel(live);
    return {
      reply: `${trainNo}${title ? ` ${title}` : ""} — ${live.status ?? ""}${position ? `, ${position}` : ""}${live.nextStation ? `, next ${live.nextStation}` : ""}.${depTime ? ` ${stop.name} se scheduled departure ${depTime}.` : ""}`,
      trainNumber: trainNo,
      trainName: title || null,
    };
  }

  /* 4) Live nahi mila — schedule se honest jawab. */
  return {
    reply: `${trainNo}${title ? ` ${title}` : ""} — live position abhi provider se nahi mili${depTime ? `, par schedule ke hisaab se ${stop.name} se ${depTime} ka departure hai` : ` (${stop.name} route mein hai)`}.${webSourceLabel(sched.provider)}`,
    trainNumber: trainNo,
    trainName: title || null,
  };
}


/** Deterministic arrival-at-station jawab — screenshot ke saare cases:
 * "18310 cdg kitne baje pahunchegi?", "18310 ka cdg arrival btao",
 * "Sirf cdg ka btao kitne baje arrival hai" (context-train), "At what time
 * 18310 reach chandigarh". Confidence-gated: arrival-words + train + ek token
 * jo route ke kisi stop se match ho — warna normal flow. */
/** User ne jo din bola (27 sept / kal / aaj / 27/09) usse run-date label — jawab me saaf rahe ki
 * kis run ke liye baat ho rahi hai. Kuch na mila to null. */
export function runDateLabel(text: string, nowIso?: string | null): string | null {
  const t = String(text ?? "").toLowerCase();
  const baseMs = nowIso && Date.parse(nowIso) ? Date.parse(nowIso) + 5.5 * 3600 * 1000 : Date.now() + 5.5 * 3600 * 1000;
  const IST = 24 * 3600 * 1000;
  const MON = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  const fmt = (ms: number) => `${new Date(ms).getUTCDate()} ${MON[new Date(ms).getUTCMonth()]} ${new Date(ms).getUTCFullYear()}`;
  const named = /\b(\d{1,2})\s*(jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)[a-z]*\b/i.exec(t);
  if (named) {
    const d = Number(named[1]);
    const mi = MON.findIndex((m) => m.toLowerCase() === named[2].slice(0, 3).toLowerCase());
    if (d >= 1 && d <= 31 && mi >= 0) {
      const year = Number(/\b(20\d\d)\b/.exec(t)?.[1] ?? new Date(baseMs).getUTCFullYear());
      return `${d} ${MON[mi]} ${year}`;
    }
  }
  const numeric = /\b(\d{1,2})[\/\-](\d{1,2})(?:[\/\-](\d{2,4}))?\b/.exec(t);
  if (numeric) {
    const d = Number(numeric[1]);
    const mo = Number(numeric[2]);
    if (d >= 1 && d <= 31 && mo >= 1 && mo <= 12) {
      let y = numeric[3] ? Number(numeric[3]) : new Date(baseMs).getUTCFullYear();
      if (y < 100) y += 2000;
      return `${d} ${MON[mo - 1]} ${y}`;
    }
  }
  if (/\b(parso|parson)\b/.test(t)) return fmt(baseMs - 2 * IST);
  if (/\b(kal|yesterday|gayi?kal)\b/.test(t)) return fmt(baseMs - IST);
  if (/\b(aaj|today|aj)\b/.test(t)) return fmt(baseMs);
  return null;
}

/** Station par rukne ki der (halt) ka sawaal — wahi family (particular station ka time). */
const HALT_QUESTION_RE = /\b(kitni der ruk\w*|kitna (?:halt|rukna|thahrav)|halting|halt time|rukne ka time|der rukt\w*)\b/i;

/** Sirf tab deterministic arrival jawab do jab sawaal SAAF arrival ka ho — warna (seat/fare/book/live/
 * plan/list wale mixed sawaal) model hi handle kare. */
export function simpleArrivalQuestion(text: string): boolean {
  const t = String(text ?? "");
  if (!ARRIVAL_QUESTION_RE.test(t) && !HALT_QUESTION_RE.test(t)) return false;
  /* Binary/live sawaal ("pahunch gayi kya?") — us par live jawab chahiye, timetable ka time nahi. */
  if (/\b(pahunch\s*(?:gayi|gaya|chuki|chuka)|(?:gayi|gaya)\s*kya|pahunch\s*gaya\s*kya|aa\s*gayi\s*kya)\b/i.test(t)) return false;
  return !/\b(seat|seats|berth|availab\w*|avl|rac|wl|waitlist|fare|kiraya|book\w*|ticket|confirm|pnr|platform|coach|live|kahan hai|kaha hai|kahaan hai|late|delay|status|plan|alternative|options?|list|alawa|ilaava|trains?\s+batao|kaunsi)\b/i.test(t);
}

/** "27 Sep 2026" jaisa label → ISO (2026-09-27). Label na bane to null. */
function isoOfLabel(label: string, nowIso?: string | null): string | null {
  const m = /^(\d{1,2})\s+([A-Za-z]{3})\s+(\d{4})$/.exec(label.trim());
  if (!m) return null;
  const MON = ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"];
  const mi = MON.indexOf(m[2].toLowerCase());
  if (mi < 0) return null;
  return `${m[3]}-${String(mi + 1).padStart(2, "0")}-${String(Number(m[1])).padStart(2, "0")}`;
}

export async function arrivalAtStationTurn(
  text: string,
  ctx: AgentContext,
  nowIso?: string | null,
): Promise<ArrivalAtStation | null> {
  const raw = String(text ?? "");
  if (!ARRIVAL_QUESTION_RE.test(raw) && !HALT_QUESTION_RE.test(raw)) return null;
  const trainNo = resolveTrainNumber(raw, ctx);
  if (!trainNo) return null;
  const tokens = arrivalStationTokens(raw);
  if (tokens.length === 0) return null;

  const routed = await routedSchedule(trainNo);
  const schedule = routed.schedule;
  if (!schedule || !("stops" in schedule) || !schedule.stops?.length) return null;
  const stops = schedule.stops;

  const clean = (s: string) => s.toLowerCase().replace(/[^a-z\u0900-\u097F]/g, "");
  const matchStop = (tok: string) =>
    stops.find(
      (st) =>
        st.code.toLowerCase() === tok ||
        (tok.length >= 4 &&
          (clean(st.name).includes(clean(tok)) || clean(st.name).startsWith(clean(tok)))),
    );

  /* Multiple tokens match karein (jaise "jammu se cdg") to LAST wala —
   * "X se Y pahunchegi" mein destination aakhri aata hai. */
  let stop: (typeof stops)[number] | null = null;
  for (const tok of tokens) {
    const m = matchStop(tok);
    if (m) stop = m;
  }
  if (!stop) {
    /* Round-45: station is train ke route me hi nahi (jaise "12013 haridwar arrival kitne baje") —
     * pehle ye null deta tha aur normal flow "Kahan jaana hai?" poochh leta tha. Ab seedha sach. */
    const chk = await checkStationsOnRoute(trainNo, {}, raw).catch(() => null);
    if (chk && chk.stops.length >= 2 && chk.bad) {
      const name0 = "trainName" in schedule ? String(schedule.trainName ?? "") : "";
      return { reply: `${trainNo}${name0 ? ` ${name0}` : ""} — ${routeMismatchTail(chk.bad)}`, trainNumber: trainNo, trainName: name0 || null };
    }
    return null;
  }

  /* Source-stop par arrival 00:00 API placeholder hai — hide. */
  const isSource = stops[0] === stop;
  const isLast = stops[stops.length - 1] === stop;
  const arr = stop.arrival && !(isSource && stop.arrival === "00:00") ? stop.arrival : null;
  const dep = stop.departure && !(isLast && stop.departure === "00:00") ? stop.departure : null;
  if (!arr && !dep) return null;
  const dayTag = typeof (stop as { day?: number }).day === "number" && (stop as { day?: number }).day! > 1 ? ` (Day ${(stop as { day?: number }).day})` : "";
  const timing = [arr ? `arrival ${arr}` : null, dep ? `departure ${dep}` : null]
    .filter(Boolean)
    .join(", ");
  const name = "trainName" in schedule ? String(schedule.trainName ?? "") : "";
  /* Round-44: user ne din bola ho to uski run ka label — "timetable ke hisaab se" (scheduled).
   * YAHI format screenshot me pasand aaya; model/judge dono ke liye saaf. */
  const dateLabel = runDateLabel(raw, nowIso);
  const datePart = dateLabel ? `${dateLabel} ki run ke liye ` : "";
  /* Halt ka sawaal ho to rukne ki der bhi saaf likho (arr→dep se; schedule ke hisaab se). */
  const haltPart = /\b(kitni der ruk\w*|kitna (?:halt|rukna|thahrav)|halting|halt time|rukne ka time|der rukt\w*)\b/i.test(raw) && arr && dep
    ? (() => {
        const mins = (h: number, m: number) => h * 60 + m;
        const [ah, am] = arr.split(":").map(Number);
        const [dh, dm] = dep.split(":").map(Number);
        const dur = mins(dh, dm) - mins(ah, am);
        return dur > 0 ? ` — halt ~${dur} min` : "";
      })()
    : "";
  return {
    reply: `${trainNo}${name ? ` ${name}` : ""} — ${datePart}timetable ke hisaab se: ${stop.name} (${stop.code}): ${timing}${haltPart}${dayTag}.${webSourceLabel(routed.provider)}`,
    trainNumber: trainNo,
    trainName: name || null,
  };
}

/** ── Round-44: "train X par rukti hai kya?" — haan/na ka sawaal, route ke sach se ────────────────
 * Haan → us stop ka arr/dep; nahi → saaf "is route me nahi" (+ isi shehar ka route-station, agar ho). */
const STOPPING_Q_RE = /\b(ruk(?:ti|ta|na|ne|w?ti)?|stop(?:s|ping)?|halt)\b/i;

/** ── Round-45: route-mismatch ka saaf jawab — jab poochha gaya station us train ke route me hi nahi hai.
 * Arrival / binary ("pahunch gayi kya") / departure — teeno ka ek hi sach: nahi rukti, route kya hai,
 * aur (mile to) usi shehar ka route-par wala station. (R43e rule: jhoothi seat/board listing nahi.) */
type RouteBad = { code: string; name?: string | null; first: string; last: string; nearby?: { code: string; name?: string | null } };
function routeMismatchTail(bad: RouteBad, verb = "par rukti hi nahi"): string {
  const sib = bad.nearby ? ` Isi shehar ka ${bad.nearby.code}${bad.nearby.name ? ` (${bad.nearby.name})` : ""} route par hai.` : "";
  return `${bad.code}${bad.name ? ` (${bad.name})` : ""} ${verb} (is train ka route ${bad.first} → ${bad.last} hai).${sib}`;
}

/** Round-45: model kai baar saaf sawaal (train + station diya hua) par bhi khokhla jawab de deta hai —
 * "Kahan jaana hai? Station bataiye." (R44 screenshots ki jadd). Aisa jawab tabhi badla jaata hai jab
 * hamare paas usi sawaal ka VERIFIED deterministic jawab maujood ho (arrival/live/seat handlers) —
 * warna model ka jawab hi jaata hai. AI-first wahi rehta hai: model pehle chalta hai. */
const EVASIVE_REPLY_RE =
  /\b(kahan\s+se\s+(?:jaana|jana)|kahan\s+(?:jaana|jana)\s+hai|station\s+batai?ye|station\s+batao|kaunsi\s+station|kis\s+station|train\s+(?:number|no\.?)\s+batai?ye|train\s+batai?ye|which\s+(?:train|station))\b/i;
function isEvasiveReply(reply: string): boolean {
  const r = String(reply ?? "").trim();
  return r.length <= 200 && EVASIVE_REPLY_RE.test(r);
}

/** Round-45: sawaal ki QISM — adequacy net isi par decide karta hai ki model ka jawab "us sawaal ka
 * jawab" hai ya nahi. Ye per-question rule nahi hai (R43k), sirf 3 qismein: seat / arrival-family / live. */
type AnswerKind45 = "seat" | "arrival" | "live" | "pick";
/** Round-59 (user: "connecting trains are not showing leg 1 and leg 2"): plan ka saaf ishaara.
 *  Client ke plan-page ka text isi phrasing par chalta hai ("… ka poora plan banao — …") aur chat me bhi
 *  user yahi bolta hai. Ye LIST nahi hai — do-tuk wala pattern hai, isliye naye sawaalon par bhi chalta hai. */
export function isPlanAsk(text: string): boolean {
  const t = String(text ?? "");
  return /\b(poora|poori|pura|puri)\s+plan\b/i.test(t) || /\bplan\s+(bana|banao|banado|banade|bna)/i.test(t);
}

/** ── Round-60 (user: "ambiguous station pe ab choice nahi aati") ─────────────────────────────────────
 * Jab model khud city ko ek station maan leta hai (jaise "Delhi" → NDLS) aur text me "kaunsa station?"
 * bhi poochh leta hai, tab UI me dropdown nahi aata tha — kyunki choice payload sirf us waqt banta tha jab
 * NLU city ko UNRESOLVED chhodta tha. Yahan wahi check hai, per-question rule nahi:
 *   • slot (from/to) city-level naam ho (station ka poora naam ya code text me na ho), aur
 *   • us city me 2+ station ho (asli provider data se — wahi source jo deterministic path use karta hai),
 * to wahi dropdown banao. Station ka exact naam/code likha ho to kuch nahi poochhte (koi extra sawaal nahi).
 */
export async function cityStationAmbiguity(
  slots: { from?: Station | null; to?: Station | null },
  text: string,
  search: (city: string) => Promise<{ stations: Station[] }> = routedStationSearch,
): Promise<ChoiceBlock | null> {
  const t = String(text ?? "");
  const esc = (x: string) => x.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  for (const slot of ["to", "from"] as const) {
    const st = slot === "to" ? slots.to : slots.from;
    const code = String(st?.code ?? "").trim();
    const city = String(st?.city ?? "").trim();
    const name = String(st?.name ?? "").trim();
    if (!code || !city) continue;
    /* Station-level naam (New Delhi / Hazrat Nizamuddin / NDLS) likha ho → ambiguity nahi. */
    if (city.toLowerCase() === name.toLowerCase()) continue;
    if (new RegExp(`\\b${esc(code)}\\b`, "i").test(t)) continue;
    if (name && new RegExp(esc(name), "i").test(t)) continue;
    const res = await search(city).catch(() => null);
    const stations = res?.stations ?? [];
    if (stations.length < 2) continue; /* ek hi station — poochhne ka matlab nahi */
    return {
      kind: "station",
      title: `${city} — kaunsa station?`,
      options: stations.slice(0, 8).map((s) => ({ label: `${s.code} – ${s.name}`, value: s.code, sub: null })),
      sendTemplate: "{value}",
    };
  }
  return null;
}

export function answerKind45(text: string): AnswerKind45 | null {
  const t = String(text ?? "");
  if (/\b(seat|seats|berth|availab\w*|avl|rac|waitlist|wk|wl|confirmation)\b/i.test(t) && /\b\d{4,5}\b/.test(t)) return "seat";
  if (
    BINARY_ARRIVAL_RE.test(t) ||
    ARRIVAL_QUESTION_RE.test(t) ||
    HALT_QUESTION_RE.test(t) ||
    STOPPING_Q_RE.test(t) ||
    DEPART_QUESTION_RE.test(t) ||
    /\b(kab\s+pahunch\w*|kitne\s+baje\s+pahunch\w*)\b/i.test(t)
  ) return "arrival";
  if (/\b(kahan\s+hai|kahaan\s+hai|kaha\s+hai|abhi\s+kahan|kahan\s+tak|kahan\s+pahunchi|live\s+status|running\s+status|late\s+hai|delayed|delay\s+hai)\b/i.test(t)) return "live";
  return null;
}

/** Model ka jawab us sawaal ka jawab hai ya nahi — REAL data wali cheez dhoondo, lafzon ka jaal nahi.
 *  seat    → availability ka data (AVAILABLE/WL/RAC/₹/N/A)
 *  arrival → sawaal ka station (code/naam) + waqt, ya saaf "rukuti/chalti hi nahi" (route ka sach)
 *  live    → waqt/position (ya "start hi nahi hua" wali line)
 * Jawab na ho to null na do — neeche deterministic rescue (verified tool data) chalega. */
export function replyAdequateFor45(kind: AnswerKind45, reply: string, question: string): boolean {
  const r = String(reply ?? "").trim();
  if (!r) return false;
  if (isEvasiveReply(r)) return false;
  if (kind === "seat") return /availab|rac|waitlist|\bwl\b|₹|rs\.?\s*\d|n\/a/i.test(r);
  /* Round-55 (pick): chunne wale sawaal ka jawab = EK winner (naam/number) + "kyun" — poora dump nahi. */
  if (kind === "pick") {
    /* R56b: pehle gate sirf "best"-jaise shabd maangta tha — "inme se 2nd wala kaunsa hai" / "sasti kaunsi"
     * jaise chunav par model ka SAHI chhota jawab bhi khokhla maan kar replace ho jaata tha. Ab do raste:
     * (a) chunav ka lafz ho, ya (b) candidate ka asli data ho (AVL/WL/₹) — dono soorat me jawab chhota (≤3 trains). */
    const nums = [...new Set(r.match(/\b\d{5}\b/g) ?? [])];
    if (nums.length === 0) return false;
    const namesIt = /best|sabse|behtar|recommend|suggest|सबसे|सुझाव|yeh\s+(?:le|lo|book)|isko\s+book|pehla|doosra|dusra|2nd|second|kaunsi|kaun\s*si/i.test(r);
    const hasData = /availab|rac|waitlist|\bwl\b|n\/a|₹/i.test(r);
    /* Chunav wala lafz ho to chhota ranked jawab (best + runner-up + 1-2 aur) bhi theek hai; lafz na ho
     * to data wala ek-do number. Poora board dump (kai trains, "sab dekho") khokhla hi hai. */
    const maxNums = namesIt ? 6 : hasData ? 3 : 1;
    return nums.length <= maxNums && (namesIt || hasData);
  }
  /* Route ka sach (nahi rukti/chalti) — khud me poora jawab hai. */
  if (/ruk(?:ti|ta)\s+hi\s+nahi|chalti\s+hi\s+nahi|nahi\s+ruk(?:ti|ta)|route\s+[A-Z]{2,5}\s*(?:→|->)/i.test(r)) return true;
  if (kind === "live") {
    /* Live jawab: waqt, delay ya asli POSITION ("LUDHIANA JN ke aage, delay 6 min, agla stop UMB"). */
    return /\b\d{1,2}:\d{2}\b|delay\s*\d|\d+\s*(?:min|minute)s?\s*(?:late|delay)|ke\s+(?:aage|paas|peeche)|agla\s+stop|next\s+stop|pahunch\s+(?:gayi|chuki)|nahi\s+pahunchi|start\s+(?:ho|chuka|hota)|\brunning\b|chalu/i.test(r);
  }
  /* Arrival: sawaal ka STATION (code/naam) + waqt/pahunchne ka sach — warna wo us sawaal ka jawab nahi. */
  const asked = arrivalStationTokens(question);
  const low = r.toLowerCase();
  const mentionsStation = !asked.length || asked.some((tok) => tok.length >= 3 && low.includes(tok.slice(0, 3)));
  const hasData = /\b\d{1,2}:\d{2}\b/.test(r) || /pahunch\s+(?:gayi|chuki|gaya|chuka)|nahi\s+pahunchi|pahunch\s+chuki/i.test(r);
  return mentionsStation && hasData;
}

/** Round-45 rescue: us sawaal ki qism ke hisaab se pehla milne wala VERIFIED deterministic jawab. */
/* ── Round-55: "in me se best kaunsi?" ka VERIFIED jawab ─────────────────────────────────────────────
 * Candidates = pichhle jawab me likhi trains (wahi list jo user ne dekhi). Unka live re-check hota hai
 * (wahi route/date/class), phir data se EK winner chuna jaata hai — sabse zyada confirmed seat, phir
 * jaldi departure; seat na ho to kam WL; uske baad RAC. Jawab me 1 line "kyun" + runner-up. Kuch bhi
 * banaya nahi — sab tool ke rows se. */
export async function pickBestTurn(req: AgentRequest, seeded: AgentContext): Promise<AgentResponse | null> {
  const text = String(req.text ?? "");
  const cands = previousListTrains(req.history);
  if (!isPickFollowup(text, req.history)) return null;
  const from = seeded.origin?.code ?? req.known?.from?.code ?? null;
  const to = seeded.destination?.code ?? req.known?.to?.code ?? null;
  const date = seeded.date ?? req.known?.date ?? null;
  if (!from || !to || !date) return null;
  const cls = (text.match(/\b(1A|2A|3A|3E|2S|SL|CC|EC|FC|1E)\b/i)?.[1] ?? seeded.classCode ?? "ALL").toUpperCase();
  const res = (await runFindSeatsTool({
    from,
    to,
    date,
    class_code: cls === "ALL" ? "ALL" : cls,
    train_numbers: cands,
    only_available: false,
  })) as {
    ok: boolean;
    source: string | null;
    summary: string;
    data: { rows: SeatRowLike[]; wlRows: SeatRowLike[]; trainsSeen?: number; classCodes?: string[] };
  };
  if (!res?.ok) return null;
  type Pick = SeatRowLike;
  const all: Pick[] = [...(res.data.rows ?? []), ...(res.data.wlRows ?? [])];
  if (!all.length) return null;
  const rank = (r: Pick) => (r.status === "AVAILABLE" ? 0 : r.status === "RAC" ? 1 : r.status === "WAITLIST" ? 2 : 3);
  const depMin = (r: Pick) => {
    const m = /^(\d{1,2}):(\d{2})/.exec(String(r.departure ?? ""));
    return m ? Number(m[1]) * 60 + Number(m[2]) : 9999;
  };
  const sorted = [...all].sort((a, b) => {
    if (rank(a) !== rank(b)) return rank(a) - rank(b);
    if (a.status === "AVAILABLE" && b.status === "AVAILABLE") {
      if ((b.seats ?? 0) !== (a.seats ?? 0)) return (b.seats ?? 0) - (a.seats ?? 0);
      if (depMin(a) !== depMin(b)) return depMin(a) - depMin(b);
      if ((a.durationMinutes ?? 1e9) !== (b.durationMinutes ?? 1e9)) return (a.durationMinutes ?? 1e9) - (b.durationMinutes ?? 1e9);
      return (a.fare ?? 1e9) - (b.fare ?? 1e9);
    }
    if (a.status === "RAC" && b.status === "RAC") return (b.rac ?? 0) - (a.rac ?? 0);
    if (a.status === "WAITLIST" && b.status === "WAITLIST") return (a.waitlist ?? 99) - (b.waitlist ?? 99);
    return depMin(a) - depMin(b);
  });
  const win = sorted[0];
  const second = sorted.find((r) => r.number !== win.number) ?? null;
  const clsText = (r: Pick) =>
    r.status === "AVAILABLE"
      ? `${r.classCode} AVL ${r.seats ?? "?"}${r.fare != null ? ` · ₹${r.fare}` : ""}`
      : r.status === "RAC"
        ? `${r.classCode} RAC ${r.rac ?? "?"}${r.fare != null ? ` · ₹${r.fare}` : ""}`
        : r.status === "WAITLIST"
          ? `${r.classCode} WL ${r.waitlist ?? "?"}${r.fare != null ? ` · ₹${r.fare}` : ""}`
          : `${r.classCode} N/A${r.fare != null ? ` · ₹${r.fare}` : ""}`;
  const why: string[] = [];
  if (win.status === "AVAILABLE") {
    why.push("is list me sabse zyada confirmed seats");
    if (win.departure) why.push(`departure ${win.departure}`);
    if (win.durationMinutes != null) why.push(`${Math.floor(win.durationMinutes / 60)}h ${String(win.durationMinutes % 60).padStart(2, "0")}m ka safar`);
  } else if (win.status === "RAC") {
    why.push("baaki sab WL/N-A — isme RAC mil raha hai");
  } else if (win.status === "WAITLIST") {
    why.push(`is waqt kisi me confirmed seat nahi — sabse kam WL (${win.waitlist ?? "?"})`);
  } else {
    why.push("is waqt in trains me seat hi nahi (N/A) — ye list sabse kam kharab hai");
  }
  const head =
    win.status === "AVAILABLE"
      ? `**Best: ${win.number} ${win.name} — ${clsText(win)}${win.departure ? ` · ${win.departure} departure` : ""}**`
      : `**Sabse behtar (is waqt): ${win.number} ${win.name} — ${clsText(win)}${win.departure ? ` · ${win.departure}` : ""}**`;
  const lines = [head, `Kyun: ${why.join(", ")}.`];
  if (second) lines.push(`Runner-up: ${second.number} ${second.name} — ${clsText(second)}${second.departure ? ` · ${second.departure}` : ""}.`);
  lines.push(`(Ye wahi ${cands.length} trains hain jo pichhle jawab me thi — abhi live re-check kiya gaya.)`);
  lines.push(`[NEXT] Book ${win.number}${/[A-Z0-9]{2,3}/.test(win.classCode) ? ` · ${win.classCode}` : ""} => ${win.number} ${win.classCode} seat book krdo`);
  const drop = /ROUTE:\s*(.+)/.exec(String(res.summary ?? ""))?.[1] ?? null;
  return {
    source: "agentic_model" as never,
    nlu: undefined,
    context: { ...seeded, classCode: cls === "ALL" ? seeded.classCode : cls },
    tool: "FIND_SEATS" as never,
    toolOk: true,
    reply: lines.join("\n"),
    seatCapture: {
      from,
      to,
      date,
      rows: res.data.rows ?? [],
      wlRows: res.data.wlRows ?? [],
      source: res.source,
      dropNote: drop ? `ℹ️ ${drop.trim()}` : null,
      nearbyNote: null,
      trainsSeen: res.data.trainsSeen ?? all.length,
      onlyAvailable: false,
      classCodes: res.data.classCodes ?? [],
    },
  } as unknown as AgentResponse;
}

async function deterministicRescue45(kind: AnswerKind45 | null, req: AgentRequest, seeded: AgentContext): Promise<AgentResponse | null> {
  const order: Array<() => Promise<AgentResponse | null>> =
    kind === "pick"
      ? [() => pickBestTurn(req, seeded), () => singleTrainSeatTurn(req, seeded)]
      : kind === "seat"
      ? [() => singleTrainSeatTurn(req, seeded), () => arrivalFamilyTurn(req, seeded), () => livePrecheckTurn(req)]
      : kind === "live"
        ? [() => livePrecheckTurn(req), () => arrivalFamilyTurn(req, seeded), () => departureTurn(req, seeded)]
        : [() => arrivalFamilyTurn(req, seeded), () => departureTurn(req, seeded), () => livePrecheckTurn(req), () => singleTrainSeatTurn(req, seeded)];
  for (const fn of order) {
    const r = await fn().catch(() => null);
    if (r) return r;
  }
  return null;
}

export async function stoppingQuestionTurn(
  text: string,
  ctx: AgentContext,
): Promise<{ reply: string; trainNumber: string; trainName: string | null } | null> {
  const raw = String(text ?? "");
  if (!STOPPING_Q_RE.test(raw)) return null;
  if (/\b(kitni der|kitna (?:halt|rukna|thahrav)|halt time|rukne ka time)\b/i.test(raw)) return null; /* halt-duration → arrival handler */
  if (/\b(kahan|kaha|kahaan|live|late|delay|status|seat|fare|platform|coach)\b/i.test(raw)) return null;
  const trainNo = resolveTrainNumber(raw, ctx);
  if (!trainNo) return null;
  const chk = await checkStationsOnRoute(trainNo, {}, raw).catch(() => null);
  if (!chk || chk.stops.length < 2) return null;
  const sched = await routedSchedule(trainNo).catch(() => null);
  const name = sched?.schedule && "trainName" in sched.schedule ? String((sched.schedule as { trainName?: string }).trainName ?? "") : "";
  if (chk.bad) {
    const sib = chk.bad.nearby ? ` Isi shehar ka ${chk.bad.nearby.code}${chk.bad.nearby.name ? ` (${chk.bad.nearby.name})` : ""} route par hai.` : "";
    return {
      reply: `${trainNo}${name ? ` ${name}` : ""} — nahi, ${chk.bad.code} par rukti nahi (is train ka route ${chk.bad.first} → ${chk.bad.last} hai).${sib}`,
      trainNumber: trainNo,
      trainName: name || null,
    };
  }
  /* Kaunse stop poochhe gaye? — SAARE matched tokens (multi-station sawaal bhi), duplicate nahi. */
  const tokens = arrivalStationTokens(raw);
  const clean = (x: string) => x.toLowerCase().replace(/[^a-z\u0900-\u097F]/g, "");
  const asked: typeof chk.stops = [];
  for (const st of chk.stops) {
    const code = String(st.code ?? "").toLowerCase();
    const nm = String(st.name ?? "");
    const hit = tokens.includes(code) || tokens.some((tok) => tok.length >= 4 && clean(nm).includes(clean(tok)));
    if (hit && !asked.includes(st)) asked.push(st); /* route-order me hi rehta hai */
  }
  if (!asked.length) return null;
  const head = `${trainNo}${name ? ` ${name}` : ""} — haan, `;
  const timingOf = (stop: (typeof chk.stops)[number]): string => {
    const isFirst = chk.stops[0] === stop;
    const isLast = chk.stops[chk.stops.length - 1] === stop;
    const arrRaw = (stop as { arrival?: string | null }).arrival ?? null;
    const depRaw = (stop as { departure?: string | null }).departure ?? null;
    const arr = arrRaw && !(isFirst && arrRaw === "00:00") ? arrRaw : null;
    const dep = depRaw && !(isLast && depRaw === "00:00") ? depRaw : null;
    return [arr ? `arrival ${arr}` : null, dep ? `departure ${dep}` : null].filter(Boolean).join(", ");
  };
  return {
    reply:
      asked.length === 1
        ? `${head}${asked[0].name} (${asked[0].code}) par rukti hai${timingOf(asked[0]) ? ` — ${timingOf(asked[0])}` : ""}.`
        : `${head}in sab par rukti hai: ${asked.map((st) => `${st.name} (${st.code})${timingOf(st) ? ` — ${timingOf(st)}` : ""}`).join(" · ")}.`,
    trainNumber: trainNo,
    trainName: name || null,
  };
}

/** ── Round-44: BINARY arrival sawaal ("12013 LDH pahunch gayi kya?", "kal LDH pahunchi thi?") ─────
 * Ye timetable ka WAQT nahi, haan/na ka sawaal hai — jawab LIVE run data se aata hai:
 *   • provider ne "Journey completed" (ya status me "reached/destination/arrived") kaha  → HAAN
 *   • provider ne route-order diya aur asked stop current se PEHLE aa chuka hai              → HAAN
 *   • train abhi asked stop par hai / aage hai (asked stop current ke BAAD)                → "abhi nahi"
 *   • aaj ka run start hi nahi hua (asked stop abhi aane wala hai)                          → "abhi nahi"
 * Data na mila / route-order nahi mila to null (model/normal flow — koi andaza nahi). */
const BINARY_ARRIVAL_RE = /\b(pahunch\s*(?:gayi|gaya|chuki|chuka|li)|(?:gayi|gaya|chuki|chuka)\s*kya|pahunch\s*gaya\s*kya|aa\s*gayi\s*kya|arrived\s*yet|reached\s*yet)\b/i;
const BINARY_ARRIVAL_FILLER = new Set([
  "kya","ki","ka","ke","ko","se","par","pe","pr","me","mein","hai","hain","tha","thi","the","ho","hui","hua",
  "train","gaadi","gadi","kal","aaj","parso","parson","abhi","tak","kaun","kab","ya","yaa","please","bhai",
  "arrived","reach","reached","yet","has","have","did","do","does","is","was","were","time","on","at","in",
]);

export async function arrivalBinaryTurn(
  text: string,
  ctx: AgentContext,
  nowIso?: string | null,
): Promise<ArrivalBinary | null> {
  const raw = String(text ?? "");
  if (!BINARY_ARRIVAL_RE.test(raw)) return null;
  const trainNo = resolveTrainNumber(raw, ctx);
  if (!trainNo) return null;
  const tokens = arrivalStationTokens(raw).filter((w) => !BINARY_ARRIVAL_FILLER.has(w));
  if (!tokens.length) return null;

  const sched = await routedSchedule(trainNo).catch(() => null);
  const stops = sched?.schedule && "stops" in sched.schedule ? sched.schedule.stops ?? [] : [];
  if (stops.length < 2) return null;
  const clean = (x: string) => x.toLowerCase().replace(/[^a-z\u0900-\u097F]/g, "");
  let stop: (typeof stops)[number] | null = null;
  for (const tok of tokens) {
    const m = stops.find((st) => st.code.toLowerCase() === tok || (tok.length >= 4 && (clean(st.name).includes(clean(tok)) || clean(st.name).startsWith(clean(tok)))));
    if (m) stop = m;
  }
  if (!stop) {
    /* Round-45: binary sawaal ("haridwar pahunch gayi kya") non-route station par — pehle live ka
     * raw dump aa jaata tha. Ab route ka sach (R43e: train ke route me na hone wale station par
     * seat/board nahi, saaf correction). */
    const chk = await checkStationsOnRoute(trainNo, {}, raw).catch(() => null);
    if (chk && chk.stops.length >= 2 && chk.bad) {
      const name0 = "trainName" in (sched?.schedule ?? {}) ? String((sched?.schedule as { trainName?: string })?.trainName ?? "") : "";
      return { reply: `${trainNo}${name0 ? ` ${name0}` : ""} — ${routeMismatchTail(chk.bad)}`, trainNumber: trainNo, trainName: name0 || null };
    }
    return null;
  }
  const name = "trainName" in (sched?.schedule ?? {}) ? String((sched?.schedule as { trainName?: string })?.trainName ?? "") : "";
  const askedDate = runDateLabel(raw, nowIso);
  const dateArg = askedDate ? isoOfLabel(askedDate, nowIso) : null;

  const routed = await routedLiveStatus(trainNo, dateArg ?? undefined).catch(() => null);
  const live = routed?.live as { trainName?: string; status?: string; currentStation?: string | null; nextStation?: string | null; delayMinutes?: number | null; journeyDate?: string } | null;
  const title = live?.trainName?.trim() || name || "";
  if (!live?.status) return null;
  const status = String(live.status);
  const norm = (x: string) => x.toLowerCase().replace(/junction|jn\b|[^a-z]/g, "");

  /* 1) Provider khud keh raha hai run poora ho gaya (JOINED naam kabhi na chhodo — pehle hi match). */
  const stopCode = stop.code.toLowerCase();
  /* Run poora ho chuka = saare route stops cross ho gaye — us route ka koi bhi station poochha ho to HAAN
   * (stop ka naam status me ho ya na ho; completed run me sab pahunch chuke hote hain). */
  if (/completed|destination|reached\s+(?:the\s+)?destination|arrived\s+at\s+destination|journey\s+end|यात्रा\s*पूरी/i.test(status)) {
    return { reply: `${trainNo}${title ? ` ${title}` : ""} — haan, ${stop.name} (${stop.code}) pahunch chuki hai (${askedDate ?? live.journeyDate ?? "us run"} ki run poori ho chuki hai${live.delayMinutes != null ? `, delay ${live.delayMinutes} min` : ""}).`, trainNumber: trainNo, trainName: title || null };
  }
  /* 2) Route-order se: asked stop current position se pehle? */
  const stopsList = stops.map((st) => st.code.toUpperCase());
  const askedIdx = stopsList.indexOf(stop.code.toUpperCase());
  const curRaw = String(live.currentStation ?? "").trim();
  const curToken = /^([A-Za-z .]+?)\s*\(?(\w{2,5})?\)?$/.exec(curRaw);
  const curCode = curToken?.[2]?.toUpperCase() ?? null;
  let curIdx = curCode ? stopsList.indexOf(curCode) : -1;
  if (curIdx < 0 && curRaw) {
    const curClean = clean(curRaw);
    curIdx = stops.findIndex((st) => clean(st.name ?? "").startsWith(curClean) || curClean.startsWith(clean(st.name ?? "")));
  }
  const started = !/hasn'?t started|not started|starts at/i.test(status);
  if (!started) {
    return { reply: `${trainNo}${title ? ` ${title}` : ""} — nahi, ${stop.name} (${stop.code}) abhi nahi pahunchi. Aaj (${live.journeyDate ?? "aaj"}) ka run ${/starts at\s*([\d:]+)/i.exec(status)?.[1] ?? ""} par start hota hai; ${stop.code} par schedule se arrival ${stop.arrival ?? "?"} hai.`, trainNumber: trainNo, trainName: title || null };
  }
  if (askedIdx >= 0 && curIdx >= 0) {
    if (askedIdx < curIdx) {
      return { reply: `${trainNo}${title ? ` ${title}` : ""} — haan, ${stop.name} (${stop.code}) pahunch chuki hai. Abhi ${live.currentStation}${live.delayMinutes != null ? ` (delay ${live.delayMinutes} min)` : ""}.`, trainNumber: trainNo, trainName: title || null };
    }
    if (askedIdx === curIdx) {
      return { reply: `${trainNo}${title ? ` ${title}` : ""} — abhi ${stop.name} (${stop.code}) par hai (na pahunchi ke aage, na peeche).${live.delayMinutes != null ? ` Delay ${live.delayMinutes} min.` : ""}`, trainNumber: trainNo, trainName: title || null };
    }
    return { reply: `${trainNo}${title ? ` ${title}` : ""} — nahi, ${stop.name} (${stop.code}) abhi nahi pahunchi. Abhi ${live.currentStation}${live.nextStation ? `, next ${live.nextStation}` : ""}; schedule se ${stop.code} arrival ${stop.arrival ?? "?"}.`, trainNumber: trainNo, trainName: title || null };
  }
  /* NTES-style exact line: "Departed from LUDHIANA JN(LDH) at 09:11" — asked stop ke liye seedha HAAN. */
  const dep = /departed\s+from\s+([^(]+?)\s*\((\w+)\)\s*at\s*([\d:]+)/i.exec(status);
  if (dep && (norm(dep[1]) === norm(stop.name) || dep[2].toLowerCase() === stopCode)) {
    return { reply: `${trainNo}${title ? ` ${title}` : ""} — haan, ${stop.name} (${stop.code}) se ${dep[3]} baje nikal chuki hai (pahunch chuki).`, trainNumber: trainNo, trainName: title || null };
  }
  return null;
}

/* Round-16j: unresolved place (det.unresolvedFrom/To ya ctx.pending*Choice)
 * ko provider se dekho — EXACTLY ek station, needChoice=false → slot fill
 * + pending clear + det ka unresolved hata do (taaki model/atlas dobara na
 * poochhe). Multi-station city → kuch nahi (options flow). Fail-safe. */
async function autoResolveSingleStation(ctx: AgentContext, det: NluResult): Promise<void> {
  const tryOne = async (q: string | null | undefined): Promise<Station | null> => {
    const query = String(q ?? "").trim();
    if (!query) return null;
    try {
      const res = await routedStationSearch(query);
      if (res.stations.length === 1 && !res.needChoice) {
        const only = res.stations[0];
        return { code: only.code, name: only.name, city: only.city ?? only.name };
      }
    } catch {
      /* provider fail — pehla flow chalega */
    }
    return null;
  };
  if (!ctx.destination) {
    const st = await tryOne(det.unresolvedTo ?? ctx.pendingDestinationChoice);
    if (st) {
      ctx.destination = st;
      ctx.pendingDestinationChoice = null;
      det.unresolvedTo = undefined;
    }
  }
  if (!ctx.origin) {
    const st = await tryOne(det.unresolvedFrom ?? ctx.pendingOriginChoice);
    if (st) {
      ctx.origin = st;
      ctx.pendingOriginChoice = null;
      det.unresolvedFrom = undefined;
    }
  }
  if (ctx.origin && ctx.destination && ctx.origin.code === ctx.destination.code) {
    // same station dono side — jo abhi resolve hua use hatao
    if (det.unresolvedTo === undefined && ctx.pendingDestinationChoice === null) ctx.destination = null;
  }
}

/* Round-16k: pending/unresolved city ke liye REAL station options — sirf
 * station ka sawaal (date nahi), "station first" flow. Provider se 2+ station
 * mile tabhi; 0/1 (ya fail) → null (aage normal flow). */
async function askStationChoiceFirst(
  ctx: AgentContext,
  det: NluResult,
): Promise<{ reply: string; side: "to" | "from"; stations?: { code: string; name: string }[]; city?: string } | null> {
  const side: "to" | "from" | null =
    !ctx.destination && (det.unresolvedTo || ctx.pendingDestinationChoice)
      ? "to"
      : !ctx.origin && (det.unresolvedFrom || ctx.pendingOriginChoice)
        ? "from"
        : null;
  if (!side) return null;
  const place = String(
    (side === "to" ? det.unresolvedTo ?? ctx.pendingDestinationChoice : det.unresolvedFrom ?? ctx.pendingOriginChoice) ?? "",
  ).trim();
  if (!place) return null;
  try {
    const res = await routedStationSearch(place);
    if (res.stations.length === 0 && /^[A-Za-z][A-Za-z .]{2,28}$/.test(place)) {
      /* Round-18m-30g: lookup (API + web) se kuch nahi mila — model ko mat bhejo (wo purani chat ka shehar
       * guess kar leta hai, jaise Ayodhya → Varanasi). Seedha user se station code/naam poochho. */
      if (side === "to") ctx.pendingDestinationChoice = place;
      else ctx.pendingOriginChoice = place;
      return { side, reply: `"${place}" ka station lookup abhi nahi ho paya (provider/web se jawab nahi aaya). ${place} ka station code ya poora station naam bata do (jaise "AYC" ya "Ayodhya Cantt") — main us par hi search karunga, khud se koi station assume nahi karunga.` };
    }
    if (res.stations.length < 2) return null;
    if (side === "to") ctx.pendingDestinationChoice = place;
    else ctx.pendingOriginChoice = place;
    const city = res.city ?? place;
    // Format resolveStationPick ke parsers se match: "1. HWH – Howrah Junction, 2. …"
    const list = res.stations
      .slice(0, 6)
      .map((s, i) => `${i + 1}. ${s.code} – ${s.name}`)
      .join(", ");
    const known = side === "to" && ctx.origin ? `${ctx.origin.code} se ${city}: ` : side === "from" && ctx.destination ? `${city} se ${ctx.destination.code}: ` : "";
    const dateNote = ctx.dateProvided && ctx.date ? "" : det.dateAmbiguous?.length ? ` Weekend mein kaunsa din — ${det.dateAmbiguous.map((d) => d.label).join(" ya ")} — bhi bata dena.` : " Station batane ke baad date poochhunga.";
    return {
      side,
      reply: `${known}${city} mein kaunsa station chahiye? Options: ${list}.${dateNote}`,
      stations: res.stations.slice(0, 6).map((x) => ({ code: x.code, name: x.name })),
      city,
    };
  } catch {
    return null;
  }
}

/* ══ ROUND-45 (28 Sep 2026) — FULL AI-FIRST (user: "jab AI ke paas saare tools hain, to har query pehle
 * AI ke paas jaani chahiye — tum handlers/rules kyun update karte ho?") ═════════════════════════════
 * Ab HAR sawaal pehle model ke paas jaata hai (agentic tool-calling, saare tools). Neeche wale char
 * deterministic handlers pehle SHORTCUTS the (model se pehle chalte the) — ab ye sirf FALLBACK hain:
 *   (a) AI configured hi na ho (key nahi / AI_OWNS_FLOW=0), ya
 *   (b) model fail ho (timeout / http error / empty reply) — tab usi sawaal ka verified deterministic
 *       jawab turant (wahi tools: routeCheck / CHECK_AVAILABILITY / routedLiveStatus).
 * Dono engine ek hi sach bolte hain — model aur fallback alag-alag jawab kabhi nahi (R44 screenshots).
 */
export async function singleTrainSeatTurn(req: AgentRequest, seeded: AgentContext): Promise<AgentResponse | null> {
    const t = String(req.text ?? "");
    /* Round-43b (multi-turn): train pehle turn me aa chuki hai (ctx me selected) aur ab user date/route/
     * class de raha hai ("Date aaj ki ludhiana se hw ki") → usi train ki availability dobara dikhao
     * (train dobara poochhna/khoya nahi jaata — ChatGPT jaisa continue). */
    const ctxResume = { ...emptyAgentContext(), ...(req.context ?? {}) };
    const resumeDateAsk = /\b(aaj|kal|parso|parson|tomorrow|today|date|tareekh|\d{1,2}\s*(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec))\b/i.test(t) && !/\b(trains?\s*batao|kaunsi|sabhi|sab\s*trains|alawa|options?|list|book|cancel|refund)\b/i.test(t);
    const resumeBareClass = /^\s*(1A|2A|3A|3E|2S|SL|CC|EC|FC|1E)\s*$/i.test(t) && Boolean(ctxResume.date);
    /* Sirf FOLLOW-UP par resume: user naya route-ask kar raha ho ("jammu se ndls jaana hai aaj seats
     * dikhao") to purani train par nahi atakna (Round-18m-28). */
    const routeAskVerb = /\b(jaana hai|jana hai|jaana|jana|dikhao|dikha|batao|bata|bataiye|options?|trains?)\b/i.test(t);
    const resumeTrain = !/\d{4,5}/.test(t) && !routeAskVerb && ctxResume.selectedTrainNumber && (resumeDateAsk || resumeBareClass) ? ctxResume.selectedTrainNumber : null;
    if ((asksSingleTrainAvailability(t) || resumeTrain) && !isBookingMutation(req)) {
      const tnum = (/\b(\d{4,5})\b/.exec(t) ?? [])[1] ?? resumeTrain;
      if (tnum) {
        const detAv = await deterministicUnderstand(req.text, {
          now: req.now ? new Date(req.now) : undefined,
          lastAsked: req.lastAsked ?? null,
          known: { from: seeded.origin, to: seeded.destination, date: seeded.date, passengerCount: seeded.passengers },
        });
        const avCtx = { ...emptyAgentContext(), ...(req.context ?? {}) };
        const clsAsk = (t.match(/\b(1A|2A|3A|3E|2S|SL|CC|EC|FC|1E)\b/i) ?? [])[1]?.toUpperCase() ?? null;
        /* ── Round-43k: station check EK shared jagah se (routeCheck.ts) — wahi jo tool ke andar chalti hai
         * (CHECK_AVAILABILITY/GET_FARE). Isliye ye deterministic handler aur model path kabhi alag baat
         * nahi bolte: station train ke timetable route me nahi → saaf correction + sahi station ka sawaal,
         * koi N/A board nahi (user screenshot: "19326 hw ke liye seat check krna"). Station NLU se na
         * mile to bhi user ke asli tokens se (naam/code) khud dhoondha jaata hai. */
        const detFrom = (detAv as unknown as { from?: { code?: string } | null }).from?.code ?? null;
        const detTo = (detAv as unknown as { to?: { code?: string } | null }).to?.code ?? null;
        const routeChk = await checkStationsOnRoute(tnum, { origin: detFrom, destination: detTo }, t);
        const askFrom = routeChk.origin ?? null;
        const askTo = routeChk.destination ?? null;
        if (routeChk.bad) {
          const bad = routeChk.bad;
          const nameHit = (await routedStationSearch(bad.code).catch(() => null))?.stations?.find((x) => x.code.toUpperCase() === bad.code.toUpperCase()) ?? null;
          const asked = `${bad.code}${nameHit?.name && nameHit.name.toUpperCase() !== bad.code ? ` (${nameHit.name})` : ""}`;
          const schedBad = await routedSchedule(tnum).catch(() => null);
          const tname2 = avCtx.selectedTrainName ?? (schedBad?.schedule && "trainName" in schedBad.schedule ? String((schedBad.schedule as { trainName?: string }).trainName ?? "") : "");
          const label2 = `${tnum}${tname2 ? ` (${tname2})` : ""}`;
          const ctxBad = { ...emptyAgentContext(), ...(req.context ?? {}) };
          ctxBad.selectedTrainNumber = tnum;
          ctxBad.selectedTrainName = tname2 || ctxBad.selectedTrainName;
          ctxBad.lastTool = "getTimetable";
          ctxBad.lastToolOk = true;
          return {
            nlu: detAv,
            source: "nlu" as const,
            context: ctxBad,
            tool: null,
            toolOk: null,
            reply:
              `${label2} ${asked} par stop nahi karti — uska route ${bad.first} → ${bad.last} hai, aur ${asked} us route me nahi hai.\n\n` +
              (bad.nearby
                ? `Par isi shehar ka ${bad.nearby.code}${bad.nearby.name ? ` (${bad.nearby.name})` : ""} us route me hai${bad.nearby.departure ? ` (departure ${bad.nearby.departure})` : ""} — wahan se travel kar sakte ho; uska seat status bhi bata dunga.\n\n`
                : "") +
              `Ye train kis station tak chahiye? Sahi station bata do, main usi ka seat status check kar dunga. ` +
              `${bad.side === "destination" ? `${asked} ke liye` : "Is station se"} jaane wali trains bhi bata sakta hoon.\n\n` +
              `(Jawab ${label2} ke asli timetable/stops se verify kiya — andaza nahi.)`,
            interrupt: false,
            resumeAsk: null,
            resumeText: null,
            trains: null,
            confirmBook: false,
            missingFields: [],
            modelUsed: null,
            latencyMs: 0,
            failureReason: "single_train_station_not_in_route",
            engine: "deterministic" as const,
            agenticFailureReason: null,
            grounded: true,
            toolTrace: [],
            nextActions: [
              ...(bad.nearby ? [{ label: `${bad.nearby.code} ka seat`, utterance: `${tnum} ki seat availability ${bad.nearby.code} se`, primary: true }] : []),
              { label: `${tnum} ka route`, utterance: `${tnum} ka route batao`, primary: false },
              { label: `${bad.code} ke liye trains`, utterance: `${bad.first} se ${bad.code} jaane wali trains batao kal`, primary: false },
            ],
          } as never;
        }
        const baseMs = (req.now && Date.parse(req.now) ? Date.parse(req.now) : Date.now()) + 5.5 * 3600 * 1000;
        const ymd = (ms: number) => new Date(ms).toISOString().slice(0, 10);
        const given = avCtx.dateProvided && avCtx.date ? avCtx.date : detAv.date ?? null;
        const dates = given ? [given] : [ymd(baseMs), ymd(baseMs + 86400000)];
        const label = (d: string) => (d === ymd(baseMs) ? "aaj" : d === ymd(baseMs + 86400000) ? "kal" : "");
        const stepsOut: ToolTraceStep[] = [];
        const blocks: string[] = [];
        let okAny = false;
        /* Agar kisi bhi date/class me AVAILABLE/RAC nahi (sab WL/N-A/cancelled) → deterministic jawab
         * mat do: normal flow chale taaki auto-alternatives (real data) aur agla kadam mil sake. */
        let goodAny = false;
        /* Round-43e: agar kisi bhi date par koi class available nahi (sab N/A — 19326 jaisa "koi seat
         * nahi") to bhi user ko saaf date-wise jawab mile; 53s wala model/board path na chale. WL/RAC
         * wali case (kam availability) ab bhi alternatives flow par jaati hai (Round-18 §6/§7). */
        let sawNka = false;
        let sawWl = false;
        let name: string | null = avCtx.selectedTrainName ?? null;
        let from = avCtx.origin?.code ?? null;
        let to = avCtx.destination?.code ?? null;
        /* Round-43c: user ne ek hi date boli ho ("aaj ki") aur us din train cancelled/WL-only ho to
         * ChatGPT jaisa agla din bhi dikhao (27 Sep cancelled → 28 Sep CC WL16 · 2S AVL 294) — warna
         * aaj ka single-date jawab deterministic hi nahi ban paata aur route-board par chala jaata hai. */
        /* Round-43k: jo station train ka pehla/aakhri stop hi hai wo arg dena bekaar hai (provider use ulta
         * samajh leta hai — 12054 par "HW→HW" ban gaya tha). Tool khud bhi normalize karta hai, par call
         * sasti rahe isliye yahin skip. */
        const segReq = normalizeRouteSegment(routeChk.stops, { origin: askFrom, destination: askTo });
        const segFrom = segReq.origin ?? null;
        const segTo = segReq.destination ?? null;
        const queryDate = async (d: string): Promise<void> => {
          try {
            const avArgs = { train_number: tnum, date: d, ...(segFrom ? { origin: segFrom } : {}), ...(segTo ? { destination: segTo } : {}) };
            const r = (await executeApprovedTool("CHECK_AVAILABILITY", avArgs as never, { userText: req.text })) as unknown as { ok: boolean; summary: string; data: unknown; source: string | null };
            stepsOut.push({ step: stepsOut.length + 1, tool: "CHECK_AVAILABILITY", args: avArgs, ok: r.ok, source: r.source ?? "provider", summary: String(r.summary ?? ""), latencyMs: 0, dataPreview: r.data ? JSON.stringify(r.data).slice(0, 380) : undefined } as ToolTraceStep);
            if (!r.ok) return;
            okAny = true;
            const data = (r.data ?? {}) as { classes?: { code?: string; status?: string; seats?: number | null; rac?: number | null; waitlist?: number | null; fare?: number | null; note?: string | null }[]; resolvedRoute?: { origin?: string; destination?: string } };
            from = segFrom ?? askFrom ?? from ?? data.resolvedRoute?.origin ?? null;
            to = segTo ?? askTo ?? to ?? data.resolvedRoute?.destination ?? null;
            const rows = (data.classes ?? []).filter((c) => c.code);
            if (rows.some((c) => /^(AVAILABLE|RAC)$/i.test(String(c.status ?? "")))) goodAny = true;
            if (rows.some((c) => /NOT_AVAILABLE|N\/A/i.test(String(c.status ?? "")))) sawNka = true;
            if (rows.some((c) => /WAIT|RAC/i.test(String(c.status ?? "")))) sawWl = true;
            const cancelled = rows.length > 0 && rows.every((c) => /cancel/i.test(String(c.note ?? "")) || (String(c.status).toUpperCase() === "NOT_AVAILABLE" && /cancel/i.test(String(c.note ?? ""))));
            const when = `${d.slice(8, 10)} ${["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"][Number(d.slice(5, 7)) - 1]}${label(d) ? ` (${label(d)})` : ""}`;
            if (cancelled) {
              blocks.push(`• ${when}: train cancelled`);
              return;
            }
            const parts = rows.map((c) => {
              const st = String(c.status ?? "").toUpperCase();
              const val = st === "AVAILABLE" ? `AVAILABLE ${c.seats ?? "?"}` : st === "RAC" ? `RAC ${c.rac ?? "?"}` : st.includes("WAIT") ? `WL ${c.waitlist ?? "?"}` : st === "NOT_AVAILABLE" ? "N/A" : c.status;
              /* Fare sirf jab verified ho (0/null par "₹0" bhadda lagta hai aur jhootha bhi). */
              return `${c.code} ${val}${c.fare != null && c.fare > 0 ? ` ₹${c.fare}` : ""}`;
            });
            const wanted = clsAsk ? parts.filter((p) => p.startsWith(clsAsk)) : parts;
            blocks.push(`• ${when}: ${(wanted.length ? wanted : parts).join(" · ")}`);
          } catch { /* is date ka data nahi mila — baaki dates chalte rahenge */ }
        };
        for (const d of dates) await queryDate(d);
        if (!goodAny && dates.length === 1) await queryDate(ymd(Date.parse(`${dates[0]}T00:00:00Z`) + 86400000));
        const head = `${tnum}${name ? ` ${name}` : ""}${from && to ? ` (${from} → ${to})` : ""} — seat availability:`;
        if (okAny && (goodAny || (sawNka && !sawWl))) {
          const reply = `${head}\n${blocks.join("\n")}\n\n${
            goodAny
              ? `Aur kisi date/class ka bolo, ya seedha "Book ${tnum}${clsAsk ? ` ${clsAsk}` : ""}" kah do — main passenger form khol dunga.`
              : `Is train me in dates par koi class available nahi (N/A = koi seat nahi / bookable nahi). Chaho to is route ki doosri trains ke seats bata dun?`
          }`;
          return {
            nlu: detAv,
            source: "nlu" as const,
            context: {
              ...avCtx,
              origin: from ? { code: from, name: from, city: from } : avCtx.origin,
              destination: to ? { code: to, name: to, city: to } : avCtx.destination,
              selectedTrainNumber: tnum,
              selectedTrainName: name ?? avCtx.selectedTrainName,
              /* Round-43b: pehli date ctx me lock — agla turn ("CC", "kal ki seat") isi context par resume kare. */
              date: dates[0] ?? avCtx.date,
              dateProvided: dates[0] ? true : avCtx.dateProvided,
              classCode: clsAsk ?? avCtx.classCode,
              lastTool: "getAvailability",
              lastToolOk: true,
              bookingStage: "results",
            },
            tool: "getAvailability" as ToolName,
            toolOk: true,
            reply,
            interrupt: false,
            resumeAsk: null,
            resumeText: null,
            trains: null,
            confirmBook: false,
            missingFields: [],
            modelUsed: null,
            latencyMs: 0,
            failureReason: "single_train_availability_deterministic",
            engine: "deterministic" as const,
            agenticFailureReason: null,
            grounded: true,
            toolTrace: stepsOut,
            nextActions: [
              ...(goodAny
                ? [{ label: `Book ${tnum}${clsAsk ? ` · ${clsAsk}` : ""}`, utterance: `${tnum} mein ${clsAsk ?? ""} book krdo ${dates[0]}`.replace(/\s+/g, " "), primary: true }]
                : [{ label: "Route ki doosri trains", utterance: `${tnum} ke alawa ${(from ?? "ASR")} se ${(to ?? "HW")} jaane wali trains ke seats batao`, primary: true }]),
              ...(given ? [] : [{ label: "Kal ki seat", utterance: `${tnum} ki seat availability kal ki`, primary: false }]),
            ],
          } as never;
        }
      }
    }
  return null;
}

export async function livePrecheckTurn(req: AgentRequest): Promise<AgentResponse | null> {
    const t = String(req.text ?? "");
    const tnum = (/\b(\d{4,5})\b/.exec(t) ?? [])[1] ?? null;
    const liveQ = /\b(kahan hai|kahaan hai|kaha hai|abhi kahan|abhi kaha|kahan tak|kahan pahunchi|live status|running status|live hai|late hai|late h\b|late chal|delayed|delay hai|kitni der|der se chal)\b/i.test(t);
    const anyDate = /\b(aaj|kal|parso|parson|tomorrow|today|yesterday|\d{1,2}\s*(?:jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)[a-z]*|20\d\d-\d\d-\d\d|\d{1,2}\/\d{1,2})\b/i.test(t);
    /* Round-45: guard (pehle ye inner-if me tha) — sirf AAJ/date-ke-bina live sawaal par chale. */
    if (!tnum || !liveQ || anyDate) return null;
    /* "kitni der rukti hai" me bhi "kitni der" hai (LIVE_TODAY_RE) par wo HALT ka sawaal hai —
     * stop/route wala jawab chahiye, live status ka nahi. */
    if (STOPPING_Q_RE.test(t) || HALT_QUESTION_RE.test(t)) return null;
    try {
        /* Date KE BINA — router khud aaj ka origin-idle run skip kar ke chalta hua run deta hai
         * (Round-16p logic), aur cancel-alert bhi wahi se aata hai. Koi andaza nahi. */
        const liveResult = await executeTool("getLiveStatus", { trainNumber: tnum });
        if (liveResult.ok && liveResult.summary) {
          {
            const ctxLive = { ...emptyAgentContext(), ...(req.context ?? {}) };
            ctxLive.selectedTrainNumber = tnum;

            ctxLive.intent = "LIVE_TRAIN_STATUS";
            ctxLive.lastTool = "getLiveStatus";
            ctxLive.lastToolOk = true;

            return {
              nlu: null,
              source: "nlu" as const,
              context: ctxLive,
              tool: "getLiveStatus" as ToolName,
              toolOk: true,
              reply: `${liveResult.summary}\n(Live railway data — verified.)`,
              interrupt: false,
              resumeAsk: null,
              resumeText: null,
              trains: null,
              confirmBook: false,
              missingFields: [],
              modelUsed: null,
              latencyMs: 0,
              failureReason: null,
              engine: "deterministic" as const,
              agenticFailureReason: null,
              grounded: true,
              /* Audit/trace ke liye tool bhi dikhe (chat me "⚙️" line) — data wahi verified live. */
              toolTrace: [{ step: 1, tool: "getLiveStatus", args: { trainNumber: tnum }, ok: true, source: "provider", summary: String(liveResult.summary ?? ""), latencyMs: 0 } as ToolTraceStep],
            } as never;
          }
        }
      } catch {
        /* live probe optional — normal flow chalta rahe */
      }
  return null;
}

export async function arrivalFamilyTurn(req: AgentRequest, seeded: AgentContext): Promise<AgentResponse | null> {
    try {
      /* Binary sawaal (pahunch gayi kya) par LIVE data ka jawab; warna timetable ka waqt. */
      const stopping = await stoppingQuestionTurn(req.text, seeded).catch(() => null);
      if (stopping) {
        const detS = await deterministicUnderstand(req.text, {
          now: req.now ? new Date(req.now) : undefined,
          lastAsked: req.lastAsked ?? null,
          known: { from: seeded.origin, to: seeded.destination, date: seeded.date, passengerCount: seeded.passengers },
        });
        const ctxS = mergeAgentContext(seeded, detS, req.text, { selectedTrainNumber: stopping.trainNumber, selectedTrainName: stopping.trainName });
        if (!ctxS.intent || ctxS.intent === "NONE") ctxS.intent = "TRAIN_SCHEDULE";
        ctxS.pendingAsk = null;
        return {
          nlu: detS, source: "nlu" as const, context: ctxS, tool: "getTimetable" as ToolName, toolOk: true,
          reply: stopping.reply, interrupt: false, resumeAsk: null, resumeText: null, trains: null, confirmBook: false, missingFields: [],
          modelUsed: null, latencyMs: 0, failureReason: null, engine: "deterministic" as const, agenticFailureReason: null, grounded: true,
        } as never;
      }
      const arrival = BINARY_ARRIVAL_RE.test(req.text)
        ? (await arrivalBinaryTurn(req.text, seeded, req.now)) ?? (await arrivalAtStationTurn(req.text, seeded, req.now))
        : (await arrivalAtStationTurn(req.text, seeded, req.now)) ?? (await arrivalBinaryTurn(req.text, seeded, req.now));
      if (arrival) {
        const det = await deterministicUnderstand(req.text, {
          now: req.now ? new Date(req.now) : undefined,
          lastAsked: req.lastAsked ?? null,
          known: { from: seeded.origin, to: seeded.destination, date: seeded.date, passengerCount: seeded.passengers },
        });
        const ctxArr = mergeAgentContext(seeded, det, req.text, {
          selectedTrainNumber: arrival.trainNumber,
          selectedTrainName: arrival.trainName,
        });
        if (!ctxArr.intent || ctxArr.intent === "NONE") ctxArr.intent = "TRAIN_SCHEDULE";
        ctxArr.pendingAsk = null;
        void neverAutoBook(det.intent, req.bookingFlow);
        return {
          nlu: det,
          source: "nlu",
          context: ctxArr,
          tool: "getTimetable",
          toolOk: true,
          reply: arrival.reply,
          interrupt: false,
          resumeAsk: null,
          resumeText: null,
          trains: null,
          confirmBook: false,
          missingFields: [],
          modelUsed: null,
          latencyMs: 0,
          failureReason: null,
          engine: "deterministic",
          agenticFailureReason: null,
          grounded: true,
        };
      }
    } catch {
      /* precheck optional hai — normal flow continue */
    }
  return null;
}

export async function departureTurn(req: AgentRequest, seeded: AgentContext): Promise<AgentResponse | null> {
    try {
      const dep = await departureFromStationTurn(req.text, seeded);
      if (dep) {
        const det = await deterministicUnderstand(req.text, {
          now: req.now ? new Date(req.now) : undefined,
          lastAsked: req.lastAsked ?? null,
          known: { from: seeded.origin, to: seeded.destination, date: seeded.date, passengerCount: seeded.passengers },
        });
        const ctxDep = mergeAgentContext(seeded, det, req.text, {
          selectedTrainNumber: dep.trainNumber,
          selectedTrainName: dep.trainName,
        });
        if (!ctxDep.intent || ctxDep.intent === "NONE") ctxDep.intent = "LIVE_TRAIN_STATUS";
        ctxDep.pendingAsk = null;
        void neverAutoBook(det.intent, req.bookingFlow);
        return {
          nlu: det,
          source: "nlu",
          context: ctxDep,
          tool: "getLiveStatus",
          toolOk: true,
          reply: dep.reply,
          interrupt: false,
          resumeAsk: null,
          resumeText: null,
          trains: null,
          confirmBook: false,
          missingFields: [],
          modelUsed: null,
          latencyMs: 0,
          failureReason: null,
          engine: "deterministic",
          agenticFailureReason: null,
          grounded: true,
        };
      }
    } catch {
      /* precheck optional hai — normal flow continue */
    }
  return null;
}

export async function runAgent(req: AgentRequest): Promise<AgentResponse> {
  const seeded = seedContext(req);
  /* Round-18m-32 (user: "HAR question AI ke paas jaaye — train search, station lookup, live, seats, general —
   * AI decide kare kaunsa API/scrape"): code-first shortcuts (arrival/departure fast-path, live fast-path,
   * name-picker) ab sirf tab jab AI configured na ho ya AI_OWNS_FLOW=0. Warna AI pehle; ye sab uske TOOLS hain. */
  const aiFirst = agenticConfigured() && process.env.AI_OWNS_FLOW !== "0" && !isBookingMutation(req);

  /* ── 1) AI-DRIVEN TOOL CALLING (primary engine) ────────────────────
   * Model request + multi-turn state dekh kar KHUD decide karta hai kaunse
   * approved tools call karne hain (multi-step chaining allowed). Sirf
   * booking mutations model tak nahi pahunchte (booking tool hai hi nahi).
   * Cheap deterministic slot-merge (no network) context compile karta hai. */
  let agenticFailureReason: string | null = null;

  /* Station-choice reply ("4" / "NDLS" / "New Delhi") — pichhle turn mein
   * station options puche gaye the to slot yahin resolve karo. Dono engines
   * (agentic known + deterministic ctx) ko milta hai; model/history-parse
   * fail ho tab bhi flow aage badhta hai. */
  let stationPick: StationPick = null;
  try {
    stationPick = await resolveStationPick(req.text, req.history, seeded);
  } catch {
    /* pick optional hai — normal flow continue */
  }
  if (stationPick) {
    if (stationPick.side === "to" && !seeded.destination) {
      seeded.destination = { code: stationPick.code, name: stationPick.name, city: stationPick.city };
    } else if (stationPick.side === "from" && !seeded.origin) {
      seeded.origin = { code: stationPick.code, name: stationPick.name, city: stationPick.city };
    }
  }

  /* Train NAAM se resolve (2026-09-05): "swarn shatabdi ka time batao" jaisi
   * queries pichhli selected train par galti se na chal jayein. Ek solid match
   * → dono engines ke liye selectedTrain set; ambiguous/zero → honest clarify
   * (model ko galat train answer karne ka mauka hi nahi). */
  let nameClarify: string | null = null;
  let namePicker: TrainPickerResult | null = null;
  let nameResolvedTrain: { number: string; name: string } | null = null;
  if (!isBookingMutation(req)) {
    try {
      const resolved = await resolveTrainByName(req.text, seeded);
      if (resolved && "trainNumber" in resolved) {
        nameResolvedTrain = { number: resolved.trainNumber, name: resolved.trainName };
        seeded.selectedTrainNumber = resolved.trainNumber;
        seeded.selectedTrainName = resolved.trainName;
      } else if (resolved && "clarify" in resolved && !aiFirst) {
        /* AI-first: ambiguous naam par picker code nahi dega — AI TRAIN_NAME_SEARCH/SEARCH_TRAIN_BY_NAME tool se
         * khud options dikhayega (ya sawaal general ho to seedha jawab). */
        nameClarify = resolved.clarify;
        namePicker = resolved.picker ?? null;
      }
    } catch {
      /* optional hai — normal flow continue */
    }
  }

  /* ── Round-39: CAPABILITY/META sawaal — "tum kya kar sakte ho", "kya nahi kar sakte",
   * "tum kaun ho" (live battery me "kya nahi kar sakte" par model ne booking flow shuru kar
   * diya: "Kahan se jaana hai?" 😑). Ye jawab fixed aur honest hai — koi tool nahi. */
  {
    const t = String(req.text ?? "").toLowerCase();
    const capabilityQ =
      /\b(tum|aap|tu|you)\b[^?!.]{0,40}\b(kya|kaun|kaunsi|kaunsa|kaise|what|who)\b[^?!.]{0,40}\b(kar sakte|kar sakta|kar sakt[ae]|kar sakti|nahi kar|nhi kar|na kar|kaun ho|koi ho|limits?|limit)\b/i.test(t) ||
      /\b(kya nahi kar|kya nhi kar|what can'?t you|what can you not|tumhari limits?|tumhari kya limit|aap kya nahi)\b/i.test(t) ||
      /\b(tum|aap|tu|you)\b[^?!.]{0,30}\b(kaun|koun|who)\b[^?!.]{0,20}\b(ho|hain|are you)\b/i.test(t) ||
      /\b(what can you do|tum kya kya kar|aap kya kya kar|tum kya kar sakti ho)\b/i.test(t);
    /* Round-52 (user: "har query AI ke paas jaaye — deterministic path chale hi na"): ye sawaal bhi
     * ab MODEL ka hai (system prompt rule 28 me wahi honest sach likha hai). Neeche wala fixed jawab
     * sirf tab chalta hai jab AI configured na ho / AI_OWNS_FLOW=0 ho, ya model fail ho jaye (rescue). */
    if (capabilityQ && !/\b(\d{4,5})\b/.test(t) && !aiFirst) {
      const detCap = await deterministicUnderstand(req.text, {
        now: req.now ? new Date(req.now) : undefined,
        lastAsked: req.lastAsked ?? null,
        known: { from: seeded.origin, to: seeded.destination, date: seeded.date, passengerCount: seeded.passengers },
      });
      return {
        nlu: detCap,
        source: "nlu",
        context: { ...emptyAgentContext() },
        tool: null,
        toolOk: null,
        reply:
          "Main RailBook AI hoon — Indian Railways ka assistant. Main ye sab kar sakta hoon:\n" +
          "• Train search (from → to + date) — direct/connecting, timings, kis class me seat hai, fare\n" +
          "• Kisi bhi train ka: naam · route · timetable/stops · live status (abhi kahan hai) · kitni late\n" +
          "• Seat availability & fare (ConfirmTkt · RailYatri · eRail se real data), WL/RAC ka sach\n" +
          "• Booking aage badhana: class/seat chun kar passenger form kholna (IRCTC handoff)\n" +
          "• PNR status · station code/naam/city · general railway rules (tatkal · RAC/WL · luggage · khana · refund)\n" +
          "• General railway knowledge (itihaas, speed, sabse lambi route, sabse bada station jaise sawaal)\n\n" +
          "Do cheezein main NAHI karta (aapke rule ke hisaab se): (1) IRCTC par 'Continue to IRCTC' main aapki taraf se click nahi karta, (2) aapke passenger details / OTP / payment main khud nahi bharta — wo aap karte ho. " +
          "Aur jo data verified nahi hota, main guess nahi karta — saaf bolta hoon aur jo sach me pata hai wahi deta hoon.",
        interrupt: false,
        resumeAsk: null,
        resumeText: null,
        trains: null,
        confirmBook: false,
        missingFields: [],
        modelUsed: null,
        latencyMs: 0,
        failureReason: "capability_meta_answer",
        engine: "deterministic",
        agenticFailureReason: null,
        grounded: true,
      };
    }
  }

  /* ── Round-43 (27 Sep 2026, user screenshot: "12054 ki seat availability btana" par poora 16-train
   * board khul gaya, uska jawab nahi mila — jabki ChatGPT usi sawaal par 27/28/29 Sep ki saaf
   * date-wise availability deta hai). Ab KHAAS TRAIN ke seat sawaal par usi train ka
   * CHECK_AVAILABILITY chalta hai (FIND_SEATS ka route-board NAHI) — date na ho to aaj + kal dono. */
  /* Round-45: FULL AI-FIRST — ye sawaal bhi pehle MODEL ke paas jaata hai; ye deterministic
   * jawab sirf AI-off ya model-fail par (singleTrainSeatTurn(req, seeded)). */
  if (!aiFirst) {
    const turn45 = await singleTrainSeatTurn(req, seeded);
    if (turn45) return turn45;
  }

  /* ── Round-43d (27 Sep 2026, battery: "12054 late hai kya" ❌ model date poochh kar ruk gaya) ──
   * Khaas train ka live sawaal ("kahan hai" / "late hai kya" / running status) aur user ne koi date nahi
   * boli → seedha wahi live probe (date ke bina — router khud aaj ka origin-idle run skip kar ke chalta
   * hua run deta hai, Round-16p logic). Pehle ye model ke paas jaata tha jo date poochh kar ruk jaata tha. */
  /* Round-45: FULL AI-FIRST — ye sawaal bhi pehle MODEL ke paas jaata hai; ye deterministic
   * jawab sirf AI-off ya model-fail par (livePrecheckTurn(req)). */
  if (!aiFirst && !isBookingMutation(req)) {
    const turn45 = await livePrecheckTurn(req);
    if (turn45) return turn45;
  }

  /* ── Round-42 (27 Sep 2026, user: "jaise ChatGPT… sahi tools use karo user query samajhke"): BOOKING
   * HUKM ("<train> mein 2S book krdo kal ke liye") par model kai baar sirf train-info tool chala kar
   * khali summary de deta tha aur passenger form khulta hi nahi tha. Ab booking order par SERVER hi sahi
   * tools chalata hai (CHECK_AVAILABILITY + GET_FARE — real data), route train ke timetable se lock karta
   * hai, aur date/class naming se target bana kar deta hai — client ka form resolver isi se form kholta
   * hai. Koi bhi number khud se nahi — sab provider ka. (R34: "bare Book <train-no> = hukm → seedha form".) */
  {
    const t = String(req.text ?? "");
    const bookOrder = /\b(book\s*kr?do|book\s*kar\s*do|book\s*kardo|book\s*kar|booking\s*kar|ticket\s*book|book\s+(?:a\s+)?ticket|book\s*it)\b/i.test(t);
    const tnum = (/\b(\d{4,5})\b/.exec(t) ?? [])[1] ?? null;
    if (bookOrder && tnum && !/\b(cancel|refund|pnr|status)\b/i.test(t)) {
      const detBook = await deterministicUnderstand(req.text, {
        now: req.now ? new Date(req.now) : undefined,
        lastAsked: req.lastAsked ?? null,
        known: { from: seeded.origin, to: seeded.destination, date: seeded.date, passengerCount: seeded.passengers },
      });
      const bootCtx = { ...emptyAgentContext(), ...(req.context ?? {}) };
      const cls = (t.match(/\b(1A|2A|3A|3E|2S|SL|CC|EC|FC|1E)\b/i) ?? [])[1]?.toUpperCase() ?? bootCtx.classCode ?? detBook.classCodes?.[0] ?? null;
      const bDate = bootCtx.date ?? detBook.date ?? null;
      let bFrom = bootCtx.origin?.code ?? null;
      let bTo = bootCtx.destination?.code ?? null;
      let tName: string | null = bootCtx.selectedTrainName ?? null;
      if (!bFrom || !bTo || !tName) {
        try {
          const sched = await routedSchedule(tnum);
          const stops = sched?.schedule && "stops" in sched.schedule ? sched.schedule.stops ?? [] : [];
          if (stops.length) {
            bFrom = bFrom ?? stops[0].code ?? null;
            bTo = bTo ?? stops[stops.length - 1].code ?? null;
            tName = tName ?? (sched.schedule && "trainName" in sched.schedule ? (sched.schedule.trainName as string) ?? null : null);
          }
        } catch {
          /* timetable nahi mili — route ke bina hi aage (neeche honest handling) */
        }
      }
      const outCtx: AgentContext = {
        ...bootCtx,
        origin: bFrom ? { code: bFrom, name: tName ?? bFrom, city: bFrom } : bootCtx.origin,
        destination: bTo ? { code: bTo, name: bTo, city: bTo } : bootCtx.destination,
        date: bDate,
        dateProvided: Boolean(bDate),
        classCode: cls ?? bootCtx.classCode,
        intent: "BOOK_TRAIN",
        selectedTrainNumber: tnum,
        selectedTrainName: tName ?? bootCtx.selectedTrainName,
        lastTool: "getAvailability",
        lastToolOk: null,
        bookingStage: "results",
      };
      const baseResp = {
        nlu: detBook,
        source: "nlu" as const,
        context: outCtx,
        tool: null as string | null,
        toolOk: null as boolean | null,
        interrupt: false,
        resumeAsk: null,
        resumeText: null,
        trains: null,
        confirmBook: false,
        missingFields: [] as string[],
        modelUsed: null as string | null,
        latencyMs: 0,
        failureReason: "booking_order_deterministic" as string | null,
        engine: "deterministic" as const,
        agenticFailureReason: null as string | null,
        grounded: true,
      };
      if (!bDate) {
        return {
          ...baseResp,
          reply: `${tnum}${tName ? ` ${tName}` : ""}${bFrom && bTo ? ` (${bFrom} → ${bTo})` : ""} ki booking ke liye date bata do — aaj, kal, parso ya tareekh. (Class${cls ? ` ${cls}` : ""} aur baaki sab yaad rakhunga; passenger details ka form agle step me.)`,
          nextActions: [
            { label: "Aaj ke liye", utterance: `${tnum} mein ${cls ?? "2S"} book krdo aaj ke liye`, primary: true },
            { label: "Kal ke liye", utterance: `${tnum} mein ${cls ?? "2S"} book krdo kal ke liye` },
          ],
        } as never;
      }
      const argsBase = { train_number: tnum, date: bDate, origin: bFrom ?? undefined, destination: bTo ?? undefined } as Record<string, unknown>;
      const okList: string[] = [];
      let availStep: ToolTraceStep | null = null;
      let fareStep: ToolTraceStep | null = null;
      /* Round-43g: agar boli hui date par koi class bookable hi nahi (cancelled/N-A — jaise 27 Sep
       * 12054) to user ko dead-end booking nahi — agla din bhi check karo aur wahi offer karo (jo data
       * me sach me hai). Sab kuch provider ke data se, guess nahi. */
      let bDateUsed = bDate;
      try {
        const avArgs = { ...argsBase, ...(cls ? { class_code: cls } : {}) };
        const av = (await executeApprovedTool("CHECK_AVAILABILITY", avArgs as never, { userText: req.text })) as unknown as { ok: boolean; summary: string };
        availStep = { step: 1, tool: "CHECK_AVAILABILITY", args: avArgs, ok: av.ok, source: "provider", summary: String(av.summary ?? ""), latencyMs: 0 } as ToolTraceStep;
        if (av.ok) okList.push("CHECK_AVAILABILITY");
        const dead = !/\b(AVAILABLE|RAC|WL|WAIT|WAITLIST)\b/i.test(String(av.summary ?? ""));
        if (dead && bDate) {
          const nextDate = (() => {
            const [y, m, d] = bDate.split("-").map(Number);
            const dt = new Date(Date.UTC(y, m - 1, d + 1));
            return `${dt.getUTCFullYear()}-${String(dt.getUTCMonth() + 1).padStart(2, "0")}-${String(dt.getUTCDate()).padStart(2, "0")}`;
          })();
          const av2 = (await executeApprovedTool("CHECK_AVAILABILITY", { ...argsBase, date: nextDate, ...(cls ? { class_code: cls } : {}) } as never, { userText: req.text })) as unknown as { ok: boolean; summary: string };
          const better = av2.ok && /\b(AVAILABLE|RAC|WL|WAIT|WAITLIST)\b/i.test(String(av2.summary ?? ""));
          if (better) {
            bDateUsed = nextDate;
            availStep = { step: 1, tool: "CHECK_AVAILABILITY", args: { ...argsBase, date: nextDate, ...(cls ? { class_code: cls } : {}) }, ok: true, source: "provider", summary: `${bDate} par koi class bookable nahi → ${nextDate}: ${String(av2.summary ?? "")}`, latencyMs: 0 } as ToolTraceStep;
          }
        }
      } catch {
        /* tool fail — neeche honest handling */
      }
      if (cls) {
        try {
          const fArgs = { ...argsBase, class_code: cls };
          const fr = (await executeApprovedTool("GET_FARE", fArgs as never, { userText: req.text })) as unknown as { ok: boolean; summary: string };
          fareStep = { step: 2, tool: "GET_FARE", args: fArgs, ok: fr.ok, source: "provider", summary: String(fr.summary ?? ""), latencyMs: 0 } as ToolTraceStep;
          if (fr.ok) okList.push("GET_FARE");
        } catch {
          /* fare fail — availability se kaam chalega */
        }
      }
      const availTxt = availStep?.ok ? availStep.summary.replace(/\s+/g, " ").trim() : null;
      const fareTxt = fareStep?.ok ? fareStep.summary.replace(/\s+/g, " ").trim() : null;
      const routeTxt = bFrom && bTo ? `${bFrom} → ${bTo}` : "";
      const head = `${tnum}${tName ? ` ${tName}` : ""}${routeTxt ? ` (${routeTxt})` : ""} · ${bDateUsed}${cls ? ` · ${cls}` : ""}${bDateUsed !== bDate && bDate ? ` (${bDate} par koi class bookable nahi thi)` : ""}`;
      let reply: string;
      const nextActions: { label: string; utterance: string; primary?: boolean }[] = [];
      if (!cls && availTxt) {
        reply = `${head} — kaunsi class me book karun?\n${availTxt}`;
        const classRows = [...String(availStep?.summary ?? "").matchAll(/\b(1A|2A|3A|3E|2S|SL|CC|EC|FC)\b/gi)].map((m) => m[1].toUpperCase());
        for (const c of [...new Set(classRows)].slice(0, 3)) {
          nextActions.push({ label: `Book ${tnum} · ${c}`, utterance: `${tnum} mein ${c} book krdo ${bDateUsed}`, primary: nextActions.length === 0 });
        }
      } else if (availTxt || fareTxt) {
        reply = `${head} ki booking — provider ka live data:\n${availTxt ? `• ${availTxt}` : ""}${fareTxt ? `${availTxt ? "\n" : ""}• ${fareTxt}` : ""}\nPassenger details ka form khol raha hoon — naam/age bhar kar aage badho. (Booking/payment sirf aapke confirm par.)`;
        nextActions.push({ label: `Book ${tnum}${cls ? ` · ${cls}` : ""}`, utterance: `${tnum} mein ${cls ?? "2S"} book krdo ${bDateUsed}`.replace(/\s+/g, " "), primary: true });
      } else {
        reply = `${head} ki booking ke liye seat/fare data abhi provider se nahi mil pa raha — bina verified data main aage nahi badhaunga. Thodi der baad phir bolo, ya app ke "Sabhi trains · Book →" se class chun lo.`;
      }
      return {
        ...baseResp,
        reply,
        toolOk: okList.length > 0,
        toolTrace: [availStep, fareStep].filter(Boolean) as ToolTraceStep[],
        nextActions,
      } as never;
    }
  }

  /* ── ROUND-8a: "nayi baat / reset" — topic-switch command. Client is
   * response par apne booking slots bhi clear karta hai (justReset flag). */
  if (isResetCommand(req.text)) {
    const det = await deterministicUnderstand(req.text, {
      now: req.now ? new Date(req.now) : undefined,
      lastAsked: req.lastAsked ?? null,
      known: { from: seeded.origin, to: seeded.destination, date: seeded.date, passengerCount: seeded.passengers },
    });
    return {
      nlu: det,
      source: "nlu",
      context: { ...emptyAgentContext(), justReset: true },
      tool: null,
      toolOk: null,
      reply: "Theek hai — purani baat poora bhool gayi (train, stations, date sab clear). Nayi baat shuru kariye — kaunsi train ya kahan se kahan jaana hai?",
      interrupt: false,
      resumeAsk: null,
      resumeText: null,
      trains: null,
      confirmBook: false,
      missingFields: [],
      modelUsed: null,
      latencyMs: 0,
      failureReason: null,
      engine: "deterministic",
      agenticFailureReason: null,
      grounded: true,
    };
  }

  /* ── ROUND-8b (screenshot fix): "{train} {station} kitne baje pahunchegi" —
   * deterministic arrival-at-station. Pehle ye (confidence-gated) chalta hai,
   * taaki LLM ise live-status na bana de aur "Kahan se jana hai?" na pooche. */
  /* ── Round-44 (user screenshots 28 Sep): "At what time 12013 arrived ldh on 27 sept" par
   * "Kahan jaana hai? Station bataiye." aur "12013 kal ludhiana kitne baje pahunchi thi?" par
   * live/history ka poora dump aa gaya tha — jabki ye ek hi cheez ka sawaal hai (us station par
   * train kitne baje pahunchi). Isliye arrival-at-station DETERMINISTIC jawab ab AI-first mode me
   * bhi pehle chalta hai (wahi gate-able rule: train + station route me + sirf arrival ka sawaal,
   * koi aur intent nahi) — model ho ya na ho, jawab sahi aur seedha. */
  /* Round-45: FULL AI-FIRST — ye sawaal bhi pehle MODEL ke paas jaata hai; ye deterministic
   * jawab sirf AI-off ya model-fail par (arrivalFamilyTurn(req, seeded)). */
  if (!aiFirst && !nameClarify && !isBookingMutation(req)) {
    const turn45 = await arrivalFamilyTurn(req, seeded);
    if (turn45) return turn45;
  }

  /* ── ROUND-11 (screenshot fix): "12411 kya ludhiana departure kar gyi?" —
   * deterministic departure-from-station jawab (live + route-order), taaki
   * SEARCH_TRAIN ka "Kahan jaana hai?" na aaye. */
  /* Round-45: FULL AI-FIRST — ye sawaal bhi pehle MODEL ke paas jaata hai; ye deterministic
   * jawab sirf AI-off ya model-fail par (departureTurn(req, seeded)). */
  if (!aiFirst && !nameClarify && !isBookingMutation(req)) {
    const turn45 = await departureTurn(req, seeded);
    if (turn45) return turn45;
  }

  if (!nameClarify && !isBookingMutation(req) && agenticConfigured()) {
    const det = deterministicUnderstand(req.text, {
      now: req.now ? new Date(req.now) : undefined,
      lastAsked: req.lastAsked ?? null,
      known: {
        from: seeded.origin,
        to: seeded.destination,
        date: seeded.date,
        passengerCount: seeded.passengers,
      },
    });
    const ctx = mergeAgentContext(seeded, det, req.text);
    /* Round-16j (screenshot: "koaa" → model ne "KOLKATA ke liye kaunsa
     * station? 1. KOAA" poochha): unresolved city/code ko model tak jaane se
     * PEHLE deterministic resolve karo — provider exactly EK station de (koi
     * choice nahi) to slot yahin bhar do. Ambiguous (Delhi/Kolkata city) ho to
     * pehle jaisa options-flow. */
    await autoResolveSingleStation(ctx, det);
    const follow = classifyFollowUp(req.text);
    const trainNo = resolveTrainNumber(req.text, ctx) ?? det.trainNumber;
    if (trainNo) ctx.selectedTrainNumber = trainNo;

    /* Round-16k (user: "pehle station, fir date"): ambiguous city (Kolkata/
     * Delhi/Mumbai…) abhi bhi unresolved hai → model ko mat bhejo (wo kabhi
     * date+station ek saath, kabhi alag poochhta tha). Deterministic: PEHLE
     * station options; station lock hone ke baad date guard apne aap date
     * poochhega. */
    /* Round-18m-30r (user: "AI pehle message se sab handle kare"): station-options bhi ab AI ka turn — system
     * prompt use SEARCH_STATIONS + options format deta hai, needs_choice relay tool-data se hota hai. Ye
     * deterministic ask sirf safety-net (AI_OWNS_FLOW=0) ya lookup-empty case ke liye. */
    if (!trainNo && !stationPick && process.env.AI_OWNS_FLOW === "0") {
      const ask = await askStationChoiceFirst(ctx, det);
      if (ask) {
        const codes = (ask.reply.match(/\b\d\.\s*([A-Z]{2,5})\b/g) ?? []).map((m) => m.replace(/^\d\.\s*/, ""));
        const phrasedAsk = await aiPhraseGate("station", { fallback: ask.reply, mustContain: codes, context: `user ne "${ask.side === "to" ? ctx.pendingDestinationChoice : ctx.pendingOriginChoice}" bola; options tool se aaye hain` });
        return {
          nlu: det,
          source: "nlu",
          context: ctx,
          tool: "searchStations",
          toolOk: true,
          reply: phrasedAsk.text,
          choice: ask.stations?.length ? { kind: "station", title: `${ask.city ?? ""} — kaunsa station?`.trim(), options: ask.stations.slice(0, 8).map((st) => ({ label: `${st.code} – ${st.name}`, value: st.code, sub: null })), sendTemplate: "{value}" } : null,
          interrupt: false,
          resumeAsk: null,
          resumeText: null,
          trains: null,
          confirmBook: false,
          missingFields: [ask.side === "to" ? "destination" : "origin"],
          modelUsed: null,
          latencyMs: 0,
          failureReason: null,
          engine: "deterministic",
          agenticFailureReason: null,
          grounded: true,
        };
      }
    }

    /* Round-18m-9: passenger-count gate — search se pehle.
     * Round-18m-30q (user: "AI khud samjhe ki passengers poochne hain"): agentic path mein ye gate ab sirf
     * SAFETY-NET hai — model ko pehle mauka: seat/journey tools PASSENGERS MISSING par reject hote hain, model
     * apne shabdon mein poochhta hai. Gate tab lagta hai jab AI configured na ho ya AI_OWNS_FLOW=0. */
    if (process.env.AI_OWNS_FLOW === "0") {
      const paxAsk = passengerGateAsk(ctx, det, req.text, { trainNo, stationPick });
      if (paxAsk) {
        ctx.bookingStage = "collecting";
        const phrased = await aiPhraseGate("passengers", { fallback: paxAsk, mustContain: [ctx.origin!.code, ctx.destination!.code], context: `route ${ctx.origin!.code} (${ctx.origin!.name ?? ""}) → ${ctx.destination!.code} (${ctx.destination!.name ?? ""}), date ${ctx.date}` });
        return {
          nlu: det,
          source: "nlu",
          context: ctx,
          tool: null,
          toolOk: null,
          reply: phrased.text,
          interrupt: false,
          resumeAsk: "passengers",
          resumeText: null,
          trains: null,
          confirmBook: false,
          missingFields: ["passengers"],
          modelUsed: null,
          latencyMs: 0,
          failureReason: null,
          engine: "deterministic",
          agenticFailureReason: null,
          grounded: true,
        };
      }
    }

    /* ── ROUND-13d: LIVE fast-path — "18310 kahan hai abhi" jaisi UNAMBIGUOUS
     * query par LLM round-trip (10s+) bekar hai. Train number + live-phrase,
     * aur number ke siwaay sirf stopwords bache (koi station/city token nahi)
     * → seedha getLiveStatus tool, instant deterministic. Messy/ambiguous
     * ("18310 cdg kahan hai", typo wali) query ab bhi agentic jaati hai. */
    const LIVE_PHRASE_RE = /\b(kahan hai|kahaan hai|kaha hai|abhi kahan|abhi kaha|kahan tak|kahan pahunchi|live status|running status|live hai)\b/i;
    /* Round-43d: "12054 late hai kya" jaisa sawaal bhi aaj ke run ka live sawaal hai — pehle ye model
     * par chhodne se model date poochh kar ruk jaata tha (battery: late-simple ❌). Ye pattern sirf
     * AAJ ke run ka late/delay poochhta hai (punctuality history "time par chalti hai ya late" isse
     * alag rehta hai — usme "late hai" nahi hota). */
    const LIVE_TODAY_RE = /\b(late hai|late h|late chal|delayed|delay hai|kitni der|der se chal)\b/i;
    if (!aiFirst && trainNo && (LIVE_PHRASE_RE.test(req.text) || LIVE_TODAY_RE.test(req.text))) {
      const liveStop = new Set([
        "kahan", "kahaan", "kaha", "hai", "hain", "abhi", "kya", "live", "status", "running",
        "right", "now", "ab", "tell", "me", "batao", "bata", "bataiye", "btado", "dijiye",
        "position", "currently", "train", "no", "number", "ki", "ka", "ke", "the", "is",
        "meri", "mera", "se", "par", "pe", "rahi", "gayi", "gai", "kar", "karo", "kahan", "hai",
        /* Round-16p: pichhle-din cues — deterministic parseStatusDate handle karta hai */
        "kal", "parson", "parso", "yesterday", "wali", "wala", "jo", "chali", "thi", "tha", "din", "pehle", "ago", "aaj", "today",
      ]);
      const leftovers = String(req.text)
        .toLowerCase()
        .split(/[^a-z0-9]+/)
        .filter(Boolean)
        .filter((t) => t !== String(trainNo).toLowerCase() && !liveStop.has(t))
        /* Round-18m: date tokens (2026-09-09 / 9 sep / 09/09) are handled by parseStatusDate. */
        .filter((t) => !/^\d{1,4}$/.test(t) && !/^(jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)[a-z]*$/.test(t));
      if (!leftovers.length) {
        /* Round-18m (user): date cue NAHI diya → pehle poochho KIS DIN ka run —
         * sirf wahi dates jinke liye API/web ke paas sach mein data hai. */
        const statusDate = parseStatusDate(req.text, req.now ? new Date(req.now) : new Date());
        if (!statusDate) {
          try {
            const options = await routedLiveDates(trainNo, ctx.selectedTrainName ?? null);
            if (options.length > 1) {
              ctx.intent = "LIVE_TRAIN_STATUS";
              ctx.pendingAsk = null;
              const name = ctx.selectedTrainName ?? (ctx.lastTrains ?? []).find((t) => t.number === trainNo)?.name ?? null;
              return {
                nlu: det,
                source: "nlu",
                context: ctx,
                tool: "getLiveStatus",
                toolOk: true,
                reply: `${trainNo}${name ? ` ${name}` : ""} — kis din wale run ka live status chahiye? Data in dates ke liye available hai: ${options.map((o) => o.label).join(", ")}. Neeche se chuniye.`,
                interrupt: false,
                resumeAsk: null,
                resumeText: null,
                trains: null,
                liveDates: { trainNumber: trainNo, trainName: name, options },
                confirmBook: false,
                missingFields: [],
                modelUsed: null,
                latencyMs: 0,
                failureReason: null,
                engine: "deterministic",
                agenticFailureReason: null,
                grounded: true,
              };
            }
          } catch {
            /* date discovery optional — fall through to direct live */
          }
        }
        try {
          const liveResult = await executeTool("getLiveStatus", {
            trainNumber: trainNo,
            trainName: ctx.selectedTrainName ?? undefined,
            /* Round-16p: "kal wali kahan hai" → pichhle din ka run. */
            date: statusDate,
          });
          if (liveResult.ok && liveResult.summary) {
            ctx.intent = "LIVE_TRAIN_STATUS";
            ctx.pendingAsk = null;
            return {
              nlu: det,
              source: "nlu",
              context: ctx,
              tool: "getLiveStatus",
              toolOk: true,
              reply: `${liveResult.summary}\n(Live railway data — verified.)`,
              interrupt: false,
              resumeAsk: null,
              resumeText: null,
              trains: null,
              confirmBook: false,
              missingFields: [],
              modelUsed: null,
              latencyMs: 0,
              failureReason: null,
              engine: "deterministic",
              agenticFailureReason: null,
              grounded: true,
            };
          }
        } catch {
          /* live fast-path fail — normal agentic flow continue */
        }
      }
    }

    /* Round-37 (user screenshot: train picker se "12054 … (ASR → HW) select ki" ke baad "12054 mein 2S
     * book krdo" — server context me origin/destination NULL the, isliye booking gate (client) route
     * na milne par form khol hi nahi paaya aur AI wahi class-sawaal dohraata raha). Picker tap ki
     * message me route khud user ne chuna hota hai — use context me lock karo (koi andaza nahi). */
    {
      const pick = /\b(\d{4,5})\b[^()]{0,60}\(\s*([A-Za-z]{2,6})\s*(?:→|->|—>|to)\s*([A-Za-z]{2,6})\s*\)/.exec(String(req.text ?? ""));
      if (pick) {
        const [, num, fromCode, toCode] = pick;
        const from = fromCode.toUpperCase();
        const to = toCode.toUpperCase();
        if (from !== to && !ctx.origin && !ctx.destination) {
          ctx.origin = { code: from, name: from, city: from };
          ctx.destination = { code: to, name: to, city: to };
        }
        if (!ctx.selectedTrainNumber) ctx.selectedTrainNumber = num;
      }
    }

    const capture: SearchCapture = { table: null };
    /* Round-18m-9: passenger-gate ka jawab ("2") akela model ko confuse karta
     * hai ("2 se kya matlab?") — slots poore hain to explicit search request
     * bana kar bhejo; origin/destination/date user ke hi rehte hain. */
    const paxResume =
      req.lastAsked === "passengers" &&
      Boolean(ctx.paxProvided && ctx.passengers && ctx.origin && ctx.destination && ctx.date && ctx.dateProvided) &&
      !trainNo &&
      /^\s*(\d|ek|do|teen|char|chaar|paanch|panch|chhe|che|one|two|three|four|five|six)\b/i.test(req.text);
    const agenticText = paxResume
      ? `${ctx.origin!.name ?? ctx.origin!.code} (${ctx.origin!.code}) se ${ctx.destination!.name ?? ctx.destination!.code} (${ctx.destination!.code}) ${ctx.date} ko ${ctx.passengers} passengers ke liye trains aur seat availability dhundo`
      : req.text;
    try {
      const turn = await runAgenticTurn({
        text: agenticText,
        now: req.now,
        history: req.history,
        capture,
        known: {
          origin: ctx.origin?.code ?? null,
          destination: ctx.destination?.code ?? null,
          date: ctx.date ?? det.date ?? null,
          dateProvided: Boolean(ctx.dateProvided || det.date),
          trainNumber: trainNo ?? null,
          classCode: ctx.classCode ?? det.classCodes?.[0] ?? null,
          /* Round-18m-30q: pax sirf tab jab user ne bataye (paxProvided) — warna tool precondition model se poochhwayegi. */
          passengers: (ctx.paxProvided ? ctx.passengers : null) ?? det.passengerCount ?? null,
          stationPicked: stationPick ? (stationPick.side === "to" ? "destination" : "origin") : null,
          /* Round-9 (Agra-bug): pending cluster-city context se — turn-1 ka
           * unresolved "Agra" turn-2 tak yaad rahe. */
          destinationAmbiguous: !ctx.destination ? (ctx.pendingDestinationChoice ?? det.unresolvedTo ?? null) : null,
          originAmbiguous: !ctx.origin ? (ctx.pendingOriginChoice ?? det.unresolvedFrom ?? null) : null,
        },
      });
      // Station-pick already resolve ho chuka hai (server-verified) par model
      // wahi station-options sawaal DOBARA pooch raha hai → model ka reply
      // discard, deterministic path real search ke saath jawab dega.
      const pickReasked = Boolean(stationPick && turn.reply && asksStationChoice(turn.reply));
      if (pickReasked) agenticFailureReason = "station_pick_reask";
      // Station ambiguity PENDING hai (det.unresolvedTo) par model ne koi tool
      // succeed nahi kiya aur be-jaawab "provider se nahi mil" summary de di —
      // deterministic path real station options poochega (useful reply).
      const unhelpfulNoData =
        Boolean(det.unresolvedTo) &&
        turn.steps.every((st) => !st.ok) &&
        /provider se nahi mil|unavailable|andaza nahi lagaunga/i.test(String(turn.reply ?? ""));
      if (unhelpfulNoData) agenticFailureReason = "unhelpful_summary_with_pending_choice";
      /* Round-18m-30r (user rule: STATION pehle, date baad): city ambiguous hai, model ne SEARCH_STATIONS/
       * options diye bina date/pax poochh liya ya kuch aur bol diya → model ka reply discard; deterministic
       * station-options (tool-data) chalenge. AI flow ka malik hai, par ye order nahi tod sakta. */
      const pendingCity = (!ctx.destination ? ctx.pendingDestinationChoice ?? det.unresolvedTo : null) ?? (!ctx.origin ? ctx.pendingOriginChoice ?? det.unresolvedFrom : null) ?? null;
      let skippedStationStep = false;
      if (pendingCity && !trainNo && !stationPick && !turn.steps.some((st) => st.tool === "SEARCH_STATIONS" || st.tool === "SEARCH_TRAINS" || st.tool === "JOURNEY_ANALYZE" || st.tool === "RANK_JOURNEY_OPTIONS") && !mentionsStationOptions(String(turn.reply ?? ""))) {
        /* Sirf ASLI multi-station city par override (lookup 2+ stations de) — NLU ka garbage ("Ko Ldh") nahi. */
        try {
          const chk = await routedStationSearch(String(pendingCity));
          skippedStationStep = chk.stations.length >= 2;
        } catch {
          skippedStationStep = false;
        }
      }
      if (skippedStationStep) agenticFailureReason = "station_step_skipped_by_model";
      /* Round-16o: agentic ne bina kisi successful tool ke "provider se nahi
       * mil pa rahi" de diya, par sawaal general/knowledge type hai → reply
       * discard; neeche UNIVERSAL WEB FALLBACK (KB/Wikipedia/scrape) jawab
       * dega. User rule: general sawaal kabhi "provider se nahi mil" par na ruke. */
      const unhelpfulGeneral =
        !unhelpfulNoData &&
        turn.steps.every((st) => !st.ok) &&
        /provider se nahi mil|andaza nahi lagaunga/i.test(String(turn.reply ?? "")) &&
        webRescueEligible(String(req.text ?? ""), turn.steps);
      if (unhelpfulGeneral) agenticFailureReason = "unhelpful_summary_general_question";
      /* ── Round-45 ADEQUACY NET (model-first ka insurance) ────────────────────────────────────────
       * Model PEHLE chalta hai (AI-first — user ka explicit choice). Par agar uska jawab us sawaal ka
       * jawab hi nahi hai (train ki summary bhej di, "Kahan jaana hai?" poochh liya) aur hamare paas
       * usi sawaal ka REAL tool-data wala jawab maujood hai → wahi do. Koi per-question rule nahi:
       * sawaal ki qism (seat / arrival / live) + jawab me expected data hai ya nahi — bas itna.
       * Jawab "theek lag raha hai" par bhi sahi ho, iske liye model ka jawab hi rakha jaata hai. */
      if (aiFirst && turn.reply && !isBookingMutation(req) && !pickReasked && !unhelpfulNoData && !unhelpfulGeneral && !skippedStationStep) {
        const kind45: AnswerKind45 | null = isPickFollowup(String(req.text ?? ""), req.history)
          ? "pick"
          : answerKind45(String(req.text ?? ""));
        if (kind45 && !replyAdequateFor45(kind45, String(turn.reply), String(req.text ?? ""))) {
          const resc45 = await deterministicRescue45(kind45, req, seeded);
          if (resc45) {
            /* Prod telemetry (jaise modelFallbacks): model ne kya diya tha — andaza nahi, log. */
            console.log(JSON.stringify({ adequacyRescue: kind45, modelHad: String(turn.reply).slice(0, 200) }));
            return { ...resc45, agenticFailureReason: "inadequate_reply_rescued" };
          }
        }
      }
      if (turn.reply && !pickReasked && !unhelpfulNoData && !unhelpfulGeneral && !skippedStationStep) {
        /* Round-33: model ne jo pax khud samjha (jaise "Kal,1" → 1) wo ctx me yaad rakho —
         * agle turn me AI dobara "kitne passengers?" nahi poochhega. */
        if (!(ctx.paxProvided && ctx.passengers) && capture.passengers) {
          ctx.passengers = capture.passengers;
          ctx.paxProvided = true;
        }
        // Memory (2026-09-05): search hui to trains ctx mein yaad rakho.
        rememberSearch(ctx, capture.table);
        // User instruction (2026-09-05): "waise hum continue kar sakte hain"
        // jaisi proactive lines KABHI nahi — user poochhe tabhi aayengi.
        // interrupt/resume mechanism band; slot-filling sawaal reply ke andar hi aate hain.
        void neverAutoBook(det.intent, req.bookingFlow);
        /* ── Round-59 (user screenshot: Leg 1/Leg 2 dikh hi nahi rahe) ──────────────────────────────
         * Plan maanga gaya tha par model ne sirf TEXT diya (kabhi kabhi ek markdown table) aur koi plan
         * payload nahi bheja. Us haalat me card hi nahi banta tha aur user ke paas adhoora text bachta tha.
         * Ab: plan ka sawaal + slots + model ka payload nahi → wahi engine (planJourney) chalता hai jo
         * baaki har jagah chalta hai (RANK_JOURNEY_OPTIONS/JOURNEY_ANALYZE). Ye rescue hai (R45 ka usool:
         * deterministic sirf jab model na de) — logic/data wahi, sirf guarantee ki payload kabhi khaali na
         * jaaye. Model ka reply text waisa hi rehta hai (jhooth nahi, kuch chhupaya nahi). */
        /* Round-60: city-level station ambiguity par dropdown (agar model ne choice payload na diya ho). */
        let choicePayload = capture.choice ?? null;
        if (!choicePayload) {
          choicePayload = await cityStationAmbiguity({ from: det.from ?? null, to: det.to ?? null }, String(req.text ?? "")).catch(() => null);
          if (choicePayload) console.log(JSON.stringify({ choiceRescue: choicePayload.title }));
        }
        let planPayload = capture.plan ?? null;
        if (!planPayload && isPlanAsk(req.text) && ctx.origin?.code && ctx.destination?.code && ctx.date) {
          planPayload = await planJourney({
            from: ctx.origin.code,
            to: ctx.destination.code,
            date: ctx.date,
            travelClass: ctx.classCode ?? null,
            preference: "best_overall",
            includeConnections: true,
            includeAlternativeDates: false,
            /* capture.table rows AgentTrainRow hote hain (TrainResult nahi) — engine ko trains pass nahi
             * karte, wo khud route board laayega (wahi source jo baaki jagah use hota hai). */
            trains: undefined,
            searchProvider: undefined,
            passengers: ctx.paxProvided ? ctx.passengers : null,
          }).catch(() => null);
          if (planPayload) console.log(JSON.stringify({ planPayloadRescue: ctx.origin.code + "→" + ctx.destination.code, date: ctx.date }));
        }
        return {
          nlu: det,
          source: "nlu",
          context: ctx,
          tool: null,
          toolOk: turn.ok ? true : false,
          reply: ensureBookingOffer(turn.reply, req.text),
          interrupt: false,
          resumeAsk: null,
          resumeText: null,
          trains: capture.table,
          journey: planPayload,
          alternatives: capture.alternatives ?? null,
          trainPicker: capture.trainPicker ?? null,
          choice: choicePayload,
          confirmBook: false,
          missingFields: missingOf({
            from: det.from,
            to: det.to,
            date: det.date,
            passengerCount: det.passengerCount,
          }),
          modelUsed: turn.modelUsed,
          modelFallbacks: turn.modelFallbacks ?? [],
          latencyMs: turn.latencyMs,
          failureReason: null,
          engine: "agentic_tool_calling",
          toolTrace: turn.steps,
          agenticFailureReason: turn.ok ? null : (turn.failureReason ?? null),
          grounded: turn.grounded,
          /* Round-32: model ne khud jo agla kadam chuna (agar diya ho). */
          nextActions: turn.nextActions ?? null,
          /* Round-53: model ke FIND_SEATS ka live data — app isi se cards banata hai (text=cards). */
          seatCapture: capture.seat ?? null,
        };
      }
      // Agentic chala par reply nahi bana — wajah record karo, fallback chalo.
      if (!turn.ok || !turn.reply) agenticFailureReason = turn.failureReason ?? "no_reply";
    } catch (err) {
      // Deterministic fallback chalega par wajah record hogi.
      agenticFailureReason = `throw:${err instanceof Error ? err.message : "unknown"}`;
    }
  }

  /* ── Round-45: FULL AI-FIRST ka promise — model fail (timeout/error/empty) hua to usi sawaal ka
   * VERIFIED deterministic jawab turant (wahi handlers + wahi tools: routeCheck/CHECK_AVAILABILITY/
   * routedLiveStatus) — warna "Kahan jaana hai?" jaisa adhoora jawab chala jaata (R44 screenshots). */
  if (aiFirst && agenticFailureReason && !isBookingMutation(req)) {
    /* R55g: model fail/timeout par bhi "in me se best" ka jawab chunne wala hi ho — warna deterministic
     * path poori list dump kar deta hai (exactly wahi jo user ne screenshot me pakda). */
    const kindFail: AnswerKind45 | null = isPickFollowup(String(req.text ?? ""), req.history)
      ? "pick"
      : answerKind45(String(req.text ?? ""));
    const rescue = await deterministicRescue45(kindFail, req, seeded);
    if (rescue) return { ...rescue, agenticFailureReason };
  }

  /* ── 2) DETERMINISTIC FALLBACK (existing architecture, preserved) ── */
  const seeded2 = seedContext(req);
  /* Round-16g: deterministic NLU ko bhi SEEDED slots do (sirf req.known nahi
   * — context wale bhi). Warna "NDLS" (destination pick) ko NLU `from`
   * samajh leta tha kyunki known.from khaali tha → origin LDH overwrite. */
  const understood = await runUnderstand({
    text: req.text,
    lastAsked: req.lastAsked ?? (stationPick ? (stationPick.side as "to" | "from") : null),
    known: {
      ...(req.known ?? {}),
      from: req.known?.from ?? seeded2.origin ?? null,
      to: req.known?.to ?? seeded2.destination ?? null,
      /* Round-18m-30o: seedContext ne stale client date/pax ko reject kiya ho to NLU ko bhi wahi sach mile —
       * warna NLU known.date se date bhar deta tha aur plan bina poochhe ban jaata tha (prod screenshot). */
      date: (seeded2.dateProvided ? seeded2.date : null) ?? null,
      passengerCount: (seeded2.paxProvided ? seeded2.passengers : null) ?? null,
    },
    now: req.now,
  });
  /* Naam-se-resolve (upar hua) deterministic ctx par bhi apply ho — warna
   * fallback pichhli selected train (galat) ka jawab de deta tha. */
  if (nameResolvedTrain) {
    seeded2.selectedTrainNumber = nameResolvedTrain.number;
    seeded2.selectedTrainName = nameResolvedTrain.name;
  }
  /* Station-pick deterministic path mein bhi apply ho (seedContext req se
   * padta hai, pick upar resolve hua tha). */
  if (stationPick) {
    if (stationPick.side === "to" && !seeded2.destination) {
      seeded2.destination = { code: stationPick.code, name: stationPick.name, city: stationPick.city };
    } else if (stationPick.side === "from" && !seeded2.origin) {
      seeded2.origin = { code: stationPick.code, name: stationPick.name, city: stationPick.city };
    }
    /* Round-16g: pick ek side ke liye tha — NLU ne agar wahi code doosri side
     * par daal diya to wo galat hai; sirf picked side rakho. */
    const picked = stationPick.code;
    if (stationPick.side === "to" && understood.nlu.from?.code === picked) understood.nlu.from = undefined;
    if (stationPick.side === "from" && understood.nlu.to?.code === picked) understood.nlu.to = undefined;
    /* Round-18m-7 (prod repro: "kal" + Varanasi → "Bsb" → date dobara poochhi):
     * NLU "Bsb" ko unresolvedTo maanta hai → mergeAgentContext ise NAYA route
     * samajh kar date reset kar deta tha. Pick server-verified hai → unresolved hatao. */
    understood.nlu.unresolvedTo = stationPick.side === "to" ? undefined : understood.nlu.unresolvedTo;
    understood.nlu.unresolvedFrom = stationPick.side === "from" ? undefined : understood.nlu.unresolvedFrom;
  }
  const ctx = mergeAgentContext(seeded2, understood.nlu, req.text);
  await autoResolveSingleStation(ctx, understood.nlu); // Round-16j
  const follow = classifyFollowUp(req.text);
  const trainNo = resolveTrainNumber(req.text, ctx) ?? understood.nlu.trainNumber;
  if (trainNo) ctx.selectedTrainNumber = trainNo;

  let tool = decideTool(follow, ctx, understood.nlu.intent);
  /* ── AVAILABILITY/FARE SLOT-RESUME (screenshot fix 2026-09-06, bug (c)):
   * pichhle turn ne availability/fare ke liye slots/class maange the
   * (lastToolOk=false); user ka agla message "Date aaj ki ludhiana se hw ki"
   * NLU ko naya SEARCH_TRAIN lagta hai — par asal mein wo pichhle sawaal
   * ke slots ka jawab hai (route+date ab ctx mein merge ho chuke hain).
   * Naya train number text mein na ho to availability/fare RESUME karo,
   * naya train-search mat chalao ("Kahan jaana hai?" ghalat jawab tha). */
  const prevFailedSlotTool =
    (seeded2.lastTool === "getAvailability" || seeded2.lastTool === "getFare") && seeded2.lastToolOk === false
      ? seeded2.lastTool
      : null;
  const textHasNewTrainNo = /\b\d{4,6}\b/.test(String(req.text ?? ""));
  if (
    prevFailedSlotTool &&
    ctx.selectedTrainNumber &&
    !textHasNewTrainNo &&
    (understood.nlu.intent === "SEARCH_TRAIN" ||
      understood.nlu.intent === "BOOK_TRAIN" ||
      understood.nlu.intent === "NONE") &&
    (ctx.classCode || (ctx.origin && ctx.destination) || ctx.dateProvided)
  ) {
    tool = prevFailedSlotTool;
  }
  /* General-fact sawaal (2026-09-06 screenshot bug 1): "12014 ki top speed"
   * par TRAIN_SCHEDULE/getTimetable chal jaata tha — user ko timetable milta
   * tha, speed ka jawab nahi. Fact-sawal par railway tool mat chalao —
   * deterministic web fallback (neeche) labeled fact jawab dega. */
  if (tool && GENERAL_FACT_RE.test(String(req.text ?? ""))) tool = null;
  /* Round-18l (screenshot: "Amritsar se Goa is weekend, koi direct confirm
   * seat hai?") — availability/fare words WITHOUT any train → ye ROUTE ka
   * sawaal hai (journey plan availability probe karta hi hai). Pehle
   * getAvailability chal kar "Train, date, stations aur class chahiye."
   * bolta tha. Train context na ho to searchTrains/slot flow par jao. */
  if (
    (tool === "getAvailability" || tool === "getFare") &&
    !trainNo &&
    !ctx.selectedTrainNumber &&
    (understood.nlu.from || understood.nlu.to || understood.nlu.unresolvedFrom || understood.nlu.unresolvedTo || ctx.origin || ctx.destination || ctx.pendingDestinationChoice || ctx.pendingOriginChoice)
  ) {
    tool = ctx.origin && ctx.destination && ctx.dateProvided ? "searchTrains" : null;
  }
  ctx.lastTool = tool;

  /* Concept-question detector (2026-09-06 #4/#7): "2s class kya hoti hai" /
   * "vande bharat kya hoti hai" jaise sawaal search/booking ya naam-clarify
   * list nahi — jawab maangte hain. Atlas-guard + naam-clarify-guard dono
   * yahi use karte hain. */
  const GENERAL_QUESTION_RE =
    /\b(kya hota|kya hoti|kya hote|ka matlab|what is|kya hai|kaise hota|kaise hoti|kab banta|kab khulta|kab milta|kab milti|kitna hota|kitni hoti|matlab kya|sabse\s+(tez|tezi|jaldi|lambi|lamba|lambe|badi|bada|bade|choti|chota|chote|sasti|sasta|saste|acchi|accha|acche|achhi|famous|popular|purani|purana|purane|nayi|naya|naye)|kaunsi hai|kaun sa hai|kaun si hai|kitne hain|kitni hai|kitna hai|kab hui|kab hua|kab bani|kab shuru|kab chalu|kahan bani|kitna lamba|kitni lambi|kitna route|kitna cover|cover karta|cover karti|pehli|pehla|shuruaat|ke bare mein|ke baare mein)\b/i;
  const hasJourneyContext = Boolean(
    ctx.origin || ctx.destination || ctx.selectedTrainNumber || /\b\d{5}\b/.test(String(req.text ?? "")),
  );
  /* Train-NAAM resolve ne concept-Q par "10 trains mili — kaunsi?" clarify
   * de di thi (vande bharat) — concept par list NAHI, jawab chahiye. Universal
   * KB/web fallback ko reply dene do. */
  if (nameClarify && GENERAL_QUESTION_RE.test(String(req.text ?? "")) && !hasJourneyContext) {
    nameClarify = null;
  }

  /* Naam ambiguous/zero tha — model skip ho chuka hai; yahan honest clarify
   * hi final reply hai (koi tool call NAHI, koi galat train ka data NAHI). */
  if (nameClarify) {
    void neverAutoBook(understood.nlu.intent, req.bookingFlow);
    return {
      nlu: understood.nlu,
      source: understood.source,
      context: ctx,
      tool: null,
      toolOk: null,
      reply: nameClarify,
      interrupt: false,
      resumeAsk: null,
      resumeText: null,
      trains: null,
      trainPicker: namePicker,
      confirmBook: false,
      missingFields: understood.missingFields,
      modelUsed: understood.modelUsed,
      latencyMs: understood.latencyMs,
      failureReason: understood.failureReason,
      engine: "deterministic",
      agenticFailureReason: "train_name_clarify",
      grounded: true,
    };
  }

  let reply: string | null = null;
  let toolOk: boolean | null = null;

  /* Atlas/search/booking intents ka deterministic answer — pehle yahan
   * empty reply jaata tha (SELECT_* bhi aur "amritsar se delhi jaana hai"
   * jaise SEARCH/BOOK intents bhi). Ya station clarification, ya missing-slot
   * ask, ya real search — kabhi khali nahi. */
  let atlasTrace: ToolTraceStep | null = null;
  let atlasGrounded: boolean | undefined;
  const atlasPref = ATLAS_PREF[understood.nlu.intent];
  const searchishIntent = Boolean(atlasPref) || understood.nlu.intent === "SEARCH_TRAIN" || understood.nlu.intent === "BOOK_TRAIN";
  let detTrains: AgentTrainTable | null = null;
  let detJourney: JourneyPlan | null = null;
  let detChoice: import("./agentic.js").ChoiceBlock | null = null;
  // tool === "searchTrains" ka deterministic executor hai hi nahi (agentic
  // engine ka tool hai) — searchish intent + complete slots par atlasFallback
  // hi real search + table + memory dega. Warna agentic timeout par EMPTY reply.
  /* Screenshot fix (2026-09-06 #4): "2s class kya hoti hai" jaisa
   * concept-question bhi SEARCH intent ban jaata tha → slot-ask ("Kahan se
   * jaana hai?"). General-question pattern + koi journey context (route/
   * train number) nahi → search MAT karo — universal KB/web fallback ko
   * reply dene do. */
  if (GENERAL_QUESTION_RE.test(String(req.text ?? "")) && !hasJourneyContext) {
    /* concept-question — atlasFallback skip */
  } else if ((!tool || tool === "searchTrains") && searchishIntent) {
    const outcome = await atlasFallback(atlasPref ?? "best", ctx, understood.nlu);
    reply = outcome.reply;
    toolOk = outcome.ok;
    atlasTrace = outcome.trace;
    atlasGrounded = outcome.grounded;
    detTrains = outcome.trains;
    detJourney = outcome.journey ?? null;
    detChoice = outcome.choice ?? null;
    rememberSearch(ctx, detTrains);
  }

  /* Station-choice reply ("4"/"NDLS") ka deterministic answer — slot context
   * mein already filled hai. Slots complete → REAL search + grounded top
   * trains (client bhi intent-carry se TrainBoard kholta hai); missing →
   * honest agla sawaal. Kabhi khali nahi. */
  if (!tool && !reply && stationPick) {
    const other = stationPick.side === "to" ? ctx.origin : ctx.destination;
    /* Round-16h: date user ne di ho tabhi search — warna neeche resume-line date poochegi.
     * Round-18m-30s (prod screenshot LDH→MTJ: "1" ke baad seedha plan, pax nahi poochha): ye DETERMINISTIC
     * fallback path (AI ka reply reject hua) bhi wahi rule maane jo tools maante hain — passengers ke bina
     * koi seat search/plan nahi. Station lock + date hai, pax nahi → pax poochho (AI wording, fallback text). */
    if (other && ctx.date && ctx.dateProvided && !(ctx.paxProvided && ctx.passengers)) {
      ctx.bookingStage = "collecting";
      const from = stationPick.side === "to" ? other.code : stationPick.code;
      const to = stationPick.side === "to" ? stationPick.code : other.code;
      const fb = `Theek hai — ${from} → ${to}, ${ctx.date}. Kitne passengers hain? (1–6) Seats usi hisaab se check karunga.`;
      reply = (await aiPhraseGate("passengers", { fallback: fb, mustContain: [from, to], context: `route ${from} → ${to} lock ho gaya, date ${ctx.date}; ab party size chahiye tabhi seats sahi milengi` })).text;
    } else if (other && ctx.date && ctx.dateProvided) {
      try {
        const search = await searchTrainsRouted({ from: ctx.origin!.code, to: ctx.destination!.code, date: ctx.date });
        const top = search.trains
          .slice(0, 3)
          .map((t) => `${t.number} ${t.name} (${t.departure}→${t.arrival})`)
          .join(", ");
        // User feedback (2026-09-05): list ke saath SABSE FAST upfront — dobara poochhna na pade.
        const withDur = search.trains.filter((t) => t.durationMinutes != null);
        const fastest = withDur.length
          ? withDur.reduce((b, t) => (t.durationMinutes < (b.durationMinutes ?? Infinity) ? t : b))
          : null;
        const fastestLine = fastest ? ` Sabse fast: ${fastest.number} ${fastest.name} (${fastest.durationLabel}).` : "";
        let sibling: Awaited<ReturnType<typeof sameCityFallbackSearch>> = null;
        if (!search.trains.length) sibling = await sameCityFallbackSearch(ctx.origin!.code, ctx.destination!.code, ctx.date!);
        if (sibling) {
          const chg = sibling.changed === "destination" ? ctx.destination! : ctx.origin!;
          const newCode = sibling.changed === "destination" ? sibling.to : sibling.from;
          const newSt = { code: newCode, name: (sibling.trains[0] && (sibling.changed === "destination" ? sibling.trains[0].to.name : sibling.trains[0].from.name)) || newCode, city: chg.city ?? chg.name };
          if (sibling.changed === "destination") ctx.destination = newSt; else ctx.origin = newSt;
          reply = `${ctx.origin!.code === newCode ? chg.code : ctx.origin!.code} → ${sibling.changed === "destination" ? chg.code : ctx.destination!.code} (${ctx.date}) ke liye seedhi koi train nahi hai — lekin usi shehar ke ${newCode} (${newSt.name}) tak ${sibling.trains.length} trains hain. Main ${sibling.from} → ${sibling.to} dikha raha hoon (station badla hai, note kar lo).`;
          search.trains = sibling.trains;
          search.provider = sibling.provider;
        }
        reply = reply || (search.trains.length
          ? `Theek hai — ${ctx.origin!.code} → ${ctx.destination!.code} (${ctx.date}): ${search.trains.length} trains mili.${fastestLine} Poori list neeche table mein hai.`
          : `${ctx.origin!.code} → ${ctx.destination!.code} (${ctx.date}) ke liye koi train nahi mili — main andaza nahi lagaunga.`);
        toolOk = search.trains.length > 0;
        detTrains = tableFromSearch(ctx.origin!.code, ctx.destination!.code, ctx.date!, search.trains.slice(0, 12));
        rememberSearch(ctx, detTrains);
        /* Round-18m-7: station-pick ke baad bhi wahi JOURNEY PLANNER card (BEST FOR
         * YOU / summary / seat-wale connections) — plain table nahi. */
        if (search.trains.length) {
          try {
            detJourney = await planJourney({ from: ctx.origin!.code, to: ctx.destination!.code, date: ctx.date!, travelClass: ctx.classCode ?? null, preference: "best_overall", includeConnections: true /* Round-18m-30g: leg-1/leg-2 HAMESHA (user rule) */, includeAlternativeDates: false, trains: search.trains, searchProvider: search.provider, passengers: ctx.paxProvided ? ctx.passengers : null });
          } catch {
            detJourney = null;
          }
        }
        atlasTrace = {
          step: 1,
          tool: "SEARCH_TRAINS",
          args: { origin: ctx.origin!.code, destination: ctx.destination!.code, date: ctx.date },
          ok: search.trains.length > 0,
          source: search.provider,
          summary: `${search.trains.length} trains (${search.provider})`,
          latencyMs: 0,
        };
        atlasGrounded = true;
      } catch {
        reply = `Theek hai — ${other.code} → ${stationPick.code} (${ctx.date}). Trains check kar raha hoon — list turant aa rahi hai.`;
      }
    } else if (other) {
      reply = (await aiPhraseGate("date", { fallback: `Theek hai — ${other.code} → ${stationPick.code}. Kis date ko jaana hai?`, mustContain: [other.code, stationPick.code], context: `route ${other.code} → ${stationPick.code} (${stationPick.name}) lock ho gaya; ab date chahiye` })).text;
    } else {
      reply = `Theek hai — ${stationPick.code} (${stationPick.name}). Kahan se jaana hai?`;
    }
  }

  /* Station choice PENDING hai (pichhla AI turn options pooch raha tha) par
   * number map nahi ho paya (model ne partial examples diye the) — honest
   * re-ask, kabhi khali/confusing nahi. */
  const lastAssistant = [...(req.history ?? [])].reverse().find((h) => h.role === "assistant")?.content;
  const stationChoicePending = Boolean(lastAssistant && mentionsStationOptions(lastAssistant)) && !(ctx.origin && ctx.destination);
  const bareIndex = String(req.text ?? "").trim().match(/^(\d{1,2})[.!]?$/);
  if (!tool && !reply && stationChoicePending && bareIndex) {
    reply = "Number se station confirm nahi kar paya — station ka naam ya 4-letter code bataiye (jaise NDLS, DLI).";
  }
  /* Round-18m: "1" after a train list = 1st train of the list → selected;
   * show what we know and offer the next step (date/class already in ctx →
   * availability is one word away). Never books. */
  if (!tool && !reply && bareIndex && trainNo && ctx.lastTrainNumbers.includes(trainNo)) {
    const row = (ctx.lastTrains ?? []).find((t) => t.number === trainNo);
    ctx.selectedTrainNumber = trainNo;
    if (row?.name) ctx.selectedTrainName = row.name;
    const route = ctx.origin && ctx.destination ? ` ${ctx.origin.code}→${ctx.destination.code}` : "";
    const when = ctx.dateProvided && ctx.date ? ` (${ctx.date})` : "";
    reply = `Theek hai — ${trainNo}${row?.name ? ` ${row.name}` : ""}${route}${when} select ki. Kaunsi class ka seat/fare dekhna hai — SL, 3A, 2A, CC, EC? (Booking sirf aapke "Confirm & Book" par hogi.)`;
    toolOk = true;
  }

  if (tool === "getCoachPosition" && !trainNo) {
    reply = "Kaunsi train ki coach position? 5-digit train number boliye.";
  } else if ((tool === "getAvailability" || tool === "getFare") && trainNo && (!ctx.classCode || !ctx.dateProvided)) {
    /* ── SMART SLOT-ASK (screenshot fix 2026-09-06, bug (b)): train context
     * mein hai, stations auto-route honge; sirf jo missing hai wahi poochho.
     * Round-16i: DATE bhi mandatory (aaj default nahi) — class ke saath ek
     * hi line mein. (Agla "CC"/"kal" jaisa jawab slot-resume se tool chala dega.) */
    const routeBit = ctx.origin && ctx.destination ? ` ${ctx.origin.code}→${ctx.destination.code}` : "";
    const what = tool === "getFare" ? "fare" : "availability";
    if (!ctx.dateProvided && !ctx.classCode) {
      reply = `${trainNo}${routeBit} ka ${what} — kis date ka chahiye (aaj/kal/parso ya tareekh), aur kaunsi class — CC, EC, SL, 2A, 3A?`;
    } else if (!ctx.dateProvided) {
      reply = `${trainNo}${routeBit} ${ctx.classCode} ka ${what} kis date ka chahiye — aaj, kal, parso ya tareekh batao.`;
    } else {
      reply = `${trainNo}${routeBit} ${ctx.date} ki kaunsi class — CC, EC, SL, 2A, 3A?`;
    }
    ctx.lastToolOk = false;
  } else if (tool && tool !== "searchTrains") {
    /* FARE AUTO-ROUTE (user report 2026-09-06: "12014 ki CC fare" par
     * stations missing the — deterministic path RAILWAY CALL hi nahi karta
     * tha, seedha "unavailable" bol deta tha). Agentic path jaisa hi:
     * stations missing + train number hai → timetable se first/last stop. */
    let fareOrigin = ctx.origin?.code ?? null;
    let fareDestination = ctx.destination?.code ?? null;
    if ((tool === "getFare" || tool === "getAvailability") && trainNo && (!fareOrigin || !fareDestination)) {
      try {
        const sched = await routedSchedule(trainNo);
        const stops = sched.schedule && "stops" in sched.schedule ? sched.schedule.stops ?? [] : [];
        if (stops.length) {
          fareOrigin = fareOrigin ?? stops[0].code;
          fareDestination = fareDestination ?? stops[stops.length - 1].code;
        }
      } catch {
        /* timetable nahi mili — seedha ctx ke stations se try */
      }
    }
    /* Round-16p: live status ke liye booking-date (ctx.date = future journey)
     * NAHI — status-date (kal/parson/7 Sep = PICHHLA run) chahiye. */
    const liveDate = tool === "getLiveStatus" ? parseStatusDate(req.text, req.now ? new Date(req.now) : new Date()) : undefined;
    const result = await executeTool(tool as ToolName, {
      query: req.text,
      origin: fareOrigin ?? undefined,
      destination: fareDestination ?? undefined,
      date: tool === "getLiveStatus" ? liveDate : ctx.date ?? undefined,
      trainNumber: trainNo,
      trainName: ctx.selectedTrainName ?? undefined,
      classCode: ctx.classCode ?? undefined,
      passengers: ctx.passengers ?? 1,
      pnr: understood.nlu.pnr,
    });
    toolOk = result.ok;
    ctx.lastToolOk = result.ok;
    /* Fail par executeTool ka SAHI summary prefer karo (user report
     * 2026-09-06): "Train, date, stations chahiye" jaisa actionable message
     * factReplyUnavailable ke generic "Fare abhi available nahi hai" se
     * overwrite ho raha tha — user ko lagta tha fare API se hi nahi aa raha! */
    reply = result.ok ? result.summary : result.summary || factReplyUnavailable(follow ?? tool);
    if (result.ok && tool === "getLiveStatus") {
      reply = `${result.summary}\n(Live railway data — gadh ke nahi.)`;
    }
  } else if (follow === "live" && !trainNo) {
    reply = "Train number kya hai? 5-digit number boliye.";
  } else if (follow === "coach" && !trainNo) {
    reply = "Kaunsi train ki coach position? 5-digit train number boliye.";
  } else if (!reply && follow === "fare" && (!ctx.selectedTrainNumber || !ctx.classCode || !ctx.date || !ctx.origin || !ctx.destination)) {
    reply = "Fare ke liye train, class aur date chahiye. Jo missing hai woh batao — main figure invent nahi karunga.";
  } else if (!reply && follow === "availability" && (!ctx.selectedTrainNumber || !ctx.classCode || !ctx.date)) {
    /* Round-18l: route-level seat sawaal ka jawab atlasFallback de chuka ho
     * (station/date ask ya plan) to overwrite mat karo. */
    reply = "Availability ke liye train, class aur date chahiye.";
  }

  // User instruction (2026-09-05): proactive "waise hum continue kar sakte hain"
  /* GENERAL-FACT WEB FALLBACK (user 2026-09-06: "agar data API se na mile to
   * verified sites se le aaye"): "top speed / kitni tez / kab chalu hui" jaise
   * sawaal API/KB se aate hi nahi. Model timeout par bhi jawab mile —
   * deterministic web lookup (Wikipedia/DDG), SAAPH label ke saath. */
  let factWebTried = false;
  if (!reply && !tool && GENERAL_FACT_RE.test(String(req.text ?? ""))) {
    factWebTried = true;
    /* English query banwao — live test: Hinglish raw text par DDG/Wikipedia
     * 0 results dete hain, "Amritsar Shatabdi 12014 top speed" par dete hain. */
    const rawText = String(req.text ?? "");
    let factKeyword = "information";
    if (/\b(top speed|max speed|average speed|kitni tez|kitna tez|speed kya|speed kitni)\b/i.test(rawText)) factKeyword = rawText.includes("average") ? "average speed" : "top speed";
    else if (/\b(kab shuru|kab chalu|kab start|kitne saal|kab bani|history|pehli train|sabse pehli)\b/i.test(rawText)) factKeyword = "history";
    else if (/kitne coach/i.test(rawText)) factKeyword = "coaches";
    else if (/engine ka naam/i.test(rawText)) factKeyword = "locomotive";
    let subject = "";
    /* Follow-up ("maine to top speed poochi thi?") mein number text me nahi —
     * context ki selected train se le (screenshot bug 4 fix). */
    const factNum = rawText.match(/\b(\d{5})\b/)?.[1] ?? ctx.selectedTrainNumber ?? null;
    let factTrainName = "";
    if (factNum) {
      try {
        const info = await routedTrainInfo(factNum);
        const nm = info.info?.trainName ?? "";
        /* RailCore "SHTABDI" spelling deta hai, Wikipedia mein "Shatabdi" —
         * normalize karke hi query banao warna wiki search 0 deta hai. */
        if (nm) {
          subject = titleCaseWords(nm.replace(/\bSHTABDI\b/gi, "SHATABDI"));
          factTrainName = subject;
        }
      } catch {
        /* naam nahi mila — number hi subject */
      }
      if (!subject) subject = factNum;
      else subject = `${subject} ${factNum}`;
    } else {
      const typeM = rawText.match(/\b(vande bharat|shatabdi|rajdhani|gatimaan|gatiman|duronto|tejas|garib rath|hum safar|jan shatabdi|double decker|mahamana|antyodaya|bande bharat|namma metro|namo bharat)\b/i);
      if (typeM) {
        subject = titleCaseWords(typeM[1]);
        factTrainName = subject;
      }
    }
    /* ChatGPT-jaisa SOURCE-SCRAPE (user 2026-09-06): train ka POORA Wikipedia
     * page (speed/rake/history/slip-coach details) dhoondh kar question ke
     * hisaab ka paragraph — generic snippet se pehle ye, kaafi zyada detail. */
    if (factTrainName) {
      const pageAnswer = await answerFromTrainPage(factTrainName, factNum, rawText);
      if (pageAnswer) {
        reply = pageAnswer;
        toolOk = true;
      }
    }
    if (!reply) {
    /* "tatkal quota kaise kaam karta hai" jaise case: factKeyword generic
     * "information" banta hai + subject khali → query "information" bekar.
     * Aise mein filler-stripped core text hi query banao. */
    const CORE_FILLER_RE =
      /\b(ka|ki|ke|ko|kya|hai|hain|hun|tha|thi|the|se|mein|me|mai|main|par|pe|to|hi|bhi|batao|batana|btana|btaye|bataiye|bata|dikhao|dikha|chahiye|karo|karna|kar|mujhe|mera|meri|aap|kripya|please|kr|kro|nahi|na|haan|yan|ya|jaise|bta|btao)\b/gi;
    const coreText = rawText.replace(CORE_FILLER_RE, " ").replace(/\s+/g, " ").trim();
    const queryTail = factKeyword !== "information" || subject ? factKeyword : coreText;
    const factQuery = `${subject ? subject + " " : ""}${queryTail}`.trim().slice(0, 140);
    let webResults = await webSearch(factQuery, 3);
    /* Naam+number wali query fail ho to bina-number retry (naam hi kaafi) —
     * e.g. "Amritsar Shatabdi 12014 top speed" 0 par "Amritsar Shatabdi top
     * speed" mil sakta hai. */
    if (!webResults.length && subject.includes(" ")) {
      const q2 = subject.replace(/ \d{5}$/, "") + " " + factKeyword;
      webResults = await webSearch(q2, 3);
    }
    /* Disambiguation ("Top speed may refer to:") jawab nahi hota — skip.
     * Screenshot fix (2026-09-06 #3): "12054 ki top speed" par pehla web
     * result "production car speed records" (Wikipedia) tha — bilkul
     * irrelevant. Ab railway-relevance filter: snippet/title mein railway
     * context hona chahiye, car/automotive jaise non-railway results reject. */
    const RAILWAY_FACT_RE =
      /train|rail|railway|railroad|express|locomotive|shatabdi|rajdhani|vande bharat|duronto|gatimaan|gatiman|tejas|km\/h|kmph|kph|irctc|coach/i;
    const NOT_RAILWAY_FACT_RE =
      /\b(production cars?|street-legal|automobiles?|cars?|motorcycles?|aircraft|bicycles?|speedboats?|birds?)\b/i;
    const good = webResults.filter((x) => {
      const hay = `${x.title} ${x.snippet}`;
      if (/may refer to:/i.test(x.snippet)) return false;
      if (NOT_RAILWAY_FACT_RE.test(hay)) return false;
      return RAILWAY_FACT_RE.test(hay);
    });
    if (good.length) {
      const best = good[0];
      reply = `Web se mila: ${best.snippet}\n(Source: ${best.title} — ${best.url})\n(Ye railway API ka live data nahi, web-search ka jawab hai.)`;
      toolOk = true;
    } else {
      /* Round-4 (ChatGPT-jaisa): fact-web fail hone par general sawaal
       * ("mumbai local ki pehli service kab shuru hui") ko topic-page
       * (Wikipedia full page) + LLM layers se jawab milne ka mauka do. */
      if (!factNum) {
        const topicAnswer = await answerFromTopicPage(String(req.text ?? ""));
        if (topicAnswer) {
          reply = topicAnswer;
          toolOk = true;
        } else {
          const LLM_EXCLUDE_RE =
            /\b(live|abhi kahan|abhi kaha|running status|pnr\s*status|pnr check|seat avail|availability|avl|kiraya|current fare|aaj ka fare|aaj ka rate)\b|\d{5,}/i;
          if (!LLM_EXCLUDE_RE.test(String(req.text ?? ""))) {
            const aiAnswer = await generalRailwayAnswer(String(req.text ?? ""));
            if (aiAnswer) {
              reply = `${aiAnswer}\n(AI ka general jawab — live data nahi; important details IRCTC/official source se verify karein.)`;
              toolOk = true;
            }
          }
        }
      }
      if (!reply) {
        /* Web timeout / 0 results / sab irrelevant (car records jaise) —
         * EMPTY reply kabhi nahi (screenshot #3: timeout par khali jawab
         * gaya tha). Honest denial — guess nahi. */
        reply = `${factNum ? `Train ${factNum} ki` : "Is"} ${factKeyword === "information" ? "detail" : factKeyword} ka reliable jawab web se abhi nahi mil paya — main railway ke verified data ke bina guess nahi karunga.`;
        toolOk = false;
      }
    }
    } /* end if (!reply) — train-page se jawab aa gaya tha to webSearch skip */
  }

  /* Concept-question par tool ka "Train number chahiye" fail-reply hatao —
   * universal KB/web/LLM fallback ko jawab dene do (round-4: "vivek express
   * kitna lamba route cover karta hai" → TRAIN_INFO tool fail ho jaata tha). */
  if (
    reply &&
    /^train number chahiye/i.test(String(reply).trim()) &&
    GENERAL_QUESTION_RE.test(String(req.text ?? "")) &&
    !hasJourneyContext
  ) {
    reply = null;
    tool = null;
    toolOk = null;
    detTrains = null;
  }

  /* ── UNIVERSAL WEB FALLBACK (user request 2026-09-06: "ChatGPT jaisa —
   * koi bhi railway sawaal, API se jawab na mile to khud web se dhoondh ke
   * laana"). General-fact keywords se aage: jab tak reply nahi bani, koi
   * tool nahi chala, aur railway-domain ka QUESTION hai — web search se
   * jawab try karo (labeled, 1 call). Booking-critical (live/fare/seats/
   * PNR) par kabhi nahi — wahan verified API/scrape hi (rule 15). */
  if (!reply && !tool && !factWebTried) {
    const rawText = String(req.text ?? "").trim();
    const RAILWAY_Q_RE =
      /\b(train|trains|rail|railway|railways|railroad|irctc|station|stations|coach|coaches|pnr|tatkal|berth|berths|seat|seats|fare|quota|platform|locomotive|engine|express|shatabdi|rajdhani|vande bharat|bande bharat|duronto|garib rath|tejas|gatimaan|gatiman|metro|local|suburban|line|lines|route|routes|network|zone|zones|gauge|waiting list|rac|gnwl|pqwl|rlwl|tqwl|wl|arp|chart|catering|pantry|blanket|bedroll|reservation|sleeper|class|classes|1a|2a|3a|cc|ec|2s|vistadome|lhb|icf|tte|concession|refund|cancellation|helpline|madad|ecatering|vivek|gatimaan)\b/i;
    const QUESTION_RE =
      /\b(kya|kaise|kaisa|kab|kahan|kahaan|kitna|kitni|kitne|kaun|kaunsi|kyun|kyu|kyon|why|how|what|when|where|which|does|can|batao|batana|btana|btaye|bataiye|bata|bataen|dikhao|dikha|suchi|list|sab|sare|kaun se|milta|milti|milte|hoti|hota|hote|matlab|meaning|sabse|pehli|pehla|pehle|shuruaat|shuru|history|samjhao|samjha|explain|kaunsi)\b/i;
    if (RAILWAY_Q_RE.test(rawText) && QUESTION_RE.test(rawText) && !/\b(live status|running status|abhi kahan|kaha hai|kahan hai)\b/i.test(rawText)) {
      /* ── LOCAL RAILWAY KNOWLEDGE BASE (user 2026-09-06: "AI ke paas har
       * cheez ka answer ho"). Sleeper/tatkal/RAC/classes jaise general
       * sawaal web se PEHLE stable local KB se — turant, offline, reliable. */
      const kbAnswer = railKbAnswer(rawText);
      if (kbAnswer) {
        reply = kbAnswer;
        toolOk = true;
      }
      if (!reply) {
      /* Query banao: filler hatao, train ka naam/number prepend (trainInfo
       * se — ChatGPT jaisa "samajh ke" search karne ke liye subject chahiye). */
      const FILLER_RE =
        /\b(ka|ki|ke|ko|kya|kya|hai|hain|hun|tha|thi|the|se|mein|me|mai|main|par|pe|to|hi|bhi|batao|batana|btana|btaye|bataiye|bata|bataen|dikhao|dikha|chahiye|karo|karna|karke|kar|mujhe|mera|meri|mere|aap|tum|tumhara|kripya|please|kr|kro|nahi|na|haan|yan|ya|jaise|waise|bta|btao|lga|lagta|kabhi|hota|hoti|hote|milta|milti|milte|karta|karti|karte|matlab|meaning|walI|wala|wale)\b/gi;
      let q = rawText.replace(FILLER_RE, " ").replace(/\s+/g, " ").trim().slice(0, 100);
      const num = rawText.match(/\b\d{5}\b/)?.[1] ?? ctx.selectedTrainNumber ?? null;
      let subject = "";
      if (num) {
        try {
          const info = await routedTrainInfo(num);
          const nm = info.info?.trainName ?? "";
          if (nm) subject = titleCaseWords(nm.replace(/\bSHTABDI\b/gi, "SHATABDI"));
        } catch {
          /* naam nahi mila */
        }
        subject = subject ? `${subject} ${num}` : num;
      }
      const finalQuery = `${subject ? subject + " " : ""}${q}`.trim().slice(0, 140);
      if (finalQuery.length >= 3) {
        /* ChatGPT-jaisa train-page scrape pehle (num + naam dono hone par) —
         * "12054 mein catering hoti hai kya" jaise sawaal train ke Wikipedia
         * page ke relevant paragraph se aate hain. */
        if (num && subject && subject !== num) {
          const pageAnswer = await answerFromTrainPage(subject.replace(/ \d{5}$/, ""), num, rawText);
          if (pageAnswer) {
            reply = pageAnswer;
            toolOk = true;
          }
        }
        /* ROUND-5 ("jaise ChatGPT kahin se bhi scrap karke laata hai"):
         * general web search (DDG-lite/Bing) → top pages SCRAPE →
         * question-keyword scored paragraph. HOW-TO / RULE sawaal
         * ("luggage limit", "irctc account kaise banaye") par scrape
         * PEHLE — aise jawab blogs/official sites par hote hain, Wikipedia
         * par nahi. Knowledge sawaal par wiki pehle. */
        const RULE_HOWTO_Q =
          /kitna|kitni|kitne|limit|charge|charges|rule|rules|slab|kaise|how to|kya karna|process|banaye|banane|steps|allowed|permission|kab tak|deadline/i.test(rawText);
        const tryScrape = async (): Promise<void> => {
          if (reply) return;
          const scrapeAnswer = await answerFromWebScrape(rawText);
          if (scrapeAnswer) {
            reply = scrapeAnswer;
            toolOk = true;
          }
        };
        const tryTopic = async (): Promise<void> => {
          if (reply) return;
          const topicAnswer = await answerFromTopicPage(rawText);
          if (topicAnswer) {
            reply = topicAnswer;
            toolOk = true;
          }
        };
        if (RULE_HOWTO_Q) {
          await tryScrape();
          await tryTopic();
        } else {
          await tryTopic();
          await tryScrape();
        }
        /* Superlative sawaal ("sabse tez train") par wiki-page se jawab nahi
         * mila → snippet bhi unreliable (meta/intro text) — seedha LLM layer
         * (fastest/largest jaise common superlatives LLM sahi jaanta hai,
         * labeled). */
        const superlativeQ =
          /sabse\s+(tez|tezi|jaldi|lambi|lamba|badi|bada|purani|purana|nayi|naya|sasti|sasta|acchi|accha|famous|mashhoor)|fastest|longest|largest|oldest/i.test(rawText);
        const webResults = reply || superlativeQ ? [] : await webSearch(finalQuery, 3);
        const RAILWAY_FACT_RE2 =
          /train|rail|railway|railroad|express|locomotive|shatabdi|rajdhani|vande bharat|duronto|gatimaan|gatiman|tejas|km\/h|kmph|kph|irctc|coach|station|ticket|berth|tatkal|quota|pantry|catering/i;
        const NOT_RAILWAY_FACT_RE2 =
          /\b(production cars?|street-legal|automobiles?|motorcycles?|aircraft|bicycles?|speedboats?|birds?)\b/i;
        const good = webResults.filter((x) => {
          const hay = `${x.title} ${x.snippet}`;
          if (/may refer to:/i.test(x.snippet)) return false;
          if (NOT_RAILWAY_FACT_RE2.test(hay)) return false;
          if (!RAILWAY_FACT_RE2.test(hay)) return false;
          /* Relevance: sawaal ke significant words snippet mein hone chahiye
           * (Sikhism-Iraq wala irrelevant-snippet bug). */
          return wikiRelevant(rawText, hay);
        });
        if (good.length) {
          const best = good[0];
          reply = `Web se mila: ${best.snippet}\n(Source: ${best.title} — ${best.url})\n(Ye railway API ka data nahi, web-search ka jawab hai.)`;
          toolOk = true;
        } else if (!reply) {
          /* CHATGPT-JAISA FINAL LAYER (round-4: "AI ke paas har cheez ka
           * answer ho"): KB + train-page + topic-page + web sab fail —
           * phir LLM general railway knowledge se jawab, clearly labeled.
           * Live/booking-critical par KABHI nahi (rule 15) — wahan sirf API. */
          const LLM_EXCLUDE_RE =
            /\b(live|abhi kahan|abhi kaha|running status|pnr\s*status|pnr check|seat avail|availability|avl|kiraya|current fare|aaj ka fare|aaj ka rate)\b|\d{5,}/i;
          if (!LLM_EXCLUDE_RE.test(rawText)) {
            const aiAnswer = await generalRailwayAnswer(rawText);
            if (aiAnswer) {
              reply = `${aiAnswer}\n(AI ka general jawab — live data nahi; important details IRCTC/official source se verify karein.)`;
              toolOk = true;
            }
          }
          if (!reply) {
            /* LLM bhi nahi — honest denial (screenshot #4). */
            reply = `Ye main abhi confirm nahi kar paya — guess nahi karunga. Live train data (status/fare/seats) API se nikaal leta hoon; ya sawaal thode alag shabdon se poochein.`;
            toolOk = false;
          }
        }
      } /* end if (!reply) — KB se jawab aaya to web skip */
      }
    }
  }

  /* ── FINAL SAFETY NET (screenshot 2026-09-06 #4: "gnwl kya hota hai"
   * jaise sawaal par EMPTY reply -> client 'Kahan se kahan jaana hai?'
   * dikha deta tha). Railway-domain ka koi bhi sawaal kabhi EMPTY reply
   * ke saath nahi jata — honest general jawab. */
  /* Railway-keyword ho toh OUT_OF_DOMAIN classification bhi override —
   * NLU galat off-domain bol sakta hai ("engine wap7 ka matlab"), par sawaal
   * railway ka hai toh EMPTY kabhi nahi (#7). */
  const railwayishText = /\b(train|trains|rail|railway|railways|irctc|station|coach|coaches|pnr|tatkal|berth|seat|seats|fare|quota|platform|engine|locomotive|express|shatabdi|rajdhani|vande bharat|bande bharat|duronto|garib rath|tejas|gatimaan|gatiman|sleeper|class|classes|wl|rac|gnwl|pqwl|rlwl|tqwl|arp|chart|catering|pantry|blanket|bedroll|reservation|concession|refund|cancellation|helpline|madad|ecatering|tte|gauge|lhb|icf|vistadome|1a|2a|3a|cc|ec|2s)\b/i.test(String(req.text ?? ""));
  if (
    !reply &&
    (understood.nlu.intent !== "OUT_OF_DOMAIN" || railwayishText) &&
    String(req.text ?? "").trim().length > 1
  ) {
    /* Pehle LLM se general jawab try (round-4 ChatGPT-jaisa) — live-critical
     * par nahi. Fail tabhi honest "samajh nahi paya". */
    const SN_LLM_EXCLUDE_RE =
      /\b(live|abhi kahan|abhi kaha|running status|pnr\s*status|pnr check|seat avail|availability|avl|kiraya|current fare|book|booking|ticket kharid|reserve)\b|\d{5,}/i;
    let snAnswer: string | null = null;
    if (railwayishText && !SN_LLM_EXCLUDE_RE.test(String(req.text ?? ""))) {
      snAnswer = await generalRailwayAnswer(String(req.text ?? ""));
    }
    if (snAnswer) {
      reply = `${snAnswer}\n(AI ka general jawab — live data nahi; important details IRCTC/official source se verify karein.)`;
      toolOk = true;
    } else {
      reply =
        "Ye sawaal main theek se samajh nahi paya. Railway ke live data (train status, fare, seat availability, PNR) par turant poochho — wahi API se nikaalta hoon. Ya apna sawaal thoda saaf shabdon mein poochein.";
      toolOk = false;
    }
  }

  // lines KABHI nahi bhejna — resume mechanism band.
  void neverAutoBook(understood.nlu.intent, req.bookingFlow);

  /* 2026-09-20 (user: "seats show karne ke baad book karne ka option poochhna chahiye tha"):
   * model seat data deta hai par offer line bhool jaata hai — isliye FINAL reply par
   * deterministic guard (har path: agentic + deterministic). Sirf sawaal add hota hai;
   * booking/payment/click ka koi rasta yahan se nahi khulta (confirmBook: false niche). */
  reply = ensureBookingOffer(reply, req.text);

  return {
    nlu: understood.nlu,
    source: understood.source,
    context: ctx,
    tool,
    toolOk,
    reply,
    interrupt: false,
    resumeAsk: null,
    resumeText: null,
    trains: detTrains,
    journey: detJourney,
    choice: detChoice,
    confirmBook: false,
    missingFields: understood.missingFields,
    modelUsed: understood.modelUsed,
    latencyMs: understood.latencyMs,
    failureReason: understood.failureReason,
    engine: "deterministic",
    toolTrace: atlasTrace ? [atlasTrace] : undefined,
    agenticFailureReason,
    grounded: atlasGrounded,
  };
}
