/* ── VERIFIED-SITE WEB SCRAPING fallback (user request 2026-09-06):
 * "agar data API se na mile to verified sites (indian railway, ixigo,
 * make my trip, cris, etc — koi bhi verified site) se web scraping se
 * data le aaye."
 *
 * LAST-RESORT: RailCore (primary) + RailKit (fallback) dono fail hone par
 * hi chalta hai — routedSchedule() ke ant mein. Data HAMESHA source-labeled
 * jaata hai (provider: "web_ixigo" / "web_confirmtkt") taaki reply mein
 * saaf dikhe ki ye railway API nahi, verified public site se aaya hai.
 *
 * Sources (dono SSR — plain HTML mein poora timetable milta hai):
 *   1. ixigo.com/trains/<num>      (Stn Code|Stn Name|Arrives|Departs|…)
 *   2. confirmtkt.com/train-schedule/<num> (Station Name - Code|Arrives|Departs)
 *   3. trainspnrstatus.com/train-schedule/<num> ([#, NAME, CODE, arr, dep])
 *
 * COACH POSITION (2026-09-06, user: "har cheez API fail par web se"):
 *   - trainspnrstatus.com/train-coach-position/<num> (SSR coach boxes)
 *
 * LIVE STATUS (2026-09-06, user ne booking-critical scraping bhi authorize ki):
 *   - railyatri.in/live-train-status/<num>-<name> (SSR __NEXT_DATA__.ltsData —
 *     NTES-based: current station, delay, ETA, upcoming stations)
 *   NOTE: fare/seat-availability ke liye abhi koi publicly accessible SSR
 *   source nahi mila (ConfirmTkt 404-shell, ixigo/trainspnrstatus 403,
 *   RailYatri availability client-side API auth-dependent) — wo sirf API se.
 *
 * Bot-block/parse-change par null/[] — honest empty, koi crash nahi. */

export type ScrapedStop = {
  code: string;
  name: string;
  arrival: string | null;
  departure: string | null;
};

export type ScrapedSchedule = {
  trainNumber: string;
  trainName: string | null;
  stops: ScrapedStop[];
  provider: "web_ixigo" | "web_confirmtkt" | "web_trainspnrstatus";
  sourceUrl: string;
};

const UA =
  "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";
const SCRAPE_TIMEOUT_MS = 9000;

/* Tests inject karte hain (setWebFetch pattern). */
let scrapeFetchImpl: typeof fetch | null = null;
export function setScrapeFetch(fn: typeof fetch | null): void {
  scrapeFetchImpl = fn ?? globalThis.fetch.bind(globalThis);
}

async function fetchHtml(url: string): Promise<string | null> {
  try {
    const host = (() => {
      try {
        return new URL(String(url)).hostname;
      } catch {
        return "";
      }
    })();
    /* Full browser fingerprint — kuch CDNs (trainspnrstatus) incomplete
     * headers par 403 dete hain. Referer host ka khud ka page hai. */
    const res = await (scrapeFetchImpl ?? globalThis.fetch.bind(globalThis))(url, {
      headers: {
        "User-Agent": UA,
        Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
        "Accept-Language": "en-IN,en;q=0.9,hi;q=0.8",
        "Sec-Fetch-Dest": "document",
        "Sec-Fetch-Mode": "navigate",
        "Sec-Fetch-Site": "same-origin",
        "Sec-Fetch-User": "?1",
        "Upgrade-Insecure-Requests": "1",
        Referer: "https://" + host + "/",
      },
      signal: AbortSignal.timeout(SCRAPE_TIMEOUT_MS),
    });
    if (!res.ok) return null;
    return await res.text();
  } catch {
    return null;
  }
}

const TIME_RE = /(\d{1,2}:\d{2})/;

/** H1/title se train ka naam (jaise "12014 Amritsar Shtabdi: Train Route" → "Amritsar Shtabdi"). */
function trainNameFromHtml(html: string): string | null {
  const h1 = html.match(/<h1[^>]*>([\s\S]*?)<\/h1>/i)?.[1];
  const raw = (h1 && h1.trim()) || pageTitle(html) || "";
  const m = String(raw)
    .replace(/<[^>]+>/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/\d{4,6}\s*/g, " ")
    .replace(/[:|·-].*/g, " ")
    .replace(/\b(train|route|schedule|timetable|time table)\b/gi, " ")
    .replace(/\s+/g, " ")
    .trim();
  if (m.length < 4) return null;
  return m.slice(0, 60);
}

function pageTitle(html: string): string | null {
  const og = html.match(/<meta[^>]+property=["']og:title["'][^>]+content=["']([^"']{3,100})["']/i)?.[1];
  if (og) return og.replace(/\s*\(\d{4,6}\).*/i, "").replace(/\s*[-|·].*(train|schedule|timetable|route).*/i, "").trim() || null;
  const t = html.match(/<title[^>]*>([^<]{3,100})<\/title>/i)?.[1];
  if (!t) return null;
  return t.replace(/\s*\(\d{4,6}\).*/i, "").replace(/\s*[-|·].*(train|schedule|timetable|route).*/i, "").replace(/\s*(train )?(schedule|timetable|time table|route).*/i, "").trim() || null;
}

/* ── ixigo parser: <table> rows — ||ASR|||Amritsar Jn|||starts||04:55||…
 *    Ya arrival "starts", departure "04:55".                               */
function parseIxigo(html: string, trainNumber: string): ScrapedSchedule | null {
  const tables = html.match(/<table[^>]*>[\s\S]*?<\/table>/g) ?? [];
  for (const table of tables) {
    const rows = table.match(/<tr[\s\S]*?<\/tr>/g) ?? [];
    const stops: ScrapedStop[] = [];
    for (const row of rows) {
      const cells = (row.match(/<t[dh][^>]*>([\s\S]*?)<\/t[dh]>/g) ?? []).map((c) =>
        c.replace(/<[^>]+>/g, " ").replace(/&nbsp;/g, " ").replace(/\s+/g, " ").trim(),
      );
      if (cells.length < 4) continue;
      /* Offset-safe: cells mein pehla solid A-Z 2-5 code dhoondo (ixigo
       * rows mein leading empty/index cells aate hain). */
      let ci = -1;
      for (let i = 0; i < Math.min(cells.length - 2, 6); i++) {
        if (/^[A-Z]{2,5}$/.test(cells[i].toUpperCase()) && /[a-z]/.test(cells[i + 1] ?? "")) {
          ci = i;
          break;
        }
      }
      if (ci < 0) continue;
      const code = cells[ci].toUpperCase();
      const name = cells[ci + 1] ?? "";
      const arrives = cells[ci + 2] ?? "";
      const departs = cells[ci + 3] ?? "";
      const arrival = /start/i.test(arrives) ? null : (arrives.match(TIME_RE)?.[1] ?? null);
      const departure = departs.match(TIME_RE)?.[1] ?? null;
      stops.push({ code, name, arrival, departure });
    }
    if (stops.length >= 3) {
      return {
        trainNumber,
        trainName: trainNameFromHtml(html),
        stops,
        provider: "web_ixigo",
        sourceUrl: `https://www.ixigo.com/trains/${trainNumber}`,
      };
    }
  }
  return null;
}

/* ── ConfirmTkt parser: ||2|||Beas - BEAS|||05:23|||05:25||…
 *    Station "Name - CODE" ek hi cell mein hota hai.                      */
function parseConfirmTkt(html: string, trainNumber: string): ScrapedSchedule | null {
  const tables = html.match(/<table[^>]*>[\s\S]*?<\/table>/g) ?? [];
  for (const table of tables) {
    const rows = table.match(/<tr[\s\S]*?<\/tr>/g) ?? [];
    const stops: ScrapedStop[] = [];
    for (const row of rows) {
      const cells = (row.match(/<t[dh][^>]*>([\s\S]*?)<\/t[dh]>/g) ?? []).map((c) =>
        c.replace(/<[^>]+>/g, " ").replace(/&nbsp;/g, " ").replace(/\s+/g, " ").trim(),
      );
      if (cells.length < 4) continue;
      if (cells[0] && !/^\d+$/.test(cells[0])) continue;
      const stn = cells[1] ?? "";
      const m = stn.match(/^(.*?)\s*-\s*([A-Za-z]{2,5})$/);
      if (!m) continue;
      const name = m[1].trim();
      const code = m[2].toUpperCase();
      if (!name) continue;
      const arrives = cells[2] ?? "";
      const departs = cells[3] ?? "";
      const arrival = /start/i.test(arrives) ? null : (arrives.match(TIME_RE)?.[1] ?? null);
      const departure = departs.match(TIME_RE)?.[1] ?? null;
      stops.push({ code, name, arrival, departure });
    }
    if (stops.length >= 3) {
      return {
        trainNumber,
        trainName: trainNameFromHtml(html),
        stops,
        provider: "web_confirmtkt",
        sourceUrl: `https://www.confirmtkt.com/train-schedule/${trainNumber}`,
      };
    }
  }
  return null;
}

/* ── trainspnrstatus parser: ||1||AMRITSAR||ASR|||--:--|||04:55||…
 *    Name PEHLE (uppercase), code BAAD mein — ConfirmTkt ka ulta.          */
function parseTrainSpnr(html: string, trainNumber: string): ScrapedSchedule | null {
  const tables = html.match(/<table[^>]*>[\s\S]*?<\/table>/g) ?? [];
  for (const table of tables) {
    const rows = table.match(/<tr[\s\S]*?<\/tr>/g) ?? [];
    const stops: ScrapedStop[] = [];
    for (const row of rows) {
      const cells = (row.match(/<t[dh][^>]*>([\s\S]*?)<\/t[dh]>/g) ?? []).map((c) =>
        c.replace(/<[^>]+>/g, " ").replace(/&nbsp;/g, " ").replace(/\s+/g, " ").trim(),
      );
      if (cells.length < 5) continue;
      /* Pattern: [#, NAME, CODE, arrives, departs, halt, ...] */
      let idx = -1;
      for (let i = 0; i < Math.min(cells.length - 3, 4); i++) {
        if (/^\d+$/.test(cells[i]) && /^[A-Za-z .]{3,40}$/.test(cells[i + 1] ?? "") && /^[A-Z]{2,5}$/.test((cells[i + 2] ?? "").toUpperCase())) {
          idx = i;
          break;
        }
      }
      if (idx < 0) continue;
      const name = cells[idx + 1];
      const code = cells[idx + 2].toUpperCase();
      const arrives = cells[idx + 3] ?? "";
      const departs = cells[idx + 4] ?? "";
      const arrival = /--:--|start/i.test(arrives) ? null : (arrives.match(TIME_RE)?.[1] ?? null);
      const departure = /--:--|end/i.test(departs) ? null : (departs.match(TIME_RE)?.[1] ?? null);
      stops.push({ code, name, arrival, departure });
    }
    if (stops.length >= 3) {
      return {
        trainNumber,
        trainName: trainNameFromHtml(html),
        stops,
        provider: "web_trainspnrstatus",
        sourceUrl: `https://www.trainspnrstatus.com/train-schedule/${trainNumber}`,
      };
    }
  }
  return null;
}

/** Verified-site scrape (last-resort): ixigo → ConfirmTkt → trainspnrstatus.
 *  Sab fail → null (honest empty — koi invent nahi). */
export async function scrapeTrainScheduleWeb(trainNumber: string): Promise<ScrapedSchedule | null> {
  const num = String(trainNumber ?? "").trim();
  if (!/^\d{4,6}$/.test(num)) return null;
  const sources: { url: string; parse: (html: string, num: string) => ScrapedSchedule | null }[] = [
    { url: `https://www.ixigo.com/trains/${num}`, parse: parseIxigo },
    { url: `https://www.confirmtkt.com/train-schedule/${num}`, parse: parseConfirmTkt },
    { url: `https://www.trainspnrstatus.com/train-schedule/${num}`, parse: parseTrainSpnr },
  ];
  for (const src of sources) {
    const html = await fetchHtml(src.url);
    if (!html) continue;
    const parsed = src.parse(html, num);
    if (parsed) return parsed;
  }
  return null;
}


/* ── COACH POSITION web-scrape (user request 2026-09-06: "pehle API, fail
 * par verified site se") — trainspnrstatus.com SSR coach boxes:
 *   <button aria-label="Select coach C5">...<span class="text-lg">C5</span>
 *   <span ...>CC</span> ... Pos <!-- -->12</button>
 * Live-verified 2026-09-06: 12014 → 18 coaches LPR,E2,E1,C14…C1,LPR. */

export type ScrapedCoach = {
  name: string;
  classCode: string;
  positionFromEngine: number;
  sequence: number;
};

export type ScrapedCoachPosition = {
  trainNumber: string;
  trainName: string | null;
  coaches: ScrapedCoach[];
  provider: "web_trainspnrstatus";
  sourceUrl: string;
};

/** Site labels → standard class codes (UNRESERVED → UR). */
function normalizeCoachClass(label: string): string {
  const t = String(label ?? "").trim().toUpperCase();
  if (t === "UNRESERVED" || t === "GEN" || t === "GENERAL") return "UR";
  return t || "??";
}

function parseCoachSpnr(html: string, trainNumber: string): ScrapedCoachPosition | null {
  const coaches: ScrapedCoach[] = [];
  const re =
    /aria-label="Select coach ([A-Z0-9]+)"[\s\S]*?<span class="text-lg">[^<]*<\/span><span class="text-\[10px\][^"]*">([^<]*)<\/span>[\s\S]*?Pos <!-- -->(\d+)<\/div><\/button>/g;
  for (const m of html.matchAll(re)) {
    const pos = Number(m[3]);
    if (!Number.isFinite(pos) || pos < 1) continue;
    coaches.push({ name: m[1], classCode: normalizeCoachClass(m[2]), positionFromEngine: pos, sequence: pos });
  }
  if (!coaches.length) return null;
  coaches.sort((a, b) => a.sequence - b.sequence);
  return {
    trainNumber,
    trainName: trainNameFromHtml(html),
    coaches,
    provider: "web_trainspnrstatus",
    sourceUrl: `https://www.trainspnrstatus.com/train-coach-position/${trainNumber}`,
  };
}

export async function scrapeCoachPositionWeb(trainNumber: string): Promise<ScrapedCoachPosition | null> {
  const num = String(trainNumber ?? "").trim();
  if (!/^\d{4,6}$/.test(num)) return null;
  const html = await fetchHtml(`https://www.trainspnrstatus.com/train-coach-position/${num}`);
  if (!html) return null;
  return parseCoachSpnr(html, num);
}

/** Shared source-label — tools.ts / agentic.ts replies mein lagta hai. */
export function webSourceLabel(provider: string): string {
  const site =
    provider === "web_ixigo"
      ? "ixigo.com"
      : provider === "web_trainspnrstatus"
        ? "trainspnrstatus.com"
        : provider === "web_confirmtkt"
          ? "confirmtkt.com"
          : provider === "web_railyatri"
            ? "railyatri.in"
            : provider === "web_railenquiry"
              ? "railenquiry.in"
              : provider === "web_erail"
                ? "erail.in"
                : null;
  /* Round-16o: extra API providers — web-scrape nahi, doosri railway API. */
  if (provider === "railradar") return " (Source: RailRadar API — primary railway API down tha.)";
  if (provider === "indianrailapi") return " (Source: Indian Rail API — primary railway API down tha.)";
  return site ? ` (Source: ${site} — railway API se nahi, verified web site se.)` : "";
}

/* ── LIVE STATUS via RailYatri SSR (user-authorized booking-critical scrape,
 * 2026-09-06). Page /live-train-status/<num>-<name> poora __NEXT_DATA__
 * embed karta hai jisme pageProps.ltsData = NTES-based live position hai:
 * delay, current station, eta/etd, upcoming_stations, update_time. */

export type ScrapedLiveStatus = {
  trainNumber: string;
  trainName: string;
  status: string;
  delayMinutes: number | null;
  lastUpdatedAt: string | null;
  currentStation: string | null;
  nextStation: string | null;
  journeyDate: string | null;
  provider: "web_railyatri" | "web_railenquiry";
  sourceUrl: string;
};

type LtsData = {
  success?: boolean;
  train_number?: string;
  train_name?: string;
  delay?: number;
  update_time?: string;
  current_station_code?: string;
  current_station_name?: string;
  at_src?: boolean;
  at_dstn?: boolean;
  ahead_distance_text?: string;
  title?: string;
  new_message?: string;
  awaiting_update?: boolean;
  next_station_code?: string;
  next_station_name?: string;
  eta?: string;
  etd?: string;
  status?: string;
  train_start_date?: string;
  upcoming_stations?: { station_code?: string; station_name?: string; eta?: string }[];
};

function parseNextData(html: string): Record<string, unknown> | null {
  const m = html.match(/<script id="__NEXT_DATA__"[^>]*>([\s\S]*?)<\/script>/);
  if (!m) return null;
  try {
    const parsed = JSON.parse(m[1]) as unknown;
    if (parsed && typeof parsed === "object") return parsed as Record<string, unknown>;
  } catch {
    /* malformed JSON — parse fail, honest null */
  }
  return null;
}

export function parseRailYatriLive(html: string, trainNumber: string, sourceUrl: string): ScrapedLiveStatus | null {
  const root = parseNextData(html);
  if (!root) return null;
  const props = root.props as Record<string, unknown> | undefined;
  const pageProps = props?.pageProps as Record<string, unknown> | undefined;
  const lts = pageProps?.ltsData as LtsData | undefined;
  if (!lts || lts.success !== true) return null;
  const delay = typeof lts.delay === "number" ? lts.delay : null;
  const currentName = String(lts.current_station_name ?? "").replace(/~+$/, "").trim();
  const currentCode = String(lts.current_station_code ?? "").trim();
  const upcoming = Array.isArray(lts.upcoming_stations) ? lts.upcoming_stations : [];
  const next = upcoming[0];
  const nextLabel = next
    ? `${String(next.station_name ?? "").replace(/~+$/, "").trim() || next.station_code || ""}${next.eta ? ` (${next.eta})` : ""}`.trim()
    : null;
  /* "Train starts at 17:00" (12951 jab tak start na ho) jaise short-form
   * payloads: position fields nahi hote, title/new_message/next_station
   * hi asli live info hai — reject mat karo. */
  const title = String(lts.title ?? "").trim();
  const msg = String(lts.new_message ?? "").trim();
  const nextFallback = String(lts.next_station_name ?? lts.next_station_code ?? "").replace(/~+$/, "").trim();
  if (!currentName && !currentCode && delay === null && upcoming.length === 0 && !title && !nextFallback) return null;
  const status = lts.at_dstn
    ? "Journey completed"
    : title
      ? msg ? `${title} — ${msg}` : title
      : lts.status === "T" && currentName
        ? `Running — near ${currentName}${lts.ahead_distance_text ? `, ${lts.ahead_distance_text}` : ""}`
        : lts.status === "A" && currentName
          ? `At ${currentName}`
          : lts.status === "S" || (lts.at_src && !currentName)
            ? "At source"
            : String(lts.status ?? "").trim() || "Running";
  return {
    trainNumber: String(lts.train_number ?? trainNumber),
    trainName: String(lts.train_name ?? "").trim(),
    status,
    delayMinutes: delay,
    lastUpdatedAt: String(lts.update_time ?? "").trim() || null,
    currentStation: currentName || currentCode || null,
    nextStation: nextLabel || nextFallback || null,
    journeyDate: String(lts.train_start_date ?? "").trim() || null,
    provider: "web_railyatri",
    sourceUrl,
  };
}

/** URL pattern: /live-train-status/<num>-<name-slug> — naam approximate bhi
 * chalta hai (server number se match karta hai), par bilkul naam ke bina 404. */
/* Round-18m-30y (user: "14632 kal wali run raste mein hai, app 'abhi start nahi hui' bol raha; railyatri par sahi
 * dikh raha"): SSR page hamesha AAJ ki run deta hai. RailYatri ka apna LTS API run-day select karta hai —
 * /api/v3/train_eta_data/{train}/{daysBack}.json (0 = aaj, 1 = kal, …) — wahi jo site ka "Train start day"
 * dropdown call karta hai (verified 2026-09-14 01:25 IST: 14632 day=1 → KHAMANON, 7 min late; day=0 → not started). */
export function ryDaysBack(dateYmd: string | null | undefined): number | null {
  if (!dateYmd || !/^\d{4}-\d{2}-\d{2}$/.test(dateYmd)) return null;
  const nowIst = new Date(Date.now() + 5.5 * 60 * 60 * 1000);
  const todayIst = Date.UTC(nowIst.getUTCFullYear(), nowIst.getUTCMonth(), nowIst.getUTCDate());
  const [y, m, d] = dateYmd.split("-").map(Number);
  const back = Math.round((todayIst - Date.UTC(y, m - 1, d)) / 86400000);
  return back >= 0 && back <= 6 ? back : null;
}
export async function scrapeLiveStatusApi(trainNumber: string, daysBack: number): Promise<ScrapedLiveStatus | null> {
  const num = String(trainNumber ?? "").trim();
  if (!/^\d{4,6}$/.test(num)) return null;
  const url = `https://livestatus.railyatri.in/api/v3/train_eta_data/${num}/${daysBack}.json?start_day=${daysBack}&user_id=-2345434&device_type_id=4&change_name=seo_train_name&lat=&lng=&claim_on_train=false&authentication_token=`;
  try {
    const res = await (scrapeFetchImpl ?? globalThis.fetch.bind(globalThis))(url, {
      headers: { "User-Agent": UA, Accept: "application/json", Referer: "https://www.railyatri.in/" },
      signal: AbortSignal.timeout(SCRAPE_TIMEOUT_MS),
    });
    if (!res.ok) return null;
    const lts = (await res.json()) as LtsData;
    if (!lts || lts.success !== true) return null;
    /* Same shape as SSR ltsData → same parser (wrap as __NEXT_DATA__). */
    return parseRailYatriLive(`<script id="__NEXT_DATA__" type="application/json">${JSON.stringify({ props: { pageProps: { ltsData: lts } } })}</script>`, num, `https://www.railyatri.in/live-train-status/${num}-train?start_day=${daysBack}`);
  } catch {
    return null;
  }
}

export async function scrapeLiveStatusWeb(trainNumber: string, trainName?: string | null, dateYmd?: string | null): Promise<ScrapedLiveStatus | null> {
  const num = String(trainNumber ?? "").trim();
  if (!/^\d{4,6}$/.test(num)) return null;
  /* Date di gayi ho to us run-day ka LTS API pehle (SSR sirf aaj ki run deta hai). */
  const back = ryDaysBack(dateYmd);
  if (back != null) {
    const viaApi = await scrapeLiveStatusApi(num, back);
    if (viaApi) return viaApi;
    if (back > 0) return null; // purani run ka data SSR se nahi milega — galat (aaj wali) run mat lautao
  }
  /* Round-16b: RailYatri sirf number se route karta hai — slug koi bhi chale
   * (verified 2026-09-07: /12904-x → same __NEXT_DATA__). Naam optional. */
  const name = String(trainName ?? "").trim().replace(/[^\p{L}\p{N}\s-]/gu, "").replace(/\s+/g, "-") || "train";
  const sourceUrl = `https://www.railyatri.in/live-train-status/${num}-${name}`;
  const html = await fetchHtml(sourceUrl);
  if (!html) return null;
  return parseRailYatriLive(html, num, sourceUrl);
}


/* ── RAILENQUIRY.IN LIVE STATUS (round-6, NTES-question se nikla discovery):
 * enquiry.indianrail.gov.in (NTES) datacenter IPs par firewall-level drop
 * karta hai (TLS handshake hi nahi hota) — anti-bot evasion nahi karenge.
 * railenquiry.in usi enquiry-data ka SSR mirror hai: number-only URL
 * (/runningstatus/12958 — trainName hint ki zaroorat NAHI), plain HTML mein
 * "+7 Mins Late · RUNNING · KHALILPUR · Departed from X(CODE) at HH:MM". */

export function parseRailEnquiryLive(html: string, trainNumber: string, sourceUrl: string): ScrapedLiveStatus | null {
  const text = html
    .replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<[^>]+>/g, "\n");
  const lines = text
    .split("\n")
    .map((l) => l.replace(/&nbsp;/gi, " ").replace(/\s+/g, " ").trim())
    .filter(Boolean);
  if (!lines.length) return null;
  const hay = lines.join(" | ");

  /* Train naam: <title>12958 Swrn J Rajdhani Live Train Running Status</title> */
  const title = (/\<title\>\s*([\s\S]+?)\<\/title\>/i.exec(html)?.[1] ?? "").trim();
  const tm = new RegExp(`^\\s*${trainNumber}\\s+(.+?)\\s+Live Train Running Status\\s*$`, "i").exec(title);
  const trainName = tm ? tm[1].trim() : `Train ${trainNumber}`;

  const delayM = /([+-]?\d+)\s*Mins\s*Late/i.exec(hay);
  const onTime = /\bOn Time\b/i.test(hay);
  const delayMinutes = delayM ? Number(delayM[1].replace("+", "")) : onTime ? 0 : null;

  const runM = /RUNNING\s*·\s*([A-Za-z .'-]+)/i.exec(hay);
  const depM = /Departed from ([A-Za-z .'-]+?)\s*\(([A-Z]{2,10})\)\s*at\s*(\d{1,2}:\d{2})\s*([\d]{2}-\w{3})/i.exec(hay);
  const arrM = /Arrived at ([A-Za-z .'-]+?)\s*\(([A-Z]{2,10})\)/i.exec(hay);
  const currentStation = depM ? depM[1].trim() : arrM ? arrM[1].trim() : runM ? runM[1].trim() : null;

  let status: string | null = null;
  if (depM) status = `Departed from ${depM[1].trim()} (${depM[2]}) at ${depM[3]} ${depM[4]}`;
  else if (arrM) status = `Arrived at ${arrM[1].trim()} (${arrM[2]})`;
  else if (runM) status = `Running · ${runM[1].trim()}`;
  else if (onTime) status = "On time";
  if (!status && delayMinutes == null) return null;

  return {
    trainNumber,
    trainName,
    status: status ?? `${delayMinutes} mins late`,
    delayMinutes,
    lastUpdatedAt: depM ? `${depM[3]} ${depM[4]}` : null,
    currentStation,
    nextStation: null,
    journeyDate: null,
    provider: "web_railenquiry",
    sourceUrl,
  };
}

export async function scrapeLiveStatusRailEnquiry(trainNumber: string): Promise<ScrapedLiveStatus | null> {
  const num = String(trainNumber ?? "").trim();
  if (!/^\d{4,6}$/.test(num)) return null;
  const sourceUrl = `https://railenquiry.in/runningstatus/${num}`;
  const html = await fetchHtml(sourceUrl);
  if (!html) return null;
  return parseRailEnquiryLive(html, num, sourceUrl);
}

/* ------------------------------------------------------------------ */
/* Round-7 (2026-09-06): FARE web-fallback — erail.in/train-fare/{num} */
/* ------------------------------------------------------------------ */
/* erail ka fare page poora SSR deta hai — classes header + quota rows:
 *   ROW ['', 'CC', '2S', 'GN']            ← classes (last col kabhi quota-tag)
 *   ROW ['General', '650', '205', '140']
 *   ROW ['Tatkal', '825', '220', '-']
 * Sirf known IR classes hi columns maante hain ('GN' jaise tags skip).
 * Availability numbers erail/confirmTkt/sab mirrors client-side (auth API)
 * se laate hain — SSR availability source exist nahi karta (round-7 research). */

export type ScrapedFareClass = {
  code: string;
  general: number | null;
  tatkal: number | null;
};

export type ScrapedFare = {
  trainNumber: string;
  classes: ScrapedFareClass[];
  provider: "web_erail";
  sourceUrl: string;
  /** Round-18m-23: set hone par ye SEGMENT (from→to) ka fare hai; absent = poore route ka. */
  from?: string;
  to?: string;
};

const KNOWN_IR_CLASSES = new Set(["1A", "2A", "3A", "3E", "SL", "CC", "EC", "2S", "EA"]);

function parseFareCell(raw: string): number | null {
  const cleaned = raw.replace(/[₹,\s]/g, "");
  if (!cleaned || cleaned === "-") return null;
  const n = Number.parseInt(cleaned, 10);
  return Number.isFinite(n) && n > 0 ? n : null;
}

export function parseErailFare(html: string, trainNumber: string, sourceUrl: string): ScrapedFare | null {
  /* Round-7b: erail ka fare-table layout vary karta hai — Render body mein
   * fare-classes table "Total fare for" marker ke BAAD aati hai, sandbox body
   * mein PEHLE. Isliye marker sirf page-confirm ke liye, fare-table dhoondhne
   * ke liye saari tables scan — jo General/Tatkal + class-header de wahi. */
  if (!html.includes("Total fare for")) return null;
  const tables = [...html.matchAll(/<table[^>]*>([\s\S]*?)<\/table>/gi)].map((m) => m[1]);

  for (const tbl of tables) {
    const rows = [...tbl.matchAll(/<tr[^>]*>([\s\S]*?)<\/tr>/gi)]
      .map((rm) =>
        [...rm[1].matchAll(/<t[dh][^>]*>([\s\S]*?)<\/t[dh]>/gi)].map((cm) =>
          cm[1].replace(/<[^>]+>/g, " ").replace(/&nbsp;/g, " ").replace(/\s+/g, " ").trim(),
        ),
      )
      .filter((cells) => cells.length > 0);
    if (rows.length === 0) continue;

    /* Header row: pehla cell khali/label, baaki sab short uppercase tokens. */
    const header = rows.find((cells) => {
      if (cells.length < 2) return false;
      const rest = cells.slice(1);
      return rest.length >= 1 && rest.every((c) => /^[A-Z0-9]{1,3}$/.test(c));
    });
    if (!header) continue;

    const classCols: { index: number; code: string }[] = [];
    header.slice(1).forEach((code, i) => {
      if (KNOWN_IR_CLASSES.has(code)) classCols.push({ index: i + 1, code });
    });
    if (classCols.length === 0) continue;

    const quotaRow = (label: string): string[] | null =>
      rows.find((cells) => cells[0]?.toLowerCase() === label) ?? null;
    const general = quotaRow("general");
    const tatkal = quotaRow("tatkal");
    if (!general && !tatkal) continue;

    const classes: ScrapedFareClass[] = classCols.map(({ index, code }) => ({
      code,
      general: general ? parseFareCell(general[index] ?? "") : null,
      tatkal: tatkal ? parseFareCell(tatkal[index] ?? "") : null,
    }));
    /* Kisi bhi class mein fare na mile to ye table fare-table nahi. */
    if (classes.some((c) => c.general != null || c.tatkal != null)) {
      return { trainNumber, classes, provider: "web_erail", sourceUrl };
    }
  }
  return null;
}

/* Round-18m-23 (user LDH→BSB screenshot: "2A ₹3000, SL ₹815" = 13152 ka JAT→Kolkata POORA route fare,
 * segment ka nahi — effectively fake). erail `?from=X&to=Y` segment-specific fare deta hai (page title
 * "13152 ... Ludhiana Jn to Varanasi Jn Fare"; verified 2026-09-13: LDH→BSB 2A 1960 / SL 530 vs route
 * 3000 / 815). from/to diye ho to SIRF segment page, aur page ka selected from/to verify — mismatch
 * (erail ne station na pehchana → default route) par null, kabhi route-fare ko segment-fare mat batao. */
export async function scrapeTrainFareWeb(trainNumber: string, from?: string | null, to?: string | null): Promise<ScrapedFare | null> {
  const num = String(trainNumber ?? "").trim();
  if (!/^\d{4,6}$/.test(num)) return null;
  const f = String(from ?? "").trim().toUpperCase();
  const t = String(to ?? "").trim().toUpperCase();
  const segment = /^[A-Z]{2,5}$/.test(f) && /^[A-Z]{2,5}$/.test(t);
  const sourceUrl = segment ? `https://erail.in/train-fare/${num}?from=${f}&to=${t}` : `https://erail.in/train-fare/${num}`;
  const html = await fetchHtml(sourceUrl);
  if (!html) return null;
  if (segment && !erailPageIsForSegment(html, f, t)) return null;
  const parsed = parseErailFare(html, num, sourceUrl);
  return parsed ? { ...parsed, ...(segment ? { from: f, to: t } : {}) } : null;
}

/* ------------------------------------------------------------------ */
/* 23 Sep 2026 (user): 64551 LDH-CIA MEMU jaise UNRESERVED trains ka     */
/* reserved seat data kahin nahi hota (IRCTC reservation hi nahi hoti).  */
/* erail train-enquiry page ka title honest naam/type deta hai —          */
/* "64551 LDH-CIA MEMU Train Route". Isse row ko "check karo" par atkane  */
/* ke bajaye sach dikhate hain. 12h cache; generic title → null.          */
/* ------------------------------------------------------------------ */

export type ScrapedTrainType = {
  trainNumber: string;
  trainName: string;
  /** MEMU / DEMU / PASSENGER / LOCAL — reserved classes nahi hoti. */
  unreserved: boolean;
  kind: string | null;
  sourceUrl: string;
};

const UNRESERVED_RE = /\b(MEMU|DEMU|EMU|PASSENGER|PASS|LOCAL|SHUTTLE)\b/i;
const trainTypeCache = new Map<string, { at: number; val: ScrapedTrainType | null }>();
const TRAIN_TYPE_TTL_MS = 12 * 60 * 60 * 1000;

/** <title>64551 LDH-CIA MEMU Train Route</title> → name + unreserved flag. */
export function parseErailTrainEnquiryTitle(html: string, trainNumber: string): ScrapedTrainType | null {
  const m = html.match(/<title>\s*(?:\r?\n\s*)?(\d{4,6})\s+([^<]{2,90}?)\s*(?:Train Route)?\s*<\/title>/i);
  if (!m) return null;
  if (m[1] !== String(trainNumber).trim()) return null;
  const name = m[2].replace(/\s+/g, " ").trim();
  if (!name || /^(train enquiry|indian railways|erail)/i.test(name)) return null;
  const hit = name.match(UNRESERVED_RE);
  return {
    trainNumber: m[1],
    trainName: name,
    unreserved: Boolean(hit),
    kind: hit ? hit[1].toUpperCase() : null,
    sourceUrl: `https://erail.in/train-enquiry/${trainNumber}`,
  };
}

export async function scrapeTrainTypeWeb(trainNumber: string): Promise<ScrapedTrainType | null> {
  const num = String(trainNumber ?? "").trim();
  if (!/^\d{4,6}$/.test(num)) return null;
  const hit = trainTypeCache.get(num);
  if (hit && Date.now() - hit.at < TRAIN_TYPE_TTL_MS) return hit.val;
  try {
    const sourceUrl = `https://erail.in/train-enquiry/${num}`;
    const html = await fetchHtml(sourceUrl);
    const parsed = html ? parseErailTrainEnquiryTitle(html, num) : null;
    trainTypeCache.set(num, { at: Date.now(), val: parsed });
    return parsed;
  } catch {
    trainTypeCache.set(num, { at: Date.now(), val: null });
    return null;
  }
}

/** Tests ke liye cache clear. */
export function _clearTrainTypeCache(): void {
  trainTypeCache.clear();
}

/** erail fare page ke from/to selects mein wahi station selected hain jo maange the? */
export function erailPageIsForSegment(html: string, from: string, to: string): boolean {
  const sel = (name: string): string | null => {
    const m = html.match(new RegExp(`<select[^>]*name=['"]${name}['"][\\s\\S]*?</select>`, "i"));
    if (!m) return null;
    const o = m[0].match(/<option[^>]*value=['"]([A-Za-z]{2,5})['"][^>]*selected/i) ?? m[0].match(/<option[^>]*selected[^>]*value=['"]([A-Za-z]{2,5})['"]/i);
    return o ? o[1].toUpperCase() : null;
  };
  return sel("from") === from.toUpperCase() && sel("to") === to.toUpperCase();
}

/* ------------------------------------------------------------------ */
/* Round-7: STATION-LOOKUP web-fallback — railenquiry.in/station/{CODE} */
/* ------------------------------------------------------------------ */
/* Title format: "<title>{Name} ({CODE}) Railway Station</title>" (SSR). */

export type ScrapedStation = {
  code: string;
  name: string;
  city: string;
  provider: "web_railenquiry" | "web_erail";
  sourceUrl: string;
};

export function parseRailEnquiryStation(html: string, code: string, sourceUrl: string): ScrapedStation | null {
  const m = html.match(/<title>([^<]{2,80}?)\s*\(([A-Za-z]{2,5})\)\s*Railway\s+Station<\/title>/i);
  if (!m) return null;
  const name = m[1].replace(/&amp;/g, "&").replace(/\s+/g, " ").trim();
  if (!name || /^railway/i.test(name)) return null;
  if (m[2].toUpperCase() !== code.toUpperCase()) return null;
  return { code: code.toUpperCase(), name, city: name, provider: "web_railenquiry", sourceUrl };
}

export async function scrapeStationLookupWeb(code: string): Promise<ScrapedStation | null> {
  const c = String(code ?? "").trim();
  if (!/^[A-Za-z]{2,5}$/.test(c)) return null;
  const sourceUrl = `https://railenquiry.in/station/${c.toUpperCase()}`;
  const html = await fetchHtml(sourceUrl);
  if (html) {
    const parsed = parseRailEnquiryStation(html, c, sourceUrl);
    if (parsed) return parsed;
  }
  /* Round-16b: railenquiry.in Render (datacenter) IP se block hai — erail ki
   * full station list se exact code match (same list jo name-search use karti hai). */
  const list = await erailStationList();
  const hit = list.find((s) => s.code === c.toUpperCase());
  if (!hit) return null;
  return {
    code: hit.code,
    name: hit.name,
    city: hit.name.replace(/\s+(Jn|Junction|Cantt|City|Terminus|Central|Town|Road|Halt|H)$/i, "").trim() || hit.name,
    provider: "web_erail",
    sourceUrl: "https://erail.in/",
  };
}

/* ── SEAT AVAILABILITY via RailYatri SA JSON (Round-16, user request
 * 2026-09-07: "api fail ho jaaye to seat availability ... web se scrape").
 * railyatri.in ka seat-availability page client-side jo endpoint call
 * karta hai (sa.railyatri.in/api/v3/seat/availability/<train>/<date>/
 * <from>/<to>/<class>/<quota>.json) — keyless, IRCTC-sourced (cached,
 * `last_updated_at` ke saath). 6 din ki rows aati hain; hum maangi hui
 * date ki row lete hain. Status text "AVAILABLE-0288" / "RAC 12" /
 * "GNWL45/WL20" / "REGRET" / "NOT AVAILABLE" / "TRAIN DEPARTED". */

export type ScrapedSeatAvailability = {
  trainNumber: string;
  date: string; // YYYY-MM-DD
  classCode: string;
  quota: string;
  statusText: string; // raw IRCTC-style string
  status: "AVAILABLE" | "RAC" | "WAITLIST" | "NOT_AVAILABLE" | "UNKNOWN";
  seats: number | null;
  rac: number | null;
  waitlist: number | null;
  ticketFare: number | null;
  totalFare: number | null;
  /** Round-18m-27: Rajdhani/Shatabdi optional catering (total_fare - ticket_fare). */
  cateringCharge: number | null;
  lastUpdatedAt: string | null;
  cacheText: string | null;
  /** Round-18m: RailYatri ki cached entry SA_MAX_AGE se purani thi — status
   * sirf "last known" hai (UI mein ⚠ stale label), fresh nahi maani jaati. */
  stale?: boolean;
  /** Round-18m-17: RailYatri ne IRCTC se abhi live pull kiya (data_from:"IRCTC") — cache nahi. */
  live?: boolean;
  provider: "web_railyatri";
  sourceUrl: string;
};

export function parseIrctcAvailabilityText(raw: string): Pick<ScrapedSeatAvailability, "status" | "seats" | "rac" | "waitlist"> {
  const t = String(raw ?? "").trim().toUpperCase();
  const num = (re: RegExp) => {
    const m = t.match(re);
    return m ? Number(m[1]) : null;
  };
  if (/^(AVAILABLE|AVL|CURR_AVBL)/.test(t)) return { status: "AVAILABLE", seats: num(/(\d+)/), rac: null, waitlist: null };
  /* Round-18m-17 (user ConfirmTkt case 12920 JAT→DADN 1A): IRCTC live text
   * "GNWL/AVAILABLE" = quota-type GNWL, CURRENT status AVAILABLE (WL number
   * nahi hai) — ye seat hai, waitlist nahi. Isi tarah "GNWL/RAC 3" = RAC. */
  const slash = t.match(/^(?:GNWL|RLWL|PQWL|TQWL|RSWL|RQWL|CKWL)\s*\/\s*(AVAILABLE|AVL|CURR_AVBL)\s*-?\s*(\d+)?/);
  if (slash) return { status: "AVAILABLE", seats: slash[2] ? Number(slash[2]) : null, rac: null, waitlist: null };
  /* Round-18m-27 (user: railyatri site RAC 8, app RAC 63): IRCTC "RAC  63/RAC   8" = booking-time position 63,
   * CURRENT status RAC 8; "GNWL2/RAC26" = quota GNWL, current RAC 26. "/" ke BAAD wala current hai — wahi lo. */
  const slashRac = t.match(/^(?:GNWL|RLWL|PQWL|TQWL|RSWL|RQWL|CKWL|RAC)\s*-?\s*\d*\s*\/\s*RAC\s*-?\s*(\d+)?/);
  if (slashRac) return { status: "RAC", seats: null, rac: slashRac[1] ? Number(slashRac[1]) : null, waitlist: null };
  if (/^RAC/.test(t)) return { status: "RAC", seats: null, rac: num(/RAC\s*-?\s*(\d+)/), waitlist: null };
  if (/WL\s*-?\s*\d+/.test(t) || /^(GNWL|RLWL|PQWL|TQWL|RSWL|RQWL|CKWL)/.test(t)) {
    /* "GNWL45/WL20" — current WL (second number) hi user ke liye matter karta hai. */
    const all = [...t.matchAll(/WL\s*-?\s*(\d+)/g)].map((m) => Number(m[1]));
    return { status: "WAITLIST", seats: null, rac: null, waitlist: all.length ? all[all.length - 1] : null };
  }
  if (/REGRET|NOT AVAILABLE|TRAIN DEPARTED|CHARTING DONE|CLASS NOT EXIST|NOT_AVAILABLE/.test(t)) {
    return { status: "NOT_AVAILABLE", seats: 0, rac: null, waitlist: null };
  }
  return { status: "UNKNOWN", seats: null, rac: null, waitlist: null };
}

const SA_MAX_AGE_MS = 24 * 60 * 60 * 1000;

function ryDateKey(ymd: string): string {
  /* API rows "8-9-2026" (D-M-YYYY, no padding) dete hain. */
  const m = ymd.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (!m) return ymd;
  return `${Number(m[3])}-${Number(m[2])}-${m[1]}`;
}

export async function scrapeSeatAvailabilityWeb(
  trainNumber: string,
  dateYmd: string,
  from: string,
  to: string,
  classCode: string,
  quota = "GN",
  opts?: { noCachedRetry?: boolean; noLiveRetry?: boolean },
): Promise<ScrapedSeatAvailability | null> {
  const num = String(trainNumber).trim();
  if (!/^\d{5}$/.test(num) || !/^\d{4}-\d{2}-\d{2}$/.test(dateYmd)) return null;
  const f = String(from).toUpperCase();
  const t = String(to).toUpperCase();
  const c = String(classCode).toUpperCase();
  const q = String(quota || "GN").toUpperCase();
  const url =
    `https://sa.railyatri.in/api/v3/seat/availability/${num}/${dateYmd}/${f}/${t}/${c}/${q}.json` +
    /* Round-18m-17 (user: ConfirmTkt ne JAT→DADN 1A AVL dikhaya, hamare paas
     * railyatri cache mein WL2 tha): `refresh=true` par RailYatri IRCTC se LIVE
     * pull karta hai (data_from:"IRCTC", timestamp abhi ka) — API quota khatam
     * hone par bhi fresh seat data. Verified 2026-09-12: 12920 JAT→DADN 1A
     * cache "GNWL2/WL2" (10 Sep) → refresh "GNWL/AVAILABLE" ₹4345 (IRCTC, now). */
    `?device_type_id=6&utm_source=dweb_sa&user_id=-2345434&authentication_token=&train_search=true&train_source=${f}&train_destination=${t}&refresh=true`;
  try {
    const res = await (scrapeFetchImpl ?? globalThis.fetch.bind(globalThis))(url, {
      headers: { "User-Agent": UA, Accept: "application/json", Referer: "https://www.railyatri.in/" },
      signal: AbortSignal.timeout(SCRAPE_TIMEOUT_MS),
    });
    if (!res.ok) return null;
    type RyJson = {
      success?: boolean;
      error?: string | null;
      seat_availibility?: {
        availablity_date?: string;
        availablity_status?: string;
        seat_avl?: number | null;
        ticket_fare?: number | null;
        catering_charge?: number | null;
        total_fare?: number | null;
        last_updated_at?: string | null;
        cache_text?: string | null;
      }[];
      data_from?: string | null;
    } | null;
    let j = (await res.json()) as RyJson;
    let rows = j?.seat_availibility ?? [];
    /* Round-18m-25 (user: "ye data 12 din purana hai, railyatri se fresh lao"): IRCTC live pull
     * kabhi-kabhi transient "Unable to perform Transaction, Please try later" deta hai — 2–3 sec baad
     * wahi call fresh data de deta hai (verified 01:03 IST: 12920/12426/19804 sab live). Pehle hum
     * turant 12-din purani cache par gir jaate the. Ab maintenance-window ke alawa har live fail par
     * 2 retry (1.5s gap), phir hi cache. */
    const isMaintenance = (e: string | null | undefined) => /maintenance|resume at/i.test(String(e ?? ""));
    for (let attempt = 0; attempt < 2 && (!j?.success || !rows.length) && !isMaintenance(j?.error) && !opts?.noLiveRetry; attempt++) {
      await new Promise((r) => setTimeout(r, 1500));
      try {
        const rr = await (scrapeFetchImpl ?? globalThis.fetch.bind(globalThis))(url, {
          headers: { "User-Agent": UA, Accept: "application/json", Referer: "https://www.railyatri.in/" },
          signal: AbortSignal.timeout(SCRAPE_TIMEOUT_MS),
        });
        if (!rr.ok) continue;
        const jj = (await rr.json()) as RyJson;
        if (jj?.success && (jj.seat_availibility ?? []).length) {
          j = jj;
          rows = jj.seat_availibility ?? [];
        } else if (jj?.error) j = { ...(j ?? {}), error: jj.error };
      } catch {
        /* retry exhausted → cache below */
      }
    }
    /* Round-18m-23 (user 23:54 IST screenshot: "seat data nahi aayi"): IRCTC ka daily maintenance
     * window (~23:45–00:20) mein refresh=true `success:false, "services will resume at 00:20"` deta
     * hai — tab RailYatri ka CACHED endpoint (bina refresh) try karo; wahi asli IRCTC data hai,
     * bas kuch der purana (cache_text "As of 1 hour ago" ke saath, stale-guard yahi neeche). */
    if ((!j?.success || !rows.length) && !opts?.noCachedRetry) {
      const cached = await (async () => {
        try {
          const r2 = await (scrapeFetchImpl ?? globalThis.fetch.bind(globalThis))(url.replace("&refresh=true", ""), {
            headers: { "User-Agent": UA, Accept: "application/json", Referer: "https://www.railyatri.in/" },
            signal: AbortSignal.timeout(SCRAPE_TIMEOUT_MS),
          });
          if (!r2.ok) return null;
          return (await r2.json()) as RyJson;
        } catch {
          return null;
        }
      })();
      if (cached?.success && (cached.seat_availibility ?? []).length) {
        j = cached;
        rows = cached.seat_availibility ?? [];
      }
    }
    if (!j?.success || !rows.length) return null;
    const want = ryDateKey(dateYmd);
    const row = rows.find((r) => String(r.availablity_date ?? "").trim() === want) ?? null;
    if (!row) return null;
    const statusText = String(row.availablity_status ?? "").trim();
    if (!statusText) return null;
    const parsed = parseIrctcAvailabilityText(statusText);
    if (parsed.status === "UNKNOWN") return null;
    /* FRESHNESS guard: RailYatri cache purana ho sakta hai ("As of 16 days
     * ago" dekha) — booking-critical data 24h se purana kabhi nahi dete;
     * stale = null (honest UNKNOWN upar). Timestamp parse na ho to bhi null. */
    /* Live rows: "2026-09-12T13:21:11+05:30"; cached rows: "2026-09-12 13:20:03 +0530". */
    const updatedMs = Date.parse(String(row.last_updated_at ?? "").replace(" +0530", "+05:30").replace(" ", "T"));
    /* Round-18m (user: "fallback pe seat data poora nahi aa raha"): purani
     * cache ko chhupane ki jagah STALE flag ke saath do — UI "⚠ stale" + "as of
     * 2 months ago" dikhata hai, silent "Refresh" cell nahi. Timestamp hi na
     * ho to ab bhi null (kab ka hai pata nahi). */
    if (!Number.isFinite(updatedMs)) return null;
    const stale = Date.now() - updatedMs > SA_MAX_AGE_MS;
    /* Journey date beet chuki ho to bhi nahi. */
    if (Date.parse(`${dateYmd}T23:59:59+05:30`) < Date.now()) return null;
    const seats = parsed.status === "AVAILABLE" && typeof row.seat_avl === "number" ? row.seat_avl : parsed.seats;
    return {
      trainNumber: num,
      date: dateYmd,
      classCode: c,
      quota: q,
      statusText,
      status: parsed.status,
      seats,
      rac: parsed.rac,
      waitlist: parsed.waitlist,
      ticketFare: typeof row.ticket_fare === "number" ? row.ticket_fare : null,
      totalFare: typeof row.total_fare === "number" ? row.total_fare : null,
      cateringCharge: typeof row.catering_charge === "number" && row.catering_charge > 0 ? row.catering_charge : null,
      lastUpdatedAt: row.last_updated_at ?? null,
      cacheText: row.cache_text ?? null,
      live: String(j.data_from ?? "").toUpperCase() === "IRCTC",
      ...(stale ? { stale: true } : {}),
      provider: "web_railyatri",
      sourceUrl: `https://www.railyatri.in/seat-availability/${num}`,
    };
  } catch {
    return null;
  }
}

/* ── STATION NAME SEARCH via erail.in station list (Round-16). erail.in
 * apni site ke liye poori ~9000-station "CODE,Name,CODE,Name…" list
 * (/js/cmp/stations.js) serve karta hai — local DB (~70 stations) aur
 * railenquiry (sirf code→name) ke baad NAME-search ke liye yahi last
 * resort. Ek baar fetch, 6 ghante memory cache. */

let erailStationsCache: { at: number; list: { code: string; name: string }[] } | null = null;
const ERAIL_STATIONS_TTL_MS = 6 * 60 * 60 * 1000;

export async function erailStationList(): Promise<{ code: string; name: string }[]> {
  if (erailStationsCache && Date.now() - erailStationsCache.at < ERAIL_STATIONS_TTL_MS) return erailStationsCache.list;
  const html = await fetchHtml("https://erail.in/js/cmp/stations.js?v=092f8");
  if (!html) return erailStationsCache?.list ?? [];
  const m = html.match(/StationsData\s*=\s*"([^"]+)"/);
  if (!m) return erailStationsCache?.list ?? [];
  const parts = m[1].split(",");
  const list: { code: string; name: string }[] = [];
  for (let i = 0; i + 1 < parts.length; i += 2) {
    const code = parts[i].trim();
    const name = parts[i + 1].trim();
    if (/^[A-Z]{1,5}$/.test(code) && name && !/^\d+$/.test(name)) list.push({ code, name });
  }
  if (list.length > 1000) erailStationsCache = { at: Date.now(), list };
  return list;
}

export function _setErailStationsCacheForTests(list: { code: string; name: string }[] | null): void {
  erailStationsCache = list ? { at: Date.now(), list } : null;
}

/** Name/code search — exact code, phir name-prefix, phir name-contains.
 * "Jn"/"Junction" normalize. Max `limit` results. */
export async function scrapeStationSearchWeb(query: string, limit = 6): Promise<ScrapedStation[]> {
  const q = query.trim().toLowerCase().replace(/\s+/g, " ");
  if (q.length < 2) return [];
  const list = await erailStationList();
  if (!list.length) return [];
  const norm = (n: string) => n.toLowerCase().replace(/\bjn\b/g, "junction").replace(/[^a-z0-9 ]+/g, " ").replace(/\s+/g, " ").trim();
  const qn = norm(q);
  const scored: { s: { code: string; name: string }; score: number }[] = [];
  for (const s of list) {
    const n = norm(s.name);
    let score = 0;
    if (s.code.toLowerCase() === q) score = 100;
    else if (n === qn) score = 90;
    else if (n.startsWith(qn + " ")) score = 80;
    else if (n.startsWith(qn)) score = 70;
    else if (new RegExp(`\\b${qn.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\b`).test(n)) score = 50;
    if (score) scored.push({ s, score });
  }
  scored.sort((a, b) => b.score - a.score || a.s.name.length - b.s.name.length);
  return scored.slice(0, limit).map(({ s }) => ({
    code: s.code,
    name: s.name,
    city: s.name.replace(/\s+(Jn|Junction|Cantt|City|Terminus|Central|Town|Road|Halt|H)$/i, "").trim() || s.name,
    provider: "web_erail",
    sourceUrl: "https://erail.in/",
  }));
}

/* ───────────────────────── Round-16n: trains-between-stations (web) ─────────────────────────
 * User (2026-09-08): "RailCore daily limit hit → fallback par bhi trains nahi
 * dikh rahi, web scraping lagayi thi na?" — train SEARCH ka web fallback tha
 * hi nahi (sirf schedule/fare/availability/live ka tha). erail.in ka public
 * getTrains endpoint '~'-delimited rows deta hai: number, name, src/dst,
 * boarding FROM/TO code (exact — DLI vs NDLS alag), dep, arr, duration
 * (HH.MM, 24h+ bhi), 7-char running-days bitmask (Mon..Sun), aur class list. */
export type ScrapedTrainRow = {
  number: string;
  name: string;
  fromCode: string;
  fromName: string;
  toCode: string;
  toName: string;
  departure: string; // HH:MM
  arrival: string; // HH:MM
  durationMinutes: number;
  runsOn: number[]; // JS getDay(): 0=Sun..6=Sat
  classes: string[];
  type: string;
};

export type ScrapedTrainSearch = {
  trains: ScrapedTrainRow[];
  provider: "web_erail";
  sourceUrl: string;
};

function erailTime(raw: string): string | null {
  const m = String(raw ?? "").match(/^(\d{1,2})\.(\d{2})$/);
  if (!m) return null;
  return `${m[1].padStart(2, "0")}:${m[2]}`;
}

function erailDuration(raw: string): number | null {
  const m = String(raw ?? "").match(/^(\d{1,3})\.(\d{2})$/);
  if (!m) return null;
  return Number(m[1]) * 60 + Number(m[2]);
}

/** erail bitmask: 7 chars Mon..Sun → JS days (0=Sun). */
function erailDays(mask: string): number[] {
  const m = String(mask ?? "").trim();
  if (!/^[01]{7}$/.test(m)) return [0, 1, 2, 3, 4, 5, 6];
  const out: number[] = [];
  for (let i = 0; i < 7; i++) if (m[i] === "1") out.push((i + 1) % 7);
  return out.length ? out : [0, 1, 2, 3, 4, 5, 6];
}

export function parseErailTrainList(text: string): ScrapedTrainRow[] {
  const rows = String(text ?? "")
    .split("^")
    .map((r) => r.trim())
    .filter(Boolean);
  const out: ScrapedTrainRow[] = [];
  for (const row of rows) {
    const f = row.split("~");
    if (f.length < 14) continue;
    const number = f[0].trim();
    if (!/^\d{5}$/.test(number)) continue;
    const dep = erailTime(f[10]);
    const arr = erailTime(f[11]);
    const dur = erailDuration(f[12]);
    if (!dep || !arr || dur == null) continue;
    const classField = f.find((x) => /^(?:[A-Z0-9]{2}:[^|]*\|)+$/.test(x)) ?? "";
    let classes = [...classField.matchAll(/(?:^|\|)([A-Z0-9]{2}):/g)].map((m) => m[1]);
    /* Round-18m-24 (user LDH→CNB screenshot: 22432/18310 mein "2S — Refresh" column, jabki in trains
     * mein 2S coach hai hi nahi): erail ki class-list mein IRCTC "2S" ko unreserved/GN ke liye bhi
     * likh deta hai. Usi row ka RAKE composition (",,En:SLRD,SLRD,SLRD:GN,GN,GN:S,S1,SL:B,B1,3A:…")
     * sach batata hai — coach-class tokens nikaal kar reserved classes wahi rakho jo rake mein hain.
     * Rake na ho (14670 jaisi) to list waise hi. Kabhi class ADD nahi karte — sirf jhoothi hataate hain. */
    const rakeField = f.find((x) => /(?:^|:)[A-Z0-9+]+,[A-Z0-9+]*,[A-Z0-9+]+(?::|$)/.test(x) && /:[A-Z0-9]+,[A-Z0-9]*,(?:SL|3A|2A|1A|3E|CC|EC|2S|EA)(?::|$)/.test(x)) ?? "";
    if (rakeField) {
      const rakeClasses = new Set<string>();
      for (const seg of rakeField.split(":")) {
        const parts = seg.split(",");
        if (parts.length < 3) continue;
        for (const tok of parts[2].split("+")) if (/^(SL|3A|2A|1A|3E|CC|EC|2S|EA)$/.test(tok)) rakeClasses.add(tok);
      }
      if (rakeClasses.size) classes = classes.filter((c) => !/^(SL|3A|2A|1A|3E|CC|EC|2S|EA)$/.test(c) || rakeClasses.has(c));
    }
    const type = f.find((x) => /^(SUPERFAST|MAIL_EXPRESS|SHATABDI|RAJDHANI|COMPOSITE|RAIL_MOTOR|DURONTO|GARIB_RATH|VANDE_BHARAT|PASSENGER|MEMU|DEMU)$/.test(x)) ?? "Express";
    out.push({
      number,
      name: f[1].trim(),
      fromCode: f[7].trim().toUpperCase(),
      fromName: f[6].trim(),
      toCode: f[9].trim().toUpperCase(),
      toName: f[8].trim(),
      departure: dep,
      arrival: arr,
      durationMinutes: dur,
      runsOn: erailDays(f[13]),
      classes,
      type,
    });
  }
  return out;
}

export async function scrapeTrainsBetweenWeb(from: string, to: string): Promise<ScrapedTrainSearch | null> {
  const f = String(from ?? "").trim().toUpperCase();
  const t = String(to ?? "").trim().toUpperCase();
  if (!/^[A-Z]{2,5}$/.test(f) || !/^[A-Z]{2,5}$/.test(t)) return null;
  const url = `https://erail.in/rail/getTrains.aspx?Station_From=${f}&Station_To=${t}&DataSource=0&Language=0&Cache=true`;
  const body = await fetchHtml(url);
  if (!body) return null;
  const trains = parseErailTrainList(body);
  if (!trains.length) return null;
  return { trains, provider: "web_erail", sourceUrl: url };
}

/* ── TRAIN NAME SEARCH via erail.in train list (Round-16o). RailCore daily
 * limit par TRAIN_NAME_SEARCH "naam se koi train nahi mili" bolta tha —
 * erail.in apni site ke liye poori "NNNNN - NAME" list (/js5/IRTrains.js)
 * serve karta hai. Ek baar fetch, 6 ghante memory cache. Sirf number+naam
 * (route nahi) — schedule alag se aata hai. */
let erailTrainsCache: { at: number; list: { number: string; name: string }[] } | null = null;
const ERAIL_TRAINS_TTL_MS = 6 * 60 * 60 * 1000;

export function parseErailTrainNameList(raw: string): { number: string; name: string }[] {
  let arr: unknown = null;
  try {
    arr = JSON.parse(raw);
  } catch {
    const m = raw.match(/\[[\s\S]*\]/);
    if (m) {
      try {
        arr = JSON.parse(m[0]);
      } catch {
        arr = null;
      }
    }
  }
  if (!Array.isArray(arr)) return [];
  const out: { number: string; name: string }[] = [];
  for (const item of arr) {
    const m = String(item).match(/^\s*(\d{4,6})\s*-\s*(.+?)\s*$/);
    if (m) out.push({ number: m[1], name: m[2].replace(/\s+/g, " ") });
  }
  return out;
}

export async function erailTrainList(): Promise<{ number: string; name: string }[]> {
  if (erailTrainsCache && Date.now() - erailTrainsCache.at < ERAIL_TRAINS_TTL_MS) return erailTrainsCache.list;
  const body = await fetchHtml("https://erail.in/js5/IRTrains.js");
  if (!body) return erailTrainsCache?.list ?? [];
  const list = parseErailTrainNameList(body);
  if (list.length > 1000) erailTrainsCache = { at: Date.now(), list };
  return list;
}

export function _setErailTrainsCacheForTests(list: { number: string; name: string }[] | null): void {
  erailTrainsCache = list ? { at: Date.now(), list } : null;
}

export type ScrapedTrainName = { number: string; name: string; provider: "web_erail" };

/** Naam/number se trains — number exact, phir naam ke saare words match
 * (word-prefix), phir koi bhi word. Max `limit`. */
/** Round-18: erail names have spelling variants ("SHTABDI", "RAJDHNI") — allow 1 edit for ≥5-letter words (2 for ≥8). */
function looseWordMatch(a: string, b: string): boolean {
  if (Math.abs(a.length - b.length) > 2) return false;
  const max = a.length >= 8 ? 2 : 1;
  const dp = Array.from({ length: a.length + 1 }, (_, i) => [i, ...Array(b.length).fill(0)]);
  for (let j = 1; j <= b.length; j++) dp[0][j] = j;
  for (let i = 1; i <= a.length; i++)
    for (let j = 1; j <= b.length; j++) dp[i][j] = Math.min(dp[i - 1][j] + 1, dp[i][j - 1] + 1, dp[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
  return dp[a.length][b.length] <= max;
}

export async function scrapeTrainNameSearchWeb(query: string, limit = 10): Promise<ScrapedTrainName[]> {
  const q = query.trim().toLowerCase().replace(/\s+/g, " ");
  if (q.length < 3) return [];
  const list = await erailTrainList();
  if (!list.length) return [];
  if (/^\d{4,6}$/.test(q)) {
    return list.filter((t) => t.number === q).slice(0, limit).map((t) => ({ ...t, provider: "web_erail" as const }));
  }
  const norm = (s: string) => s.toLowerCase().replace(/\bexp\b/g, "express").replace(/\bsf\b/g, "superfast").replace(/[^a-z0-9 ]+/g, " ").replace(/\s+/g, " ").trim();
  const words = norm(q).split(" ").filter((w) => w.length >= 2 && !/^(train|trains|ki|ka|ke|wali|wala)$/.test(w));
  if (!words.length) return [];
  const scored: { t: { number: string; name: string }; hits: number; exact: boolean }[] = [];
  for (const t of list) {
    const n = norm(t.name);
    const nWords = n.split(" ");
    let hits = 0;
    for (const w of words) {
      if (nWords.some((nw) => nw === w || (w.length >= 4 && nw.startsWith(w)) || (w.length >= 5 && nw.length >= 5 && looseWordMatch(w, nw)))) hits++;
    }
    if (!hits) continue;
    scored.push({ t, hits, exact: n === words.join(" ") });
  }
  if (!scored.length) return [];
  /* Sirf best tier — saare words match hue to wahi; warna max-hits waale.
   * ("express" jaisa common word akela 3000 trains hit karega.) */
  const maxHits = Math.max(...scored.map((x) => x.hits));
  return scored
    .filter((x) => x.hits === maxHits)
    .sort((a, b) => Number(b.exact) - Number(a.exact) || a.t.number.localeCompare(b.t.number))
    .slice(0, limit)
    .map(({ t }) => ({ ...t, provider: "web_erail" as const }));
}

/* ── Round-18m-30z: TRAIN FACTS (pantry/catering, classes, type, rating, run-days) from verified sites ──
 * User (2026-09-14): "12461 mein khaana milta hai?" → app ne Wikipedia ka galat page dump kiya. Ab per-train
 * facts do sources se: erail.in train-enquiry (plain sentence: "Pantry is not available", classes, category,
 * gauge) + confirmtkt.com train-schedule (JSON: HasPantry, TrainType, FoodRating, DaysOfRun). Dono se mila to
 * cross-check; mismatch ho to dono batao (invent nahi). */
export type ScrapedTrainFacts = {
  trainNumber: string;
  trainName: string | null;
  source: string | null;
  destination: string | null;
  pantry: boolean | null;
  /* Round-21b (25 Sep, user: "kuch bhi fake mat rakho — jo real provider se aaye wahi dikhao"):
   * pantry ka per-source sach. erail = IR timetable line ("Pantry is (not) available"),
   * confirmtkt = JSON ka HasPantry. Dono alag ho sakte hain (dekha gaya: 12716/12926 par erail
   * "available" aur confirmtkt false) — isliye merged `pantry` ke saath ye bhi rakha jaata hai,
   * UI sach ke hisaab se decide kare (guess nahi). */
  pantrySources: { erail: boolean | null; confirmtkt: boolean | null };
  classes: string[];
  trainType: string | null;
  runDays: string | null;
  foodRating: number | null;
  rating: number | null;
  sentence: string | null;
  providers: string[];
  sourceUrls: string[];
};

export async function scrapeTrainFactsWeb(trainNumber: string): Promise<ScrapedTrainFacts | null> {
  const num = String(trainNumber ?? "").trim();
  if (!/^\d{4,6}$/.test(num)) return null;
  const out: ScrapedTrainFacts = { trainNumber: num, trainName: null, source: null, destination: null, pantry: null, pantrySources: { erail: null, confirmtkt: null }, classes: [], trainType: null, runDays: null, foodRating: null, rating: null, sentence: null, providers: [], sourceUrls: [] };
  const erailUrl = `https://erail.in/train-enquiry/${num}`;
  const ctUrl = `https://www.confirmtkt.com/train-schedule/${num}`;
  const [erail, ct] = await Promise.all([fetchHtml(erailUrl), fetchHtml(ctUrl)]);
  if (erail) {
    const text = erail.replace(/<script[\s\S]*?<\/script>|<style[\s\S]*?<\/style>/gi, " ").replace(/<[^>]+>/g, "\n").replace(/&nbsp;/g, " ");
    const flat = text.replace(/\s+/g, " ");
    const m = new RegExp(`${num}\\s+([A-Z0-9 .'&-]+?),\\s*(.+?)\\s+to\\s+(.+?)\\s+runs\\s+(.+?),\\s*has classes\\s+([A-Z0-9 ]+)\\.\\s*(Pantry is (?:not )?available)`, "i").exec(flat);
    if (m) {
      /* Sentence ke aage page-title text chipka hota hai ("X Train Route Abount Train 12461 X 12461 X") → last "NNNNN NAME" hi asli. */
      const nm = m[1].trim();
      const parts = nm.split(new RegExp(`\\b${num}\\b`)).map((x) => x.trim()).filter(Boolean);
      out.trainName = (parts.length ? parts[parts.length - 1] : nm).replace(/\s+Train Route.*$/i, "").trim();
      out.source = m[2].trim();
      out.destination = m[3].trim();
      out.runDays = m[4].trim();
      out.classes = m[5].trim().split(/\s+/).filter((c) => /^[0-9A-Z]{2,3}$/.test(c) && c !== "GN");
      out.pantry = !/not available/i.test(m[6]);
      out.pantrySources.erail = out.pantry;
      out.sentence = `${num} ${out.trainName}, ${out.source} to ${out.destination}, runs ${out.runDays}, classes ${out.classes.join(" ")}. ${m[6]}.`;
      const cat = /category type is ([A-Za-z ]+?)\./i.exec(text.replace(/\s+/g, " "));
      if (cat) out.trainType = cat[1].trim();
      out.providers.push("web_erail");
      out.sourceUrls.push(erailUrl);
    }
  }
  if (ct) {
    const hp = /"HasPantry":(true|false)/.exec(ct);
    const tt = /"TrainType":"([^"]+)"/.exec(ct);
    const fr = /"FoodRating":([0-9.]+)/.exec(ct);
    const rt = /"Rating":([0-9.]+)/.exec(ct);
    const tn = /"TrainName":"([^"]+)"/.exec(ct);
    if (hp || tt) {
      const ctPantry = hp ? hp[1] === "true" : null;
      out.pantrySources.confirmtkt = ctPantry;
      if (out.pantry == null) out.pantry = ctPantry;
      else if (ctPantry != null && ctPantry !== out.pantry) out.sentence = `${out.sentence ?? ""} (Note: erail (IR timetable data) says pantry ${out.pantry ? "available" : "not available"}, confirmtkt says ${ctPantry ? "available" : "not available"} — sources differ; tell the user both; erail is the primary source; suggest confirming on IRCTC while booking. Do NOT ask the user to retry.)`.trim();
      if (!out.trainType && tt) out.trainType = tt[1];
      if (fr) out.foodRating = Number(fr[1]);
      if (rt) out.rating = Number(rt[1]);
      if (!out.trainName && tn) out.trainName = tn[1];
      out.providers.push("web_confirmtkt");
      out.sourceUrls.push(ctUrl);
    }
  }
  return out.providers.length ? out : null;
}
