# Production deploy report

**Status:** READY and promoted  
**Deployment:** `dpl_7Qg6BgBdrwzSgV2zdZhymGy9ZKwQ`  
**Production URL:** https://railbook-three.vercel.app  
**Alias:** https://railbook-bookkro.vercel.app  
**Secrets printed:** none

## Environment (names only)

Present on Vercel Production: `RAILWAY_PROVIDER`, `RAILCORE_API_KEY`, `RAILKIT_API_KEY`, `NVIDIA_API_KEY`, `NVIDIA_MODEL`, `NVIDIA_BASE_URL`, `AI_REQUEST_TIMEOUT_MS`.  
`RAILWAY_PROVIDER` is `railcore`. No RailRadar keys.

## Runtime identity

| Check | Result |
| --- | --- |
| Active railway provider | **railcore** (`/api/health` `provider=railcore`, `mock=false`) |
| RailKit fallback | **on** (`fallback=railkit`) |
| NVIDIA | **Connected** — `openai/gpt-oss-20b` on `https://integrate.api.nvidia.com/v1` |
| RailCore | **up** — stations, ASR→LDH search (22 trains), fare, availability, timetable |
| RailKit | **up** — PNR (honest 404), cancelled list, live fallback |
| Booking confirmation | **safe** — `/api/agent` `confirmBook: false` even on `Book kar do` + `FARE_REVIEW` |

## Smoke tests (live production)

| # | Case | Result |
| --- | --- | --- |
| 1 | “Mujhe Amritsar se Ludhiana jaana hai” | **PASS** — ASR→LDH, `date=null`, missing `date` + `passengers`. Did not assume today. NVIDIA 20b NLU. |
| 2 | Mid-booking “12014 ka live status batao” | **PASS** — tool `getLiveStatus` ok, real 12014 / AMRITSAR SHTABDI, then resume “Kis date ko jaana hai?” Context ASR→LDH kept. `confirmBook: false`. |
| 3 | “Meri bookings dikhao” | **PASS** — fast-path `VIEW_BOOKINGS` / `getMyBookings`. |
| 4 | “Amritsar se cancelled trains batao” | **PASS** — intent `CANCELLED_TRAINS`; RailKit `cancelList` fully 15 / partial 45 (real payload, e.g. 15615 GHY SCL EXPRESS). |
| 5 | 12014 CC ASR→LDH fare / availability | **PASS** — AVAILABLE 590 seats, ticket ₹510 + service ₹25 = ₹535, `railwayAvailable: true`. |
| 6 | Facts not invented | **PASS** — empty/failed PNR is 404; live/fare/AVL/cancelled from providers. |
| 7 | No book without Confirm UI | **PASS** — agent never sets `confirmBook`. Charge stays on Confirm & Book / Yes, Book It. |
| 8 | Production provider | **PASS** — `railwayProvider` identity is **railcore**. Live for 12014 used **railkit_fallback** (RailCore live unusable; fallback returned real running data, not a fake). |

## Notes

- First promote (`dpl_8sAmpZK…`) crashed serverless boot (`FUNCTION_INVOCATION_FAILED`) because the function imported `src/ai/agent.js` outside the server bundle. Same orchestrator; helpers now live at `server/agent/context.ts`. Second promote is the live one.
- Automated `prod-verify` live check “failed” only because it required `provider===railcore`; the HTTP 200 body was real 12014 status via RailKit fallback.

---

# AI-first tool-calling deploy (2026-09-04)

**Deployment:** `dpl_DzTdw6icqhRYrHbU7x8NB2Wu1NrS` (promoted)
**Production URL:** https://railbook-three.vercel.app · **Alias:** https://railbook-bookkro.vercel.app
**Secrets printed:** none (verified: every /api/agent response scanned for key patterns)

- `RAILCORE_API_KEY` replaced with the new live key (patch, 200 OK). `RAILKIT_API_KEY`, `NVIDIA_API_KEY`, `NVIDIA_MODEL` kept untouched. `RAILWAY_PROVIDER=railcore`.
- `/api/health`: `provider=railcore`, `fallback=railkit`, `agent.auto=true`, `model=openai/gpt-oss-20b`.
- Architecture: AI-FIRST tool calling (see AGENTIC_TOOLCALLING_REPORT.md) — 419/419 unit tests, 12/12 live production tool-call cases.
- GitHub: mohitmalhotra2420/Raillllbook@main.

---

# Adversarial-validation fix deploy (2026-09-04, round 2)

**Deployment:** `dpl_Coho9PuFWH5JuU3iNtT4GHCHP4Dt` (production, READY)
**Production URL:** https://railbook-three.vercel.app
**Secrets printed:** none

- `NVIDIA_API_KEY` updated to the new live key (sensitive var patched in place, targets production+preview). No `NVIDIA_FALLBACK_MODEL` env exists — the nemotron code-default was removed, so the model chain is GPT-OSS-20b only.
- Code shipped (local commit `a717c2f`, pending GitHub push): nemotron removal, "next <weekday>" = next ISO week, legacy-city station clusters (Calcutta/Madras/Bombay → real options, never model-improvised), airport guard, honest `provider=none` on dual-provider search failure, station-code grounding guard (NDAP-class inventions blocked), preferred_class partition via verified probed class.
- Live verify after deploy: `engine=agentic_tool_calling`, `model=openai/gpt-oss-20b`, "next Saturday" → tool arg `date=2026-09-12` ✓, Delhi ambiguity → asks with real options ✓, `grounded=true`.
- Unit suite: 429/429 (10 new regression tests for the fixes).
- RailCore daily quota was exhausted during local validation (resets 00:00 IST); provider fallback to real RailKit data verified in that window (`railkit_fallback` sources, no mocks).
