import type { DialogSlot, KnownSlots, NluResult } from "./ai/nlu";
import type {
  BookingRecord,
  ClassAvailability,
  ClassCode,
  FareBreakdown,
  Meta,
  Recommendation,
  Station,
  TrainResult,
  WalletState,
} from "./types";

export type AgentProgress = { phase: string; done?: number; total?: number; detail?: string; at: number };
export type AgentResponse = {
      nlu: NluResult;
      source: "ai" | "nlu";
      context: AgentContextClient | null;
      tool: string | null;
      toolOk: boolean | null;
      reply: string | null;
      interrupt: boolean;
      resumeAsk: DialogSlot | null;
      resumeText: string | null;
      confirmBook: false;
      missingFields: string[];
      modelUsed?: string | null;
      latencyMs?: number;
      failureReason?: string | null;
      engine?: "agentic_tool_calling" | "deterministic" | null;
      /** Round-27: live board ki seat rows (chat ka seat/availability jawab) — train-wise chips ke liye. */
      seatFilter?: {
        classCodes: string[];
        line: string | null;
        /** Round-49: jo trains destination tak nahi jaati thin, unka note (card me dikhta hai). */
        dropNote?: string | null;
        /** Round-50: unme se seat-detih trains ka alag section (jaise JAT tak, aage khud). */
        nearbyNote?: string | null;
        rows: {
          number: string;
          name: string;
          classCode: string;
          status: string;
          seats: number | null;
          rac: number | null;
          waitlist: number | null;
          fare: number | null;
          departure: string | null;
          durationMinutes: number | null;
        }[];
        wlRows: {
          number: string;
          name: string;
          classCode: string;
          status: string;
          seats: number | null;
          rac: number | null;
          waitlist: number | null;
          fare: number | null;
          departure: string | null;
          durationMinutes: number | null;
        }[];
        trainsSeen: number;
        source: string | null;
      } | null;
      /** Round-32: model ka khud chuna hua "agla kadam" (chips) — verified data se validate hokar. */
      nextActions?: { label: string; utterance: string; primary?: boolean }[] | null;
      trains?: import("./ai/agent").AgentTrainTable | null;
      journey?: import("./ai/agent").AgentJourneyPlan | null;
      alternatives?: import("./ai/agent").AgentAlternatives | null;
      trainPicker?: import("./ai/agent").AgentTrainPicker | null;
      /** Round-18m-33: dropdown choice (station / run-day / train). */
      choice?: { kind: "station" | "run_date" | "train"; title: string; options: { label: string; value: string; sub?: string | null }[]; sendTemplate: string } | null;
      /** Round-18m: live-status date chooser (only dates with real provider data). */
      liveDates?: { trainNumber: string; trainName: string | null; options: { date: string; label: string; runState: string; provider: string }[] } | null;
      toolTrace?: {
        step: number;
        tool: string;
        args: Record<string, unknown>;
        ok: boolean;
        source: string | null;
        summary: string;
        latencyMs: number;
        dataPreview?: string;
      }[] | null;
      grounded?: boolean | null;
      agenticFailureReason?: string | null;
    };

async function request<T>(url: string, init?: RequestInit): Promise<T> {
  const res = await fetch(url, {
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(init?.headers ?? {}),
    },
  });
  const data = (await res.json().catch(() => ({}))) as T & { error?: string; code?: string };
  if (!res.ok) {
    const err = new Error(data.error ?? `Request failed (${res.status})`) as Error & {
      status: number;
      code?: string;
      body: unknown;
    };
    err.status = res.status;
    err.code = data.code;
    err.body = data;
    throw err;
  }
  return data;
}

/** Slots the server-side AI agent returns so the deterministic booking flow can continue. */
export interface AgentContextClient {
  intent?: string | null;
  origin?: { code: string; name: string; city: string } | null;
  destination?: { code: string; name: string; city: string } | null;
  date?: string | null;
  dateProvided?: boolean;
  passengers?: number | null;
  paxProvided?: boolean;
  classCode?: string | null;
  selectedTrainNumber?: string | null;
  selectedTrainName?: string | null;
  bookingStage?: string | null;
  pendingAsk?: string | null;
  /** Round-8: "nayi baat/reset" one-shot signal — client apne journey slots clear kare. */
  justReset?: boolean;
}

export interface AdminModel {
  id: string;
  name: string;
  provider: string | null;
  description: string | null;
  contextLength: number | null;
  inputPricing: string;
  outputPricing: string;
  capabilities: string[];
  modalities: string[];
  suitable: boolean;
}

export interface AdminModelCatalog {
  endpoint: string;
  fetchedAt: string | null;
  models: AdminModel[];
  suitable: AdminModel[];
  selectedId: string | null;
  selectedSource: "env" | "auto" | "none";
  fallbackIds?: string[];
  error: string | null;
}

export interface NvidiaAdminModel {
  id: string;
  name: string;
  provider: string | null;
  kind: string;
  capabilities: string[];
  contextLength: number | null;
  suitable: boolean;
}

export interface NvidiaAdminCatalog {
  connected: boolean;
  status: string;
  label: string;
  modelsAvailable: number;
  suitableCount: number;
  endpoint: string;
  fetchedAt: string | null;
  error: string | null;
  models: NvidiaAdminModel[];
}

export const api = {
  /** Round-20: pantry/catering (read-only) — passenger form ka food choice. */
  trainPantry: (trainNumber: string) => trainPantryApi(trainNumber),
  adminModels: (refresh = false) =>
    request<AdminModelCatalog>(`/api/admin/models${refresh ? "?refresh=1" : ""}`),
  refreshAdminModels: () =>
    request<AdminModelCatalog>("/api/admin/models/refresh", { method: "POST" }),
  nvidiaModels: (refresh = false) =>
    request<NvidiaAdminCatalog>(`/api/admin/nvidia${refresh ? "?refresh=1" : ""}`),
  refreshNvidiaModels: () =>
    request<NvidiaAdminCatalog>("/api/admin/nvidia/refresh", { method: "POST" }),
  understand: (body: { text: string; lastAsked?: DialogSlot; known?: KnownSlots; now?: string; lastFactTrain?: string }) =>
    request<{
      nlu: NluResult;
      source: "ai" | "nlu";
      provider?: "nvidia" | null;
      missingFields: string[];
      modelUsed?: string | null;
      latencyMs?: number;
      failureReason?: string | null;
      groundedReply?: string | null;
      groundedTrain?: string | null;
    }>("/api/understand", {
      method: "POST",
      body: JSON.stringify(body),
    }),
  agentAuto: (body: {
    text: string;
    history: { role: "user" | "assistant"; content: string }[];
    state: unknown;
    now: string;
    today: string;
  }) =>
    request<{
      ok: boolean;
      fallback: boolean;
      reply: string | null;
      ui: {
        trains?: TrainResult[];
        recommendations?: Recommendation[];
        from?: Station;
        to?: Station;
        date?: string;
        stationChoice?: { slot?: "from" | "to"; city: string; stations: Station[] };
        selectTrain?: string;
        openWallet?: boolean;
        openBookings?: boolean;
      };
      state: unknown;
      toolsUsed: { name: string; ok: boolean; provider: string | null; latencyMs: number }[];
      source: "ai" | "evidence" | "none";
      grounded: boolean;
      modelUsed: string | null;
      protocol: "tools" | "json" | null;
      rounds: number;
      latencyMs: number;
      llmMs: number[];
      failureReason: string | null;
      confirmBook: false;
    }>("/api/agent/auto", {
      method: "POST",
      body: JSON.stringify(body),
    }),
  /* Round-18m-29: same payload as /api/agent, delivered over SSE with REAL backend progress
   * (phase names + completed/total provider checks). Falls back to plain POST if the stream
   * is unavailable (older server / proxy buffering). */
  agentStream: async (body: unknown, onProgress: (e: AgentProgress) => void): Promise<AgentResponse> => {
    const plain = (): Promise<AgentResponse> => request<AgentResponse>("/api/agent", { method: "POST", body: JSON.stringify(body) });
    let res: Response;
    try {
      res = await fetch("/api/agent/stream", { method: "POST", headers: { "Content-Type": "application/json", Accept: "text/event-stream" }, body: JSON.stringify(body) });
    } catch {
      return plain();
    }
    if (!res.ok || !res.body || !/text\/event-stream/.test(res.headers.get("content-type") ?? "")) return plain();
    const reader = res.body.getReader();
    const dec = new TextDecoder();
    let buf = "";
    let result: AgentResponse | null = null;
    let error: string | null = null;
    let sawProgress = false;
    for (;;) {
      let read: ReadableStreamReadResult<Uint8Array>;
      try {
        read = await reader.read();
      } catch {
        /* mobile/CF often aborts an idle long stream — surface network error, do NOT restart a full turn */
        if (result) return result;
        if (error) throw new Error(error);
        throw new Error("network error");
      }
      const { value, done } = read;
      if (done) break;
      buf += dec.decode(value, { stream: true });
      let idx: number;
      while ((idx = buf.indexOf("\n\n")) >= 0) {
        const chunk = buf.slice(0, idx);
        buf = buf.slice(idx + 2);
        const ev = /^event: (.+)$/m.exec(chunk)?.[1]?.trim();
        const data = chunk.split("\n").filter((l) => l.startsWith("data: ")).map((l) => l.slice(6)).join("\n");
        if (!ev || !data) continue;
        try {
          if (ev === "progress") { sawProgress = true; onProgress(JSON.parse(data) as AgentProgress); }
          else if (ev === "result") result = JSON.parse(data) as AgentResponse;
          else if (ev === "error") error = String((JSON.parse(data) as { error?: string }).error ?? "stream error");
        } catch { /* partial/invalid frame ignored */ }
      }
    }
    if (result) return result;
    if (error) throw new Error(error);
    /* Stage-5L-net: stream opened and made progress but never sent `result` (proxy idle cut /
     * browser tab freeze). Restarting plain /api/agent would re-run a 60–120s turn and still
     * fail on mobile — report network error once instead. Fresh stream never started → plain OK. */
    if (sawProgress) throw new Error("network error");
    return plain();
  },
  agent: (body: unknown) =>
    request<AgentResponse>("/api/agent", {
      method: "POST",
      body: JSON.stringify(body),
    }),
  liveTrain: (number: string, date?: string) =>
    request<{ live: { trainNumber: string; trainName: string; status: string; delayMinutes: number | null; lastUpdatedAt?: string | null; currentStation: string | null; nextStation: string | null; journeyDate?: string | null; runState?: "not_started" | "running" | "completed" | null } }>(
      `/api/live?number=${encodeURIComponent(number)}${date ? `&date=${encodeURIComponent(date)}` : ""}`,
    ),
  trainSchedule: (number: string) =>
    request<{
      schedule: {
        trainNumber: string;
        trainName: string;
        stops?: { code: string; name: string; arrival: string; departure: string; day?: string }[];
      };
    }>(`/api/schedule?number=${encodeURIComponent(number)}`),
  trainCoachPosition: (number: string, station?: string) =>
    request<{
      coachPosition: {
        trainNumber: string;
        stationCode: string | null;
        coaches: {
          name: string;
          classCode: string;
          positionFromEngine: number | null;
          sequence: number | null;
        }[];
      };
      provider?: string;
    }>(
      `/api/coach-position?number=${encodeURIComponent(number)}${
        station ? `&station=${encodeURIComponent(station)}` : ""
      }`,
    ),
  trainHistory: (number: string, date: string) =>
    request<{
      history: {
        trainNumber: string;
        trainName: string;
        date: string;
        status?: string | null;
        runState?: "not_started" | "running" | "completed" | "unknown";
        stops: { code: string; name: string; arrival: string | null; departure: string | null; delay: number | null; done?: boolean }[];
      };
    }>(`/api/history?number=${encodeURIComponent(number)}&date=${encodeURIComponent(date)}`),
  stationBoard: (code: string, hours = 2) =>
    request<{
      board: {
        summary: string | null;
        total: number;
        trains: {
          trainNo: string;
          trainName: string;
          platform: string | null;
          source: string | null;
          dest: string | null;
          arrival: string | null;
          departure: string | null;
          delay: number | null;
          cancelled: boolean | null;
        }[];
      };
    }>(`/api/station-board?code=${encodeURIComponent(code)}&hours=${hours}`),
  cancelled: () =>
    request<{
      cancelled: {
        fully: { trainNo?: string; trainName?: string }[];
        partial: { trainNo?: string; trainName?: string }[];
      };
    }>("/api/cancelled"),
  pnrLookup: (pnr: string) =>
    request<{ pnr: { pnr: string; data?: unknown; booking?: unknown } }>(`/api/pnr/${encodeURIComponent(pnr)}`),
  meta: () => request<Meta>("/api/meta"),
  stations: (q = "") =>
    request<{ stations: Station[]; needChoice?: boolean; city?: string; provider?: string }>(
      `/api/stations?q=${encodeURIComponent(q)}`,
    ),
  search: (from: string, to: string, date: string) =>
    request<{
      trains: TrainResult[];
      recommendations: Recommendation[];
      empty: boolean;
    }>(
      `/api/trains?from=${encodeURIComponent(from)}&to=${encodeURIComponent(to)}&date=${encodeURIComponent(date)}`,
    ),
  availability: (
    trainNumber: string,
    date: string,
    from: string,
    to: string,
    classCode: ClassCode,
  ) =>
    request<{ availability: ClassAvailability; bookable: boolean }>(
      `/api/availability?trainNumber=${trainNumber}&date=${date}&from=${from}&to=${to}&classCode=${classCode}`,
    ),
  classBoard: (trainNumber: string, date: string, from: string, to: string, quota = "GN", hintClasses: string[] = []) =>
    request<{ classes: ClassAvailability[]; source?: string }>(
      `/api/availability?trainNumber=${encodeURIComponent(trainNumber)}&date=${encodeURIComponent(date)}&from=${encodeURIComponent(from)}&to=${encodeURIComponent(to)}&quota=${encodeURIComponent(quota)}${
        hintClasses.length ? `&classes=${encodeURIComponent(hintClasses.join(","))}` : ""
      }`,
    ),
  fare: (
    trainNumber: string,
    date: string,
    from: string,
    to: string,
    classCode: ClassCode,
    passengers: number,
  ) =>
    request<{ fare: FareBreakdown }>(
      `/api/fare?trainNumber=${trainNumber}&date=${date}&from=${from}&to=${to}&classCode=${classCode}&passengers=${passengers}`,
    ),
  wallet: () => request<{ wallet: WalletState }>("/api/wallet"),
  addMoney: (amount: number) =>
    request<{ wallet: WalletState }>("/api/wallet/add", {
      method: "POST",
      body: JSON.stringify({ amount }),
    }),
  createBooking: (body: unknown) =>
    request<{ booking: BookingRecord }>("/api/bookings", {
      method: "POST",
      body: JSON.stringify(body),
    }),
  confirmBooking: (id: string) =>
    request<{ booking: BookingRecord; wallet: WalletState }>(
      `/api/bookings/${id}/confirm`,
      { method: "POST" },
    ),
  getBooking: (id: string) =>
    request<{ booking: BookingRecord }>(`/api/bookings/${id}`),
  listBookings: () => request<{ bookings: BookingRecord[] }>("/api/bookings"),
  cancelBooking: (id: string) =>
    request<{ result: { refundAmount: number }; wallet: WalletState }>(
      `/api/bookings/${id}/cancel`,
      { method: "POST" },
    ),
};

/* ── Round-17: Journey intelligence endpoints (deterministic engine) ── */
export function planJourneyApi(body: {
  from: string;
  to: string;
  date: string;
  travelClass?: string | null;
  preference?: string | null;
  includeConnections?: boolean;
  includeAlternativeDates?: boolean;
}) {
  return request<import("./ai/agent").AgentJourneyPlan>("/api/journey/plan", { method: "POST", body: JSON.stringify(body) });
}

/** Round-18e: alternatives for a low/WL/RAC train+class (server-verified only). */
export function journeyAlternativesApi(body: { trainNumber: string; from: string; to: string; date: string; travelClass?: string | null; knownRow?: { status: string; seats?: number | null; waitlist?: number | null; rac?: number | null; source?: string | null } | null }) {
  return request<import("./ai/agent").AgentAlternatives>("/api/journey/alternatives", { method: "POST", body: JSON.stringify(body) });
}

/** Round-18: smart train picker (number or name → real validated matches). */
export function pickTrainsApi(q: string, ctx?: { from?: string | null; to?: string | null }) {
  const p = new URLSearchParams({ q });
  if (ctx?.from) p.set("from", ctx.from);
  if (ctx?.to) p.set("to", ctx.to);
  return request<import("./ai/agent").AgentTrainPicker>(`/api/trains/pick?${p.toString()}`);
}

/** Round-20: train ka catering/pantry info (read-only; wahi server function jo AI ka TRAIN_FACTS
 * tool use karta hai) — passenger form me food choice dikhane ke liye.
 * Round-21b: ab per-source sach bhi aata hai (sources/conflict/premiumCatering/evidence) taaki UI
 * "jo real provider kehta hai" wahi dikhaye — merged value par guess nahi. */
export type TrainPantry = {
  trainNumber: string;
  trainName?: string | null;
  trainType?: string | null;
  pantry: boolean | null;
  /** Round-21b: dono sources ka apna jawaab (null = us source ne kuch nahi kaha). */
  sources?: { erail: boolean | null; confirmtkt: boolean | null };
  /** Round-21b: sources aapas me alag-alag — guess nahi, honest note. */
  conflict?: boolean;
  /** Round-21b: Rajdhani/Shatabdi/Duronto/Vande Bharat/Tejas — catering fare me included. */
  premiumCatering?: boolean;
  /** Round-21b: sirf yahi true hone par passenger form me Food choice dikhta hai (IRCTC jaisa). */
  foodChoiceExpected?: boolean;
  /** Round-21b: insaani zubaan me evidence lines (UI note me dikhti hain). */
  evidence?: string[];
  providers: string[];
  note: string | null;
};

export function trainPantryApi(trainNumber: string) {
  return request<TrainPantry>(`/api/trains/${encodeURIComponent(trainNumber)}/pantry`);
}
