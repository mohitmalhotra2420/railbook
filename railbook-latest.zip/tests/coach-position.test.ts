import { afterEach, describe, expect, it } from "vitest";
import request from "supertest";
import { createApp } from "../server/app";
import { coachPosition, resetRailcoreBookings, setRailcoreFetch } from "../server/railway/railcore";
import { routedCoachPosition } from "../server/railway/router";
import { setScrapeFetch } from "../server/railway/webscrape";
import { executeTool } from "../server/agent/tools";
import { routeRailwayIntent } from "../server/understand/toolRoute";
import { setProvider } from "../server/providers/index";

afterEach(() => {
  setRailcoreFetch(null);
  setScrapeFetch(null);
  resetRailcoreBookings();
  process.env.RAILWAY_PROVIDER = "mock";
  process.env.RAILCORE_API_KEY = "";
  process.env.RAILKIT_API_KEY = "";
  setProvider(null);
});

function jsonResponse(status: number, body: unknown) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json" },
  });
}

const REAL_SHAPE = {
  success: true,
  data: {
    train_number: "12014",
    coach_position: [
      { sequence: 3, coach_name: "E1", class_code: "EC", position_from_engine: 3 },
      { sequence: 2, coach_name: "E2", class_code: "EC", position_from_engine: 2 },
      { sequence: 4, coach_name: "C14", class_code: "CC", position_from_engine: 4 },
      { sequence: 5, coach_name: "C13", class_code: "CC", position_from_engine: 5 },
    ],
  },
  meta: { api_version: "v1" },
};

describe("RailCore coach position", () => {
  it("adapter parses the payload, sorts engine-first, drops junk rows", async () => {
    process.env.RAILWAY_PROVIDER = "railcore";
    process.env.RAILCORE_API_KEY = "rk_live_test_secret";
    setRailcoreFetch(async (input) => {
      const url = String(input);
      expect(url).toContain("https://ir.railcore.tech/v1/trains/12014/coach-position");
      expect(url).toContain("stationCode=LDH");
      return jsonResponse(200, REAL_SHAPE);
    });
    const out = await coachPosition("12014", "LDH");
    expect(out).not.toBeNull();
    expect(out?.trainNumber).toBe("12014");
    expect(out?.stationCode).toBe("LDH");
    expect(out?.coaches.map((c) => c.name)).toEqual(["E2", "E1", "C14", "C13"]);
    expect(out?.coaches[0]).toMatchObject({ classCode: "EC", positionFromEngine: 2, sequence: 2 });
  });

  it("adapter returns null on HTTP failure or empty composition (never invents)", async () => {
    process.env.RAILWAY_PROVIDER = "railcore";
    process.env.RAILCORE_API_KEY = "rk_live_test_secret";
    setRailcoreFetch(async () => jsonResponse(200, { success: true, data: { train_number: "1", coach_position: [] } }));
    expect(await coachPosition("1")).toBeNull();
    setRailcoreFetch(async () => jsonResponse(500, { success: false, error: { message: "boom" } }));
    expect(await coachPosition("12014")).toBeNull();
  });

  it("API endpoint serves coach position with provider identity and no key leak", async () => {
    process.env.RAILWAY_PROVIDER = "railcore";
    process.env.RAILCORE_API_KEY = "rk_live_test_secret";
    setRailcoreFetch(async () => jsonResponse(200, REAL_SHAPE));
    const app = createApp();
    // Flat route — Vercel serverless only routes 1-segment /api/* paths.
    const res = await request(app).get("/api/coach-position").query({ number: "12014", station: "LDH" });
    expect(res.status).toBe(200);
    expect(res.body.provider).toBe("railcore");
    expect(res.body.coachPosition.trainNumber).toBe("12014");
    expect(res.body.coachPosition.coaches).toHaveLength(4);
    expect(JSON.stringify(res.body)).not.toMatch(/rk_live_test_secret|RAILCORE_API_KEY/i);
  });

  it("flat route rejects an invalid train number", async () => {
    process.env.RAILWAY_PROVIDER = "railcore";
    process.env.RAILCORE_API_KEY = "rk_live_test_secret";
    const app = createApp();
    const res = await request(app).get("/api/coach-position").query({ number: "12AB" });
    expect(res.status).toBe(400);
  });

  it("deep route (local dev) serves the same payload", async () => {
    process.env.RAILWAY_PROVIDER = "railcore";
    process.env.RAILCORE_API_KEY = "rk_live_test_secret";
    setRailcoreFetch(async () => jsonResponse(200, REAL_SHAPE));
    const app = createApp();
    const res = await request(app).get("/api/trains/12014/coach-position").query({ station: "LDH" });
    expect(res.status).toBe(200);
    expect(res.body.provider).toBe("railcore");
  });

  it("API endpoint answers 404 honestly when provider has no composition", async () => {
    process.env.RAILWAY_PROVIDER = "railcore";
    process.env.RAILCORE_API_KEY = "rk_live_test_secret";
    setRailcoreFetch(async () => jsonResponse(404, { success: false, error: { message: "no data" } }));
    const app = createApp();
    const res = await request(app).get("/api/trains/99999/coach-position").query({ station: "LDH" });
    expect(res.status).toBe(404);
    expect(res.body.error).toMatch(/coach position/i);
    expect(JSON.stringify(res.body)).not.toMatch(/rk_live_test_secret/i);
  });

  it("endpoint rejects malformed station codes instead of forwarding them", async () => {
    process.env.RAILWAY_PROVIDER = "railcore";
    process.env.RAILCORE_API_KEY = "rk_live_test_secret";
    let seenStation = "";
    setRailcoreFetch(async (input) => {
      seenStation = new URL(String(input)).searchParams.get("stationCode") ?? "";
      return jsonResponse(200, REAL_SHAPE);
    });
    const app = createApp();
    await request(app).get("/api/trains/12014/coach-position").query({ station: "LDH; DROP" });
    expect(seenStation).toBe("");
  });

  it("router: no RailCore key → web-scrape last-resort (scrape bhi fail = honest none)", async () => {
    /* 2026-09-06 (user: API-first, fail par verified site): key na ho to
     * router ab web-scrape try karta hai. Yahan scrape fetch bhi fail —
     * tab hi honest none. */
    process.env.RAILWAY_PROVIDER = "railcore";
    process.env.RAILCORE_API_KEY = "";
    setRailcoreFetch(async () => {
      throw new Error("network must not be touched without a key");
    });
    setScrapeFetch(async () => ({ ok: false, status: 404, text: async () => "", json: async () => ({}) }) as unknown as Response);
    const routed = await routedCoachPosition("12014", "LDH");
    expect(routed.coachPosition).toBeNull();
    expect(routed.provider).toBe("none");
  });
});

describe("Coach position voice/chat intent", () => {
  it("routes Hindi/English/Hinglish coach phrases to getCoachPosition", () => {
    expect(routeRailwayIntent("12014 ka coach position batao")).toMatchObject({
      kind: "COACH_POSITION",
      tool: "getCoachPosition",
      trainNumber: "12014",
    });
    expect(routeRailwayIntent("coach dikhao")).toMatchObject({ kind: "COACH_POSITION", tool: "getCoachPosition" });
    expect(routeRailwayIntent("13006 ki coaches batao")).toMatchObject({
      kind: "COACH_POSITION",
      tool: "getCoachPosition",
      trainNumber: "13006",
    });
    expect(routeRailwayIntent("12926 की कोच पोजिशन")).toMatchObject({
      kind: "COACH_POSITION",
      tool: "getCoachPosition",
      trainNumber: "12926",
    });
  });

  it("does not hijack live status or timetable phrasing", () => {
    expect(routeRailwayIntent("12014 kahan hai").kind).toBe("LIVE_TRAIN_STATUS");
    expect(routeRailwayIntent("12014 ka timetable").kind).toBe("TRAIN_SCHEDULE");
  });

  it("agent tool returns an honest composition summary", async () => {
    process.env.RAILWAY_PROVIDER = "railcore";
    process.env.RAILCORE_API_KEY = "rk_live_test_secret";
    setRailcoreFetch(async (input) => {
      expect(String(input)).toContain("/coach-position");
      return jsonResponse(200, REAL_SHAPE);
    });
    const out = await executeTool("getCoachPosition", { trainNumber: "12014" });
    expect(out.ok).toBe(true);
    expect(out.provider).toBe("railcore");
    expect(out.summary).toContain("4 coaches");
    expect(out.summary).toContain("E2");
    expect(out.summary).toContain("EC×2");
  });

  it("agent tool asks for the train number instead of guessing", async () => {
    const out = await executeTool("getCoachPosition", {});
    expect(out.ok).toBe(false);
    expect(out.summary).toMatch(/train number/i);
  });

  it("/api/agent answers 'coach position batao' with a real composition", async () => {
    process.env.RAILWAY_PROVIDER = "railcore";
    process.env.RAILCORE_API_KEY = "rk_live_test_secret";
    setRailcoreFetch(async () => jsonResponse(200, REAL_SHAPE));
    const app = createApp();
    const res = await request(app).post("/api/agent").send({ text: "12014 ki coach position batao" });
    expect(res.status).toBe(200);
    expect(res.body.tool).toBe("getCoachPosition");
    expect(res.body.toolOk).toBe(true);
    expect(res.body.reply).toContain("coaches");
    expect(JSON.stringify(res.body)).not.toMatch(/rk_live_test_secret/i);
  });

  it("/api/agent asks for the number when none is spoken", async () => {
    process.env.RAILWAY_PROVIDER = "railcore";
    process.env.RAILCORE_API_KEY = "rk_live_test_secret";
    const app = createApp();
    const res = await request(app).post("/api/agent").send({ text: "coach position batao" });
    expect(res.status).toBe(200);
    expect(res.body.reply).toMatch(/train number/i);
  });
});
