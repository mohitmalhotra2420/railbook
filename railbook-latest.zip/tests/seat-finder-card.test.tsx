/* 24 Sep 2026 — Seat Finder CARD ka render test (jsdom, koi browser nahi).
 * Verify: card dikhta hai, SEAT upar + WAITLIST neeche, "Available" / "Sabhi trains" chips
 * sach me list badalte hain, "data nahi aayi" wali trains alag list me aati hain (seat nahi maani jaati).
 * Sab client-side — AI/server/API touch nahi. */
import { describe, expect, it, vi, beforeEach } from "vitest";
import { fireEvent, render, screen, waitFor } from "@testing-library/react";

vi.mock("../src/voice/speakGuide", () => ({ speakGuide: vi.fn(), cancelGuide: vi.fn() }));

import { SeatFinder } from "../src/components/SeatFinder";
import type { SeatIntent } from "../src/seatfinder";

const intent = (over: Partial<SeatIntent> = {}): SeatIntent => ({
  wants: false,
  classCode: null,
  acOnly: false,
  confirmedOnly: false,
  afterMin: null,
  beforeMin: null,
  windowLabel: null,
  earliest: false,
  cheapest: false,
  ...over,
});

const search = [
  { number: "11078", name: "JHELUM EXPRESS", departure: "04:30", arrival: "11:15", durationLabel: "6h 45m", arrivalDayOffset: 0 },
  { number: "20986", name: "SWARAJ EXPRESS", departure: "00:40", arrival: "05:55", durationLabel: "5h 15m", arrivalDayOffset: 0 },
  { number: "14617", name: "PRNC-ASR JANSEWA EXP", departure: "14:01", arrival: "17:05", durationLabel: "3h 04m", arrivalDayOffset: 0 },
];

const boardRows = [
  {
    trainNumber: "11078",
    trainName: "JHELUM EXPRESS",
    classes: [
      { classCode: "2A", code: "2A", status: "AVAILABLE", seats: 29, rac: null, waitlist: null, fare: 825, source: "web_confirmtkt" },
      { classCode: "3A", code: "3A", status: "WAITLIST", seats: null, rac: null, waitlist: 12, fare: 585, source: "web_confirmtkt" },
    ],
  },
  {
    trainNumber: "20986",
    trainName: "SWARAJ EXPRESS",
    classes: [{ classCode: "2A", code: "2A", status: "RAC", seats: null, rac: 9, waitlist: null, fare: 890, source: "web_confirmtkt" }],
  },
];

function stubFetch(rows: unknown) {
  (globalThis as unknown as { fetch: unknown }).fetch = vi.fn(async () => ({ ok: true, json: async () => ({ trains: rows }) }));
}

beforeEach(() => stubFetch(boardRows));

describe("Seat Finder card (jsdom)", () => {
  it("card render hota hai: SEAT upar, WAITLIST neeche, aur 'data nahi aayi' alag list", async () => {
    render(<SeatFinder from="AAAB" to="BBBB" date="2026-09-25" rows={search} intent={intent()} onChip={() => {}} />);
    expect(await screen.findByText("Seat Finder")).toBeTruthy();
    await waitFor(() => expect(screen.getAllByText(/JHELUM EXPRESS/).length).toBeGreaterThan(0));

    /* Seat wali (AVL/RAC) upar */
    expect(screen.getByText(/Seat mil jayegi/)).toBeTruthy();
    expect(screen.getByText("AVL 29")).toBeTruthy();
    expect(screen.getByText("RAC 9")).toBeTruthy();
    /* WL neeche */
    expect(screen.getByText(/Seat pakki nahi/)).toBeTruthy();
    expect(screen.getAllByText("WL 12").length).toBeGreaterThan(0);
    /* 14617 ka board data nahi aaya → "seat nahi" nahi, alag list */
    expect(screen.getByText(/Seat data provider se nahi aayi/)).toBeTruthy();
    expect(screen.getByText(/data nahi aayi/)).toBeTruthy();
  });

  it("'✅ Available' chip = sirf AVL + RAC (WL section hat jata hai); '🚆 Sabhi trains' = sab wapas", async () => {
    render(<SeatFinder from="AAAC" to="BBBC" date="2026-09-25" rows={search} intent={intent()} onChip={() => {}} />);
    await waitFor(() => expect(screen.getByText(/Seat pakki nahi/)).toBeTruthy());

    fireEvent.click(screen.getByText("✅ Available"));
    /* WL ka apna SECTION hat jata hai (Available = AVL + RAC) */
    await waitFor(() => expect(screen.queryByText(/Seat pakki nahi/)).toBeNull());
    expect(screen.getByText("AVL 29")).toBeTruthy(); /* AVL */
    expect(screen.getByText("RAC 9")).toBeTruthy(); /* RAC bhi — user ne kaha dono */
    /* Round-19f (user: "upar card me classes available me sabhi dikh nhi rhi jabki neeche zyada hai"):
     * us train ki WL/N-A class bhi block me HALKI (off) dikhti hai — chhupti nahi. */
    const off = [...document.querySelectorAll(".sf-cchip.off")].map((c) => c.textContent ?? "");
    expect(off.some((t) => t.includes("WL 12"))).toBe(true);

    fireEvent.click(screen.getByText("🚆 Sabhi trains"));
    await waitFor(() => expect(screen.getByText(/Seat pakki nahi/)).toBeTruthy());
    expect(screen.getAllByText("WL 12").length).toBeGreaterThan(0);
  });

  it("class chip (2A) sirf us class ki rows dikhata hai — 3A WL row hat jati hai", async () => {
    render(<SeatFinder from="AAAD" to="BBBD" date="2026-09-25" rows={search} intent={intent()} onChip={() => {}} />);
    await waitFor(() => expect(screen.getAllByText("WL 12").length).toBeGreaterThan(0));
    fireEvent.click(screen.getAllByRole("button", { name: "2A" })[0]);
    await waitFor(() => expect(screen.queryByText("WL 12")).toBeNull());
    expect(screen.getByText("AVL 29")).toBeTruthy();
    expect(screen.getByText("RAC 9")).toBeTruthy();
  });

  it("user ne 'sirf confirmed' bola ho → card seedha Available mode me khulta hai", async () => {
    render(<SeatFinder from="AAAE" to="BBBE" date="2026-09-25" rows={search} intent={intent({ confirmedOnly: true })} onChip={() => {}} />);
    await waitFor(() => expect(screen.queryByText(/Seat pakki nahi/)).toBeNull());
    expect(screen.getByText("AVL 29")).toBeTruthy();
  });

  it("row tap karne par wahi purana utterance jata hai (train + class + date + route)", async () => {
    const onChip = vi.fn();
    render(<SeatFinder from="AAAF" to="BBBF" date="2026-09-25" rows={search} intent={intent()} onChip={onChip} />);
    await waitFor(() => expect(screen.getByText("AVL 29")).toBeTruthy());
    fireEvent.click(screen.getByText("AVL 29"));
    expect(onChip).toHaveBeenCalledWith("11078 ki seat availability 2A 2026-09-25 ko AAAF se BBBF");
  });

  it("WL ka 'confirm %' kahin nahi dikhaya jata (hamare paas wo data hai hi nahi)", async () => {
    const { container } = render(<SeatFinder from="AAAG" to="BBBG" date="2026-09-25" rows={search} intent={intent()} onChip={() => {}} />);
    await waitFor(() => expect(screen.getByText(/Seat pakki nahi/)).toBeTruthy());
    expect(container.textContent).not.toMatch(/\d+\s*%/); /* koi "83% confirm" jaisa andaza nahi */
    expect(container.textContent).toMatch(/confirm % hum nahi dete/i);
  });
});

/* ── 24 Sep 2026 (user: "card sirf single class hi dikha raha tha — jabki available hai") ────────
 * Per-train class board se missing/UNKNOWN class aa jaati hai (wahi endpoint jo TrainBoard
 * "Refresh seats" use karta hai). Yahan: 12029 ka route-board row sirf CC deta hai; per-train
 * fetch EC (real, available) laata hai → dono dikhni chahiye. */
const routeBoardPartial = [
  { trainNumber: "12029", trainName: "SWARN SHATABDI", classes: [
    { classCode: "CC", code: "CC", status: "AVAILABLE", seats: 86, rac: null, waitlist: null, fare: 415, source: "web_railyatri" },
    { classCode: "EC", code: "EC", status: "UNKNOWN", seats: null, rac: null, waitlist: null, fare: null, source: "web_railyatri" },
  ] },
];
const perTrainEC = {
  classes: [{ code: "EC", status: "AVAILABLE", seats: 6, rac: null, waitlist: null, fare: 660, source: "web_railyatri" }],
};

function stubFetchSplit() {
  (globalThis as unknown as { fetch: unknown }).fetch = vi.fn(async (url: string) => {
    if (String(url).includes("trainNumber=")) return { ok: true, json: async () => perTrainEC };
    return { ok: true, json: async () => ({ trains: routeBoardPartial }) };
  });
}

describe("Seat Finder card — per-train class enrichment", () => {
  it("route board me UNKNOWN class ko per-train board se real bana kar dikhata hai", async () => {
    stubFetchSplit();
    const rows = [{ number: "12029", name: "SWARN SHATABDI", departure: "11:11", arrival: "12:38", durationLabel: "1h 27m", arrivalDayOffset: 0 }];
    render(<SeatFinder from="LDH" to="BEAS" date="2026-09-25" rows={rows} intent={intent()} onChip={() => {}} />);
    expect(await screen.findByText("Seat Finder")).toBeTruthy();
    await waitFor(() => expect(screen.getAllByText(/12029/).length).toBeGreaterThan(0));
    /* EC asli row (available 6) — "status nahi mila" nahi */
    await waitFor(() => expect(screen.getByText("AVL 6")).toBeTruthy());
    expect(screen.queryByText("status nahi mila")).toBeNull();
  });

  it("'AC' chip 2S/SL hata deta hai", async () => {
    stubFetch(boardRows);
    render(<SeatFinder from="AAAB" to="BBBB" date="2026-09-25" rows={search} intent={intent({ wants: true, acOnly: true })} onChip={() => {}} />);
    expect(await screen.findByText("Seat Finder")).toBeTruthy();
    await waitFor(() => expect(screen.getAllByText(/SWARAJ EXPRESS/).length).toBeGreaterThan(0));
    /* card AC mode me hai */
    expect(screen.getByText(/AC classes/)).toBeTruthy();
  });
});

/* ── 24 Sep 2026 (user screenshot: card me SAARI 28 trains "data nahi aayi" — board call khaali
 * aayi thi, provider busy). Ab: honest banner + ↻ dobara try, aur 28-row confusion nahi. ─────── */
describe("Seat Finder card — board fail hone par", () => {
  it("khaali board → banner + '↻ Dobara try karo', poori list 'data nahi aayi' nahi dikhati", async () => {
    (globalThis as unknown as { fetch: unknown }).fetch = vi.fn(async () => ({ ok: true, json: async () => ({ trains: [] }) }));
    const rows = [{ number: "12029", name: "SWARN SHATABDI", departure: "11:11", arrival: "12:38", durationLabel: "1h 27m", arrivalDayOffset: 0 }];
    render(<SeatFinder from="ZZZZ" to="YYYY" date="2027-01-01" rows={rows} intent={intent()} onChip={() => {}} />);
    expect(await screen.findByText(/Live board abhi nahi aa payi/, {}, { timeout: 6000 })).toBeTruthy();
    expect(screen.getByText("↻ Dobara try karo")).toBeTruthy();
    expect(screen.queryByText(/DATA NAHI/)).toBeNull();
  });

  it("↻ dabane par board dobara maangta hai aur data aane par rows dikh jaati hain", async () => {
    let calls = 0;
    (globalThis as unknown as { fetch: unknown }).fetch = vi.fn(async (url: string) => {
      if (String(url).includes("trainNumber=")) return { ok: true, json: async () => ({ classes: [] }) };
      calls += 1;
      if (calls <= 2) return { ok: true, json: async () => ({ trains: [] }) };
      return { ok: true, json: async () => ({ trains: boardRows }) };
    });
    const rows = [{ number: "11078", name: "JHELUM EXPRESS", departure: "04:30", arrival: "11:15", durationLabel: "6h 45m", arrivalDayOffset: 0 }];
    render(<SeatFinder from="AAAA" to="BBBB" date="2026-09-26" rows={rows} intent={intent()} onChip={() => {}} />);
    fireEvent.click(await screen.findByText("↻ Dobara try karo", {}, { timeout: 5000 }));
    await waitFor(() => expect(screen.getByText("AVL 29")).toBeTruthy());
  });
});

/* ── Round-19 (24 Sep 2026, user screenshots) ───────────────────────────────────────────────────
 * 1) "direct mein bahut si trains available hai lekin neeche seat finder mein avl mein sabhi show
 *     nhi kar rhi and sabhi available classes bhi nhi aa rhi" — Seat Finder sirf route board dekhta
 *     tha (jo 12926 ko WL bata deta hai) jabki upar wala card per-train board se AVL dikhata hai.
 *     Ab card ke apne per-train rows (classOptions) base hain → numbers wahi, saari classes dikhti hain.
 * 2) "kal subha ki trains btao" → poori din ki list — ab window ("subah") ka filter chalta hai.  */
const cardRows = [
  { trainNumber: "11078", trainName: "JHELUM EXPRESS", classes: [
    { classCode: "3A", status: "AVAILABLE", seats: 8, rac: null, waitlist: null, fare: 760, source: "web_railyatri" },
    { classCode: "2A", status: "AVAILABLE", seats: 8, rac: null, waitlist: null, fare: 1070, source: "web_railyatri" },
    { classCode: "SL", status: "NOT_AVAILABLE", seats: null, rac: null, waitlist: null, fare: 290, source: "web_railyatri" },
  ] },
  { trainNumber: "12926", trainName: "PASCHIM EXPRESS", classes: [
    { classCode: "2A", status: "AVAILABLE", seats: 5, rac: null, waitlist: null, fare: 1270, source: "web_railyatri" },
    { classCode: "3A", status: "AVAILABLE", seats: 23, rac: null, waitlist: null, fare: 915, source: "web_railyatri" },
    { classCode: "SL", status: "AVAILABLE", seats: 8, rac: null, waitlist: null, fare: 360, source: "web_railyatri" },
  ] },
];
/* Route board purani/adhoori baat karta hai: 12926 "WL" — par card me AVL hai (asli per-train data). */
const staleRouteBoard = [
  { trainNumber: "11078", trainName: "JHELUM EXPRESS", classes: [
    { classCode: "3A", status: "AVAILABLE", seats: 18, rac: null, waitlist: null, fare: 760, source: "web_confirmtkt" },
  ] },
  { trainNumber: "12926", trainName: "PASCHIM EXPRESS", classes: [
    { classCode: "2A", status: "WAITLIST", seats: null, rac: null, waitlist: 4, fare: 1270, source: "web_confirmtkt" },
  ] },
];
const cardSearch = [
  { number: "11078", name: "JHELUM EXPRESS", departure: "04:30", arrival: "13:15", durationLabel: "8h 45m", arrivalDayOffset: 0 },
  { number: "12926", name: "PASCHIM EXPRESS", departure: "09:40", arrival: "19:10", durationLabel: "9h 30m", arrivalDayOffset: 0 },
];

describe("Seat Finder card — card ka data base (Round-19)", () => {
  it("card ke per-train rows Available me saari classes dikhate hain (12926 bhi, jo route board me WL thi)", async () => {
    (globalThis as unknown as { fetch: unknown }).fetch = vi.fn(async () => ({ ok: true, json: async () => ({ trains: staleRouteBoard }) }));
    render(
      <SeatFinder from="LDH" to="MTJ" date="2026-09-27" rows={cardSearch} cardBoard={cardRows} intent={intent({ confirmedOnly: true })} onChip={() => {}} />,
    );
    expect(await screen.findByText("Seat Finder")).toBeTruthy();
    /* card ke numbers hi dikhein (route board ka 18 nahi) */
    await waitFor(() => expect(screen.getAllByText("AVL 8").length).toBeGreaterThan(0));
    expect(screen.queryByText("AVL 18")).toBeNull(); /* route board ka purana number nahi */
    /* 12926 ki 2A/3A/SL — teeno AVL rows */
    expect(screen.getAllByText(/AVL 5/).length).toBeGreaterThan(0);
    expect(screen.getAllByText(/AVL 23/).length).toBeGreaterThan(0);
    expect(screen.getAllByText(/AVL 8/).length).toBeGreaterThan(0);
    /* footer batata hai ki data card ka hi hai */
    expect(screen.getByText(/upar wale card ka hi per-train board/)).toBeTruthy();
  });

  it("'subah' window → sirf subah ki trains (16:50 wali nahi), label bhi dikhta hai", async () => {
    const rows = [
      { number: "12014", name: "AMRITSAR SHTABDI", departure: "04:55", arrival: "06:57", durationLabel: "2h 02m", arrivalDayOffset: 0 },
      { number: "12030", name: "SWARN SHATABDI", departure: "16:50", arrival: "18:50", durationLabel: "2h", arrivalDayOffset: 0 },
    ];
    const board = [
      { trainNumber: "12014", trainName: "AMRITSAR SHTABDI", classes: [{ classCode: "CC", status: "AVAILABLE", seats: 410, rac: null, waitlist: null, fare: 490, source: "web_railyatri" }] },
      { trainNumber: "12030", trainName: "SWARN SHATABDI", classes: [{ classCode: "CC", status: "AVAILABLE", seats: 100, rac: null, waitlist: null, fare: 490, source: "web_railyatri" }] },
    ];
    (globalThis as unknown as { fetch: unknown }).fetch = vi.fn(async () => ({ ok: true, json: async () => ({ trains: board }) }));
    render(
      <SeatFinder
        from="ASR"
        to="LDH"
        date="2026-09-25"
        rows={rows}
        intent={intent({ wants: true, afterMin: 240, beforeMin: 720, windowLabel: "Subah (04:00–12:00)" })}
        onChip={() => {}}
      />,
    );
    expect(await screen.findByText("Seat Finder")).toBeTruthy();
    await waitFor(() => expect(screen.getByText("AVL 410")).toBeTruthy());
    expect(screen.getAllByText(/Subah \(04:00–12:00\)/).length).toBeGreaterThan(0);
    expect(screen.queryByText("AVL 100")).toBeNull(); /* 16:50 subah nahi */
  });
});

/* ── Round-19c (24 Sep, user dobara screenshot): "direct mein bahut si trains available hai lekin neeche
 * seat finder mein avl mein sabhi show nhi kar rhi". Route board 12926 ko sab WL batata hai, par usi
 * train ka per-train board (wahi endpoint jo TrainBoard "Refresh seats" chalata hai) 3A/2A/SL
 * AVAILABLE deta hai → "Available" tab par wahi asli rows dikhni chahiye. ───────────────────────── */
const staleBoard = [
  {
    trainNumber: "12926",
    trainName: "PASCHIM EXPRESS",
    classes: [
      { classCode: "3A", code: "3A", status: "WAITLIST", seats: null, rac: null, waitlist: 14, fare: 915, source: "web_confirmtkt" },
      { classCode: "2A", code: "2A", status: "WAITLIST", seats: null, rac: null, waitlist: 4, fare: 1270, source: "web_confirmtkt" },
    ],
  },
];
const perTrain12926 = {
  classes: [
    { code: "3A", status: "AVAILABLE", seats: 23, rac: null, waitlist: null, fare: 915, source: "web_railyatri" },
    { code: "2A", status: "AVAILABLE", seats: 5, rac: null, waitlist: null, fare: 1270, source: "web_railyatri" },
    { code: "SL", status: "AVAILABLE", seats: 8, rac: null, waitlist: null, fare: 360, source: "web_railyatri" },
  ],
};

describe("Seat Finder — purana route board vs fresh per-train board (Round-19c)", () => {
  it("'Available' tab par WL dikhne wali train per-train verify hoke asli AVL rows dikhati hai", async () => {
    (globalThis as unknown as { fetch: unknown }).fetch = vi.fn(async (url: string) => {
      if (String(url).includes("trainNumber=")) return { ok: true, json: async () => perTrain12926 };
      return { ok: true, json: async () => ({ trains: staleBoard }) };
    });
    render(
      <SeatFinder
        from="AAAQ"
        to="BBBQ"
        date="2026-09-25"
        rows={[{ number: "12926", name: "PASCHIM EXPRESS", departure: "09:40", arrival: "19:10", durationLabel: "9h 30m", arrivalDayOffset: 0 }]}
        intent={intent()}
        onChip={() => {}}
      />,
    );
    expect(await screen.findByText("Seat Finder")).toBeTruthy();
    /* pehle (Sabhi trains): route board ki purani baat — WL */
    await waitFor(() => expect(screen.getByText("WL 14")).toBeTruthy());

    fireEvent.click(screen.getByText("✅ Available"));
    /* fresh per-train probe ke baad: asli AVAILABLE rows (aur wo train list me chhupi nahi) */
    await waitFor(() => expect(screen.getByText("AVL 23")).toBeTruthy(), { timeout: 8000 });
    expect(screen.getByText("AVL 5")).toBeTruthy();
    expect(screen.getByText("AVL 8")).toBeTruthy();
    expect(screen.queryByText("WL 14")).toBeNull();
  });
});

/* ── Round-19e (24 Sep, user screenshot: "upar card mein classes available mein sabhi dikh nhi rhi jabki
 * neeche classes zyada hai"): pehle har class apni row thi aur 6 rows ke baad "aur rows dekho" — isliye
 * train ki kuch classes pehli nazar me gayab thi. Ab har train ka ek block hai jisme uski SAARI classes
 * ek saath (upar wale card jaisa), aur koi class 6-row cap me chhupti nahi. ────────────────────────── */
const manyTrains = [
  { number: "14719", name: "BKN ASR EXP", departure: "04:25", arrival: "06:06", durationLabel: "1h 41m", arrivalDayOffset: 0 },
  { number: "14631", name: "DDN ASR EXPRESS", departure: "04:46", arrival: "06:30", durationLabel: "1h 44m", arrivalDayOffset: 0 },
  { number: "12029", name: "SWARN SHATABDI", departure: "11:11", arrival: "12:38", durationLabel: "1h 27m", arrivalDayOffset: 0 },
  { number: "12053", name: "JANSHATABDI", departure: "15:40", arrival: "17:05", durationLabel: "1h 25m", arrivalDayOffset: 0 },
];
const manyBoard = [
  { trainNumber: "14719", trainName: "BKN ASR EXP", classes: [
    { classCode: "3A", code: "3A", status: "AVAILABLE", seats: 306, rac: null, waitlist: null, fare: 520, source: "web_railyatri" },
    { classCode: "2A", code: "2A", status: "AVAILABLE", seats: 84, rac: null, waitlist: null, fare: 725, source: "web_railyatri" },
    { classCode: "SL", code: "SL", status: "AVAILABLE", seats: 287, rac: null, waitlist: null, fare: 150, source: "web_railyatri" },
    { classCode: "1A", code: "1A", status: "NOT_AVAILABLE", seats: null, rac: null, waitlist: null, fare: null, source: "web_railyatri" },
  ] },
  { trainNumber: "14631", trainName: "DDN ASR EXPRESS", classes: [{ classCode: "SL", code: "SL", status: "AVAILABLE", seats: 154, rac: null, waitlist: null, fare: 150, source: "web_railyatri" }] },
  { trainNumber: "12029", trainName: "SWARN SHATABDI", classes: [
    { classCode: "CC", code: "CC", status: "AVAILABLE", seats: 86, rac: null, waitlist: null, fare: 345, source: "web_railyatri" },
    { classCode: "EC", code: "EC", status: "AVAILABLE", seats: 4, rac: null, waitlist: null, fare: 660, source: "web_railyatri" },
  ] },
  { trainNumber: "12053", trainName: "JANSHATABDI", classes: [{ classCode: "2S", code: "2S", status: "AVAILABLE", seats: 852, rac: null, waitlist: null, fare: 90, source: "web_railyatri" }] },
];

describe("Seat Finder — train-wise blocks, koi class chhupti nahi (Round-19e)", () => {
  const stub = () => {
    (globalThis as unknown as { fetch: unknown }).fetch = vi.fn(async () => ({ ok: true, json: async () => ({ trains: manyBoard }) }));
  };
  const blockOf = (container: HTMLElement, train: string) =>
    [...container.querySelectorAll(".sf-group")].find((g) => g.textContent?.includes(train));

  it("ek train ki saari AVAILABLE classes ek hi block me (14719: 3A + 2A + SL) — 'Available' tab", async () => {
    stub();
    const { container } = render(
      <SeatFinder from="AAAR" to="BBBR" date="2026-09-25" rows={manyTrains} intent={intent({ confirmedOnly: true })} onChip={() => {}} />,
    );
    await waitFor(() => expect(screen.getByText("AVL 306")).toBeTruthy());
    const block = blockOf(container, "14719")!;
    for (const t of ["AVL 306", "AVL 84", "AVL 287"]) expect(block.textContent).toContain(t); /* teeno classes ek saath */
    expect(block.textContent).toContain("4 classes"); /* saari classes is train ki */
    expect(block.textContent).toContain("3 me seat");
    /* Round-19f: Available tab me bhi train ki SAARI classes dikhti hain — jo seat nahi wali (1A N/A)
     * wo HALKI (off) chip me, koi class chhupti nahi (user ki baar-baar wali shikayat ka fix). */
    const chips = [...(block.querySelectorAll(".sf-cchip"))];
    expect(chips.length).toBe(4);
    const off = chips.filter((c) => c.classList.contains("off")).map((c) => c.textContent ?? "");
    expect(off.length).toBe(1);
    expect(off[0]).toContain("1A");
    const on = chips.filter((c) => !c.classList.contains("off")).map((c) => c.textContent ?? "");
    expect(on.length).toBe(3);
    for (const t of ["AVL 306", "AVL 84", "AVL 287"]) expect(on.join(" | ")).toContain(t);
  });

  it("'Sabhi trains' me ek train ki har class dikhti hai — available upar block me, WL/N-A neeche uske apne block me", async () => {
    stub();
    const { container } = render(
      <SeatFinder from="AAAT" to="BBBT" date="2026-09-25" rows={manyTrains} intent={intent()} onChip={() => {}} />,
    );
    await waitFor(() => expect(screen.getByText("AVL 306")).toBeTruthy());
    /* seat block: 3 available classes */
    const seatBlocks = [...container.querySelectorAll(".sf-group.seat")];
    const seat14719 = seatBlocks.find((g) => g.textContent?.includes("14719"))!;
    expect(seat14719.textContent).toContain("AVL 84");
    /* WL/N-A section bhi train-wise: 14719 ka 1A N/A uske block me */
    await waitFor(() => expect(container.querySelectorAll(".sf-group.wl").length).toBeGreaterThan(0));
    const wl14719 = [...container.querySelectorAll(".sf-group.wl")].find((g) => g.textContent?.includes("14719"));
    expect(wl14719?.textContent).toContain("1A");
    expect([...(container.querySelectorAll(".sf-group.seat, .sf-group.wl"))].length).toBeGreaterThanOrEqual(5);
  });

  it("7+ available classes hone par bhi koi chip chhupti nahi (purana 6-row cap gaya)", async () => {
    stub();
    const { container } = render(
      <SeatFinder from="AAAS" to="BBBS" date="2026-09-25" rows={manyTrains} intent={intent({ confirmedOnly: true })} onChip={() => {}} />,
    );
    await waitFor(() => expect(screen.getByText("AVL 852")).toBeTruthy());
    for (const t of ["AVL 306", "AVL 84", "AVL 287", "AVL 154", "AVL 86", "AVL 4", "AVL 852"]) expect(screen.getByText(t)).toBeTruthy();
    expect(container.querySelectorAll(".sf-group").length).toBe(4); /* chaaron trains, bina tap */
    expect(container.textContent).not.toMatch(/aur \d+ rows dekho/);
  });
});

/* ── Round-19f (user baar-baar, screenshot ke saath: "upar card me classes available me sabhi dikh nhi
 * rhi jabki neeche zyada hai"): ab Available tab me bhi POORA sach dikhta hai —
 *   • seat wali train ke block me uski SAARI classes (seat wale rangdar, baaki halki),
 *   • aur jin trains me koi available class nahi, wo bhi apne block me (saari classes halki) —
 *     alag "SEAT NAHI" heading ke saath.
 * Isliye upar wale journey card se train/class count match karta hai; kuch bhi chhupa nahi. ─────── */
describe("Seat Finder — Available tab me poora card (Round-19f)", () => {
  it("seat na wali trains bhi dikhti hain (SEAT NAHI section) — koi train/class chhupti nahi", async () => {
    (globalThis as unknown as { fetch: unknown }).fetch = vi.fn(async () => ({ ok: true, json: async () => ({ trains: manyBoard }) }));
    const { container } = render(
      <SeatFinder from="AAAU" to="BBBU" date="2026-09-25" rows={manyTrains} intent={intent({ confirmedOnly: true })} onChip={() => {}} />,
    );
    await waitFor(() => expect(screen.getByText("AVL 306")).toBeTruthy());
    /* manyBoard me saari trains me seat hai — isliye SEAT NAHI section nahi hona chahiye */
    expect(screen.queryByText(/in trains me koi AVAILABLE \/ RAC class nahi/)).toBeNull();
  });

  it("jab koi train me seat nahi: wo train apni saari classes ke saath halki dikhti hai (alag heading)", async () => {
    const board = [
      { trainNumber: "14719", trainName: "BKN ASR EXP", classes: [
        { classCode: "2A", code: "2A", status: "AVAILABLE", seats: 84, rac: null, waitlist: null, fare: 725, source: "web_railyatri" },
      ] },
      { trainNumber: "14631", trainName: "DDN ASR EXPRESS", classes: [
        { classCode: "SL", code: "SL", status: "WAITLIST", seats: null, rac: null, waitlist: 37, fare: 150, source: "web_railyatri" },
        { classCode: "3A", code: "3A", status: "NOT_AVAILABLE", seats: null, rac: null, waitlist: null, fare: null, source: "web_railyatri" },
      ] },
    ];
    (globalThis as unknown as { fetch: unknown }).fetch = vi.fn(async () => ({ ok: true, json: async () => ({ trains: board }) }));
    const { container } = render(
      <SeatFinder from="AAAV" to="BBBV" date="2026-09-25" rows={manyTrains.slice(0, 2)} intent={intent({ confirmedOnly: true })} onChip={() => {}} />,
    );
    await waitFor(() => expect(screen.getByText("AVL 84")).toBeTruthy());
    /* heading + us train ke block me SL(WAITLIST) aur 3A(N-A) dono halki chips */
    expect(screen.getByText(/in trains me koi AVAILABLE \/ RAC class nahi/)).toBeTruthy();
    const groups = [...container.querySelectorAll(".sf-group")];
    const wlTrain = groups.find((g) => g.textContent?.includes("14631"))!;
    expect(wlTrain.textContent).toContain("WL 37");
    expect(wlTrain.textContent).toContain("N/A");
    const off = [...wlTrain.querySelectorAll(".sf-cchip")];
    expect(off.length).toBe(2);
    expect(off.every((c) => c.classList.contains("off"))).toBe(true); /* saari halki — seat nahi maani jaati */
    /* seat wali train ke block me bhi uski saari classes (2A rangdar) */
    const seatTrain = groups.find((g) => g.textContent?.includes("14719"))!;
    expect([...seatTrain.querySelectorAll(".sf-cchip:not(.off)")].length).toBe(1);
  });
});
