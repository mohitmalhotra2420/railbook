/* ══ INTELLIGENCE regression (user issue 2026-09-06, screenshot) ══════
 * "esko intelligent banao kyunki user kuch bhi pooch sakta hai — any
 * questions related to trains and railway" + web search fallback.
 * Screenshot ke 4 bugs:
 *   1. "12014 vs 12054 kon si better" → flat "data nahi mila" (compare hi nahi)
 *   2. "kon kon se 11 stops hai" → "Kahan se jana hai?" (journey slots!)
 *   3. "jaana nhi hai sirf details chahiye" → statement ko station samjha
 *   4. "poora timetable do" → sirf "11 stops" count, list kabhi nahi           */
import { describe, it, expect, beforeEach, afterEach } from "vitest";
import { runAgent } from "../server/agent/run";
import { executeTool } from "../server/agent/tools";
import { classifyFollowUp, isQuestionPhraseNotTrainName } from "../server/agent/context";
import { understand } from "../server/understand/legacy-nlu";
import { setAgenticNvidiaFetch, executeApprovedTool } from "../server/agent/agentic";
import { setRailcoreFetch } from "../server/railway/railcore";
import { setWebFetch } from "../server/agent/websearch";
import { setLlmFetch } from "../server/understand/llm";
import { parseRailEnquiryLive } from "../server/railway/webscrape";

function jsonResponse(status: number, body: unknown): Response {
  return new Response(JSON.stringify(body), { status, headers: { "content-type": "application/json" } });
}

setAgenticNvidiaFetch(async () => {
  throw new Error("model unavailable — deterministic path");
});

/* RailCore mock: 12014 (8 stops, 4h55m) + 12054 (11 stops, 5h15m) */
function railcoreMock(): void {
  setRailcoreFetch(async (input) => {
    const url = new URL(String(input));
    const p = url.pathname;
    if (p.endsWith("/stations/search")) {
      return jsonResponse(200, { success: true, data: { results: [] } });
    }
    const sched = p.match(/\/trains\/(\d+)\/schedule$/);
    if (sched) {
      const num = sched[1];
      if (num === "12014") {
        return jsonResponse(200, {
          success: true,
          data: {
            train_number: "12014",
            train_name: "AMRITSAR SHATABDI",
            running_days: ["MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"],
            classes: ["CC", "EC"],
            total_duration_minutes: 295,
            stops: [
              { station_code: "ASR", station_name: "AMRITSAR JN", arrival_time: null, departure_time: "17:45", day: 1 },
              { station_code: "LDH", station_name: "LUDHIANA JN", arrival_time: "19:33", departure_time: "19:35", day: 1 },
              { station_code: "UMB", station_name: "AMBALA CANT", arrival_time: "20:55", departure_time: "20:57", day: 1 },
              { station_code: "NDLS", station_name: "NEW DELHI", arrival_time: "22:40", departure_time: null, day: 1 },
            ],
          },
        });
      }
      if (num === "12054") {
        return jsonResponse(200, {
          success: true,
          data: {
            train_number: "12054",
            train_name: "JAN SHATABDI EXPRESS",
            running_days: ["MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"],
            classes: ["2S", "CC"],
            total_duration_minutes: 315,
            stops: [
              { station_code: "ASR", station_name: "AMRITSAR JN", arrival_time: null, departure_time: "06:15", day: 1 },
              { station_code: "LDH", station_name: "LUDHIANA JN", arrival_time: "07:58", departure_time: "08:00", day: 1 },
              { station_code: "UMB", station_name: "AMBALA CANT", arrival_time: "09:20", departure_time: "09:22", day: 1 },
              { station_code: "HW", station_name: "HARIDWAR JN", arrival_time: "11:30", departure_time: null, day: 1 },
            ],
          },
        });
      }
      return jsonResponse(200, { success: true, data: { train_number: num, train_name: `TRAIN ${num}`, running_days: ["MON"], stops: [] } });
    }
    return jsonResponse(404, { success: false, error: { message: "unknown endpoint" } });
  });
}

beforeEach(() => {
  process.env.RAILWAY_PROVIDER = "railcore";
  process.env.RAILCORE_API_KEY = "rk_live_test_secret";
});
afterEach(() => {
  setRailcoreFetch(null);
  setWebFetch(null);
  process.env.RAILWAY_PROVIDER = "mock";
  process.env.RAILCORE_API_KEY = "";
});

describe("BUG 1: do trains compare — honest data-based verdict", () => {
  it("NLU: '12014 and 12054 mein se kon si better' → COMPARE_TRAINS + dono numbers", () => {
    const r = understand("Mujhe 12014 and 12054 mein se btao kon si better hai");
    expect(r.intent).toBe("COMPARE_TRAINS");
    expect(r.compareNumbers).toEqual(["12014", "12054"]);
  });

  it("deterministic compare: dono ka data + verdict + route-alag note", async () => {
    railcoreMock();
    const r = await runAgent({ text: "Mujhe 12014 and 12054 mein se btao kon si better hai", now: "2026-09-06T00:03:00+05:30" });
    const reply = String(r.reply ?? "");
    expect(reply, reply).toMatch(/12014/);
    expect(reply, reply).toMatch(/12054/);
    expect(reply, reply).toMatch(/12014.*better|better.*12014|Time mein 12014/); // 295 < 315
    expect(reply, reply).toMatch(/route alag/i); // NDLS vs HW
  });

  it("ek train missing: doosre ka data + kaunsa nahi mila (cancel nahi)", async () => {
    railcoreMock();
    const r = await runAgent({ text: "12951 aur 12014 mein se konsi better hai", now: "2026-09-06T00:03:00+05:30" });
    const reply = String(r.reply ?? "");
    expect(reply, reply).toMatch(/12014/);
    expect(reply, reply).toMatch(/12951 ki timetable nahi mil paayi/);
  });
});

describe("BUG 2+3: stops follow-up — journey slots NAHI", () => {
  it("classifyFollowUp: stops/route/har-stop patterns → timetable", () => {
    expect(classifyFollowUp("Kon kon se 11 stops hai")).toBe("timetable");
    expect(classifyFollowUp("har stop ka naam btao")).toBe("timetable");
    expect(classifyFollowUp("poora timetable do")).toBe("timetable");
    expect(classifyFollowUp("mujhe jaana nhi hai sirf 11 stops ki details chahiye")).toBe("timetable");
    expect(classifyFollowUp("ye train kahan kahan rukti hai")).toBe("timetable");
  });
});

describe("BUG 4: poora timetable = stops LIST (sirf count nahi)", () => {
  it("executeTool getTimetable: summary mein 'Route:' + har stop naam+time", async () => {
    railcoreMock();
    const r = await executeTool("getTimetable", { trainNumber: "12054" });
    expect(r.ok).toBe(true);
    expect(r.summary).toMatch(/Route: 1\. ASR /);
    expect(r.summary).toMatch(/LDH/);
    expect(r.summary).toMatch(/HW/);
    expect(r.summary).toMatch(/arr 11:30/);
  });

  it("runAgent: '12054 ka poora timetable do' → reply mein stops list", async () => {
    railcoreMock();
    const r = await runAgent({ text: "12054 ka poora timetable do", now: "2026-09-06T00:03:00+05:30" });
    const reply = String(r.reply ?? "");
    expect(reply, reply).toMatch(/Route: 1\. ASR/);
    expect(reply, reply).not.toMatch(/Kahan se jana hai/);
  });
});

describe("WEB SEARCH (last-resort fallback, user request 2026-09-06)", () => {
  it("WEB_SEARCH tool: results laata hai, 'web' source label ke saath", async () => {
    setWebFetch(async (url: any) => {
      if (String(url).includes("api.duckduckgo.com")) {
        return jsonResponse(200, {
          AbstractText: "Vande Bharat Express is a semi-high speed train service operated by Indian Railways.",
          AbstractURL: "https://en.wikipedia.org/wiki/Vande_Bharat_Express",
          Heading: "Vande Bharat Express",
        });
      }
      if (String(url).includes("wikipedia.org")) {
        return jsonResponse(200, { query: { search: [] } });
      }
      return jsonResponse(404, {});
    });
    const r = await executeApprovedTool("WEB_SEARCH", { query: "vande bharat express" });
    expect(r.ok).toBe(true);
    expect(r.source).toBe("web");
    expect(r.summary).toMatch(/UNVERIFIED/i);
    const data = r.data as { results: { title: string; snippet: string }[]; note?: string };
    expect(data.results[0].title).toMatch(/Vande Bharat/i);
    expect(data.note).toMatch(/web/i);
  });

  it("web se kuch na mile → honest fail (invent nahi)", async () => {
    setWebFetch(async () => jsonResponse(200, { query: { search: [] } }));
    const r = await executeApprovedTool("WEB_SEARCH", { query: "xyz unknown train" });
    expect(r.ok).toBe(false);
    expect(r.summary).toMatch(/kuch nahi mila/);
  });
});

/* ══ Screenshot 2026-09-06 fixes: general-fact questions + "kahan se kahan" ══ */
describe("GENERAL-FACT sawaal (screenshot 2026-09-06): flat denial nahi, WEB se jawab", () => {
  it("classifyFollowUp: 'kahan se kahan jaati hai' → timetable (route)", () => {
    expect(classifyFollowUp("Kahan se kahan jaati hai")).toBe("timetable");
    expect(classifyFollowUp("kahan se kahan jaati")).toBe("timetable");
    expect(classifyFollowUp("ye train kaha se kaha jaati hai")).toBe("timetable");
    expect(classifyFollowUp("कहां से कहां जाती है")).toBe("timetable");
  });

  it("runAgent: '12014 ki top speed' → web se jawab (flat denial NAHI)", async () => {
    railcoreMock();
    setWebFetch(async (url: any) => {
      const u = String(url);
      if (u.includes("api.duckduckgo.com")) {
        return jsonResponse(200, {
          AbstractText: "Amritsar Shatabdi operates at a maximum speed of 150 km/h.",
          AbstractURL: "https://en.wikipedia.org/wiki/Amritsar_Shatabdi",
          Heading: "Amritsar Shatabdi",
        });
      }
      if (u.includes("wikipedia.org")) return jsonResponse(200, { query: { search: [] } });
      return jsonResponse(404, {});
    });
    const r = await runAgent({ text: "12014 ki top speed kitni hai", now: "2026-09-06T00:03:00+05:30" });
    expect(String(r.reply)).toMatch(/web se mila|Web se mila/i);
    expect(String(r.reply)).toMatch(/150 km\/h|wikipedia|Source/i);
    expect(String(r.reply)).not.toMatch(/available nahi|evidence mein nahi/i);
  });

  it("runAgent: 'vande bharat ki top speed' → TRAIN_NAME hijack NAHI (kaunsi? nahi)", async () => {
    setWebFetch(async (url: any) => {
      const u = String(url);
      if (u.includes("api.duckduckgo.com")) {
        return jsonResponse(200, {
          AbstractText: "Vande Bharat trains have a maximum operating speed of 160 km/h.",
          AbstractURL: "https://en.wikipedia.org/wiki/Vande_Bharat_Express",
          Heading: "Vande Bharat Express",
        });
      }
      if (u.includes("wikipedia.org")) return jsonResponse(200, { query: { search: [] } });
      return jsonResponse(404, {});
    });
    const r = await runAgent({ text: "vande bharat ki top speed kya hai", now: "2026-09-06T00:03:00+05:30" });
    expect(String(r.reply)).toMatch(/web se mila|Web se mila|160 km\/h/i);
    expect(String(r.reply)).not.toMatch(/kaunsi|10 trains|kon si/i);
    expect(String(r.reply)).not.toMatch(/available nahi|evidence mein nahi/i);
  });

  it("runAgent follow-up: 'kahan se kahan jaati hai' → pichhli train ka route", async () => {
    railcoreMock();
    setWebFetch(null);
    const first = await runAgent({ text: "12054 ka poora timetable do", now: "2026-09-06T00:03:00+05:30" });
    expect(String(first.reply)).toMatch(/Route: 1\. ASR/);
    const second = await runAgent({ text: "Kahan se kahan jaati hai", context: first.context as never, known: {}, now: "2026-09-06T00:04:00+05:30" });
    expect(String(second.reply)).toMatch(/ASR|Route/i);
    expect(String(second.reply)).not.toMatch(/evidence mein nahi/i);
  });
});

/* BUG-fix 2026-09-06 (live e2e pakda): "kon kon se stops hai" par model ne
 * TRAIN_NAME_SEARCH("kon kon") karke KONKAN KANYA dhoondh li thi —
 * question-words train naam nahi hote. */
describe("TRAIN_NAME_SEARCH question-word guard", () => {
  it("'kon kon se stops' jaisi phrase par train search fail (naam nahi hai)", async () => {
    setWebFetch(null);
    const r = await executeApprovedTool("TRAIN_NAME_SEARCH", { query: "kon kon se stops hai" });
    expect(r.ok).toBe(false);
    expect(r.summary).toMatch(/train ka naam nahi lagta/i);
  });
});

/* Guard-safety: real train naam "stops" word ke saath block NAHI hona chahiye */
describe("question-phrase guard: naam vs question", () => {
  it("'shane punjab ki stops' = naam (guard pass)", () => {
    expect(isQuestionPhraseNotTrainName("shane punjab ki stops batao")).toBe(false);
    expect(isQuestionPhraseNotTrainName("shane punjab")).toBe(false);
  });
  it("'kon kon se stops hai' = question (guard block)", () => {
    expect(isQuestionPhraseNotTrainName("kon kon se stops hai")).toBe(true);
    expect(isQuestionPhraseNotTrainName("poora timetable do")).toBe(true);
    expect(isQuestionPhraseNotTrainName("mujhe jaana nhi hai sirf stops ki details chahiye")).toBe(true);
  });
  it("runAgent follow-up: 'kon kon se stops hai' → pichhli train ki list (KONKAN nahi)", async () => {
    railcoreMock();
    const first = await runAgent({ text: "12054 ka poora timetable do", now: "2026-09-06T00:03:00+05:30" });
    expect(String(first.reply)).toMatch(/Route: 1\. ASR/);
    const second = await runAgent({ text: "Kon kon se stops hai", context: first.context as never, known: {}, now: "2026-09-06T00:04:00+05:30" });
    const reply = String(second.reply ?? "");
    expect(reply, reply).not.toMatch(/KONKAN/i);
    expect(reply, reply).toMatch(/12054|Route|stops/i);
  });
});

/* ══ SCREENSHOT REGRESSION #2 (2026-09-06, Screenshot_20260906-115134) ══════
 * Bug (b): "12054 ki seat availability?" — train context mein tha, phir bhi
 *          "Train, date, stations aur class chahiye" (sab maanga). Ab sirf
 *          class poochna chahiye (date aaj default, stations auto-route).
 * Bug (c): "Date aaj ki ludhiana se hw ki" — NLU ne naya SEARCH_TRAIN banaya
 *          + "hw" (Haridwar) 2-letter code resolve nahi hua → "Kahan jaana
 *          hai?". Ab: hw→HW resolve + availability slot-RESUME. */

function railcoreAvailMock(): void {
  setRailcoreFetch(async (input) => {
    const url = new URL(String(input));
    const p = url.pathname;
    if (p.endsWith("/stations/search")) {
      return jsonResponse(200, { success: true, data: { results: [] } });
    }
    const sched = p.match(/\/trains\/(\d+)\/schedule$/);
    if (sched && sched[1] === "12054") {
      return jsonResponse(200, {
        success: true,
        data: {
          train_number: "12054",
          train_name: "JAN SHATABDI EXPRESS",
          running_days: ["MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"],
          classes: ["2S", "CC"],
          total_duration_minutes: 315,
          stops: [
            { station_code: "ASR", station_name: "AMRITSAR JN", arrival_time: null, departure_time: "06:15", day: 1 },
            { station_code: "LDH", station_name: "LUDHIANA JN", arrival_time: "07:58", departure_time: "08:00", day: 1 },
            { station_code: "HW", station_name: "HARIDWAR JN", arrival_time: "11:30", departure_time: null, day: 1 },
          ],
        },
      });
    }
    if (p.endsWith("/availability/seats")) {
      const from = url.searchParams.get("from");
      const to = url.searchParams.get("to");
      if (from === "LDH" && to === "HW") {
        /* RailCore real behavior: intermediate segment = NOT_FOUND */
        return jsonResponse(404, { success: false, error: { code: "NOT_FOUND", message: "Resource not found" } });
      }
      return jsonResponse(200, {
        success: true,
        data: {
          train_number: url.searchParams.get("train_number"),
          from_station_code: from,
          to_station_code: to,
          journey_date: url.searchParams.get("date"),
          quota: "GN",
          classes: [
            { class_code: "CC", status: "AVAILABLE", availability_text: "AVAILABLE 112", total_fare: 650 },
          ],
        },
      });
    }
    return jsonResponse(404, { success: false, error: { message: "unknown endpoint" } });
  });
}

describe("SCREENSHOT #2 (2026-09-06): availability UX + hw-code + slot-resume", () => {
  it("'ludhiana se hw ki' — 2-letter station code HW resolve hota hai", () => {
    const r = understand("ludhiana se hw ki train", { now: new Date("2026-09-06T11:51:00+05:30"), lastAsked: null, known: {} });
    expect(r.from?.code).toBe("LDH");
    expect(r.to?.code).toBe("HW");
  });

  /* Round-43 (27 Sep 2026, user screenshot): khaas train ke seat sawaal par poora route-board nahi —
   * us train ka DATE-WISE class status (ChatGPT jaisa). Pehle test "sirf class poochho" maangta tha;
   * ab user ki acceptance date-wise clean answer hai, isliye expectation update. */
  it("bug (b): '12054 ki seat availability?' — usi train ka date-wise class status (poora board nahi)", async () => {
    railcoreAvailMock();
    const r = await runAgent({ text: "12054 ki seat availability?", now: "2026-09-06T11:52:00+05:30" });
    const reply = String(r.reply ?? "");
    expect(reply, reply).toMatch(/12054/);
    expect(reply, reply).toMatch(/seat availability:/i);
    expect(reply, reply).toMatch(/AVAILABLE/);
    expect(reply, reply).not.toMatch(/Train, date, stations aur class chahiye/i);
  });

  it("bug (c): 'Date aaj ki ludhiana se hw ki' — availability RESUME, 'Kahan jaana hai?' nahi", async () => {
    railcoreAvailMock();
    const t2 = await runAgent({ text: "12054 ki seat availability?", now: "2026-09-06T11:52:00+05:30" });
    const t3 = await runAgent({
      text: "Date aaj ki ludhiana se hw ki",
      context: t2.context as never,
      known: {},
      now: "2026-09-06T11:53:00+05:30",
    });
    const reply = String(t3.reply ?? "");
    expect(reply, reply).toMatch(/12054/);
    expect(reply, reply).toMatch(/seat availability:/i);
    expect(reply, reply).not.toMatch(/Kahan jaana|station bataiye/i);
    expect(t3.context?.origin?.code).toBe("LDH");
    expect(t3.context?.destination?.code).toBe("HW");
  });

  /* Round-43c: user live par "aaj ki" follow-up deta hai — us din 12054 CANCELLED hota hai. Pehle ye
   * deterministic handler se fall-through karke route-board/agentic par chala jaata tha (47s, ghair
   * mutaliq jawab). Ab: usi train ka date-wise jawab + agla din bhi (ChatGPT jaisa). */
  it("T5 'aaj ki' — single-train resume: khali date par agla din bhi (route board nahi)", async () => {
    setRailcoreFetch(async (input) => {
      const url = input instanceof URL ? input : new URL(String(input));
      const p = url.pathname;
      const sched = p.match(/\/trains\/(\d+)\/schedule$/);
      if (sched && sched[1] === "12054") {
        return jsonResponse(200, {
          success: true,
          data: {
            train_number: "12054",
            train_name: "JAN SHATABDI EXPRESS",
            running_days: ["MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"],
            classes: ["2S", "CC"],
            total_duration_minutes: 315,
            stops: [
              { station_code: "ASR", station_name: "AMRITSAR JN", arrival_time: null, departure_time: "06:15", day: 1 },
              { station_code: "HW", station_name: "HARIDWAR JN", arrival_time: "11:30", departure_time: null, day: 1 },
            ],
          },
        });
      }
      if (p.endsWith("/availability/seats")) {
        const date = url.searchParams.get("date");
        const cancelled = date === "2026-09-06";
        return jsonResponse(200, {
          success: true,
          data: {
            train_number: "12054",
            from_station_code: "ASR",
            to_station_code: "HW",
            journey_date: date,
            quota: "GN",
            classes: cancelled
              ? [{ class_code: "CC", status: "NOT_AVAILABLE", availability_text: "NOT AVAILABLE" }]
              : [{ class_code: "CC", status: "AVAILABLE", available_count: 294, availability_text: "AVAILABLE 294", total_fare: 205 }],
          },
        });
      }
      return jsonResponse(404, { success: false, error: { message: "unknown endpoint" } });
    });
    const t2 = await runAgent({ text: "12054 ki seat availability btana", now: "2026-09-06T11:52:00+05:30" });
    const t3 = await runAgent({ text: "aaj ki", context: t2.context as never, known: {}, now: "2026-09-06T11:53:00+05:30" });
    const reply = String(t3.reply ?? "");
    expect(reply, reply).toMatch(/12054/);
    /* Pahla din khali (data nahi) → handler agla din bhi maangta hai; dono date-wise lines aati hain. */
    expect(reply, reply).toMatch(/06 Sep \(aaj\):/);
    expect(reply, reply).toMatch(/07 Sep \(kal\): .*AVAILABLE 294/);
    expect(reply, reply).not.toMatch(/₹0/);
    expect(reply, reply).not.toMatch(/kitne passengers/i);
    expect(reply, reply).not.toMatch(/Kahan jaana|station bataiye/i);
    expect(t3.context?.selectedTrainNumber).toBe("12054");
  });

  it("T4 'CC' — availability aati hai + LDH→HW NOT_FOUND par ASR→HW segment-fallback label", async () => {
    railcoreAvailMock();
    const t2 = await runAgent({ text: "12054 ki seat availability?", now: "2026-09-06T11:52:00+05:30" });
    const t3 = await runAgent({
      text: "Date aaj ki ludhiana se hw ki",
      context: t2.context as never,
      known: {},
      now: "2026-09-06T11:53:00+05:30",
    });
    const t4 = await runAgent({ text: "CC", context: t3.context as never, known: {}, now: "2026-09-06T11:54:00+05:30" });
    const reply = String(t4.reply ?? "");
    /* Round-43: user ka apna segment (LDH→HW) hi dikhta hai, class-filter ke saath — provider se usi
     * segment ka data maanga jaata hai (pehle ASR→HW fallback label + "segment ka direct data nahi"). */
    expect(reply, reply).toMatch(/12054/);
    expect(reply, reply).toMatch(/LDH → HW/);
    expect(reply, reply).toMatch(/CC AVAILABLE/i);
    expect(reply, reply).not.toMatch(/Kahan jaana|station bataiye/i);
  });
});

/* ══ SCREENSHOT REGRESSION #3 (2026-09-06, Screenshot_20260906-165721) ══════
 * "12054 ki top speed btana" → (1) agentic ne GET_TIMETABLE chala diya
 * (timetable dikha, speed ka jawab nahi); (2) web-search se pehla result
 * "List of production car speed records" (Wikipedia) — bilkul irrelevant —
 * unfiltered chala gaya; (3) web timeout par reply EMPTY — client fallthrough
 * "Kahan se kahan jaana hai?" dikhata tha. */

describe("SCREENSHOT #3 (2026-09-06): top speed — tool-block + irrelevant-web-filter + never-empty", () => {
  it("irrelevant web results (car speed records) reject — honest jawab, car-wala NAHI", async () => {
    railcoreMock();
    setWebFetch(async (url: any) => {
      const u = String(url);
      if (u.includes("api.duckduckgo.com")) {
        return jsonResponse(200, {
          AbstractText: "",
          AbstractURL: "",
          Heading: "",
        });
      }
      if (u.includes("wikipedia.org")) {
        return jsonResponse(200, {
          query: {
            search: [
              {
                title: "List of production car speed records",
                snippet:
                  "This is a list of the world's record-breaking top speeds achieved by street-legal production cars (as opposed to concept cars or modified cars).",
                url: "https://en.wikipedia.org/wiki/List_of_production_car_speed_records",
              },
            ],
          },
        });
      }
      return jsonResponse(404, {});
    });
    const r = await runAgent({ text: "12054 ki top speed btana", now: "2026-09-06T16:57:00+05:30" });
    const reply = String(r.reply ?? "");
    expect(reply, "reply kabhi empty nahi").toMatch(/.+/);
    expect(reply, reply).not.toMatch(/production car|street-legal/i);
    expect(reply, reply).toMatch(/nahi mil paya|guess nahi/i);
  });

  it("web timeout / 0 results par EMPTY nahi — honest denial", async () => {
    railcoreMock();
    setWebFetch(async () => {
      throw new Error("network timeout");
    });
    const r = await runAgent({ text: "12054 ki top speed btana", now: "2026-09-06T16:57:00+05:30" });
    const reply = String(r.reply ?? "");
    expect(reply, "reply kabhi empty nahi").toMatch(/.+/);
    expect(reply, reply).toMatch(/nahi mil paya/i);
  });

  it("complaint follow-up ('Maine to top speed poochi hai lekin') par 'Kahan se kahan jaana hai?' NAHI", async () => {
    railcoreMock();
    setWebFetch(async () => {
      throw new Error("network timeout");
    });
    const t1 = await runAgent({ text: "12054 ki top speed btana", now: "2026-09-06T16:57:00+05:30" });
    const t2 = await runAgent({
      text: "Maine to top speed poochi hai lekin",
      context: t1.context as never,
      known: {},
      now: "2026-09-06T16:58:00+05:30",
    });
    const reply = String(t2.reply ?? "");
    expect(reply, "reply kabhi empty nahi").toMatch(/.+/);
    expect(reply, reply).not.toMatch(/Kahan se kahan jaana|station bataiye/i);
    expect(reply, reply).toMatch(/top speed|nahi mil paya/i);
  });

  it("railway-relevant web result ab bhi aata hai (filter overreach nahi)", async () => {
    railcoreMock();
    setWebFetch(async (url: any) => {
      const u = String(url);
      if (u.includes("api.duckduckgo.com")) {
        return jsonResponse(200, {
          AbstractText: "The Gatimaan Express is India's fastest train with a top speed of 160 km/h.",
          AbstractURL: "https://en.wikipedia.org/wiki/Gatimaan_Express",
          Heading: "Gatimaan Express",
        });
      }
      if (u.includes("wikipedia.org")) return jsonResponse(200, { query: { search: [] } });
      return jsonResponse(404, {});
    });
    const r = await runAgent({ text: "gatimaan ki top speed kitni hai", now: "2026-09-06T16:57:00+05:30" });
    expect(String(r.reply)).toMatch(/160 km\/h/);
  });
});

/* ══ CHATGPT-JAISA SOURCE-SCRAPE (user request 2026-09-06: "jo sites ChatGPT
 * use karta hai wahi — question ke according khud scrape karo"). Train ka
 * Wikipedia page (e.g. "Haridwar–Amritsar Jan Shatabdi Express") — question-
 * relevant paragraph, number-verified (galat Una-Link page reject). */

import { findWikipediaPage } from "../server/agent/websearch";

describe("ChatGPT-jaisa train-page scrape (Wikipedia page, number-verified)", () => {
  it("findWikipediaPage: mustInclude galat pehli hit ko reject karke sahi page deta hai", async () => {
    setWebFetch(async (url: any) => {
      const u = String(url);
      if (u.includes("srsearch=Hw+Janshatabdi+12054") || u.includes("srsearch=Hw%20Janshatabdi%2012054") || u.includes("srsearch=")) {
        return jsonResponse(200, {
          query: {
            search: [
              { title: "Haridwar–Una Link Janshatabdi Express" },
              { title: "Haridwar–Amritsar Jan Shatabdi Express" },
            ],
          },
        });
      }
      if (u.includes("titles=Haridwar")) {
        const isUna = u.includes("Una");
        return jsonResponse(200, {
          query: {
            pages: {
              p1: {
                title: isUna ? "Haridwar–Una Link Janshatabdi Express" : "Haridwar–Amritsar Jan Shatabdi Express",
                extract: isUna ? "The Una Link train runs elsewhere. " + "x".repeat(200) : "The 12054/12053 Amritsar–Haridwar Jan Shatabdi Express covers 407 km with average speed above 55 km/h as per Indian Railways rules. " + "y".repeat(150),
              },
            },
          },
        });
      }
      return jsonResponse(404, {});
    });
    const p = await findWikipediaPage("Hw Janshatabdi 12054", "12054");
    expect(p).not.toBeNull();
    expect(p!.title).toBe("Haridwar–Amritsar Jan Shatabdi Express");
    expect(p!.extract).toContain("12054");
  });

  it("'12054 ki top speed' par train-page ka speed-paragraph (car records nahi)", async () => {
    railcoreMock();
    setWebFetch(async (url: any) => {
      const u = String(url);
      if (u.includes("srsearch=")) {
        return jsonResponse(200, { query: { search: [{ title: "Haridwar–Amritsar Jan Shatabdi Express" }] } });
      }
      if (u.includes("titles=")) {
        return jsonResponse(200, {
          query: {
            pages: {
              p1: {
                title: "Haridwar–Amritsar Jan Shatabdi Express",
                extract:
                  "The 12054/12053 Amritsar–Haridwar Jan Shatabdi Express is a Superfast Express train.\n\nService\nIt covers the distance of 407 kilometres at an average speed above 55 km/h, so its fare includes a Superfast surcharge.",
              },
            },
          },
        });
      }
      return jsonResponse(404, {});
    });
    const r = await runAgent({ text: "12054 ki top speed btana", now: "2026-09-06T17:05:00+05:30" });
    const reply = String(r.reply ?? "");
    expect(reply, reply).toMatch(/Haridwar–Amritsar Jan Shatabdi Express/);
    expect(reply, reply).toMatch(/407 kilomet|55 km\/h/i);
    expect(reply, reply).not.toMatch(/production car/i);
    expect(reply, reply).toMatch(/web-scrape/i);
  });
});

/* ══ SCREENSHOT REGRESSION #4 (2026-09-06, Screenshot_20260906-181539) ══════
 * "Sleeper class kya hota hai train mein" → "web se nahi mil paya" (web
 * query bigdi thi) + "2s class kya hoti hai" → booking slot-ask ("Kahan se
 * jaana hai?"). User: "AI ke paas har cheez ka answer ho — railway ka kuch
 * bhi pooch sakta hai". */

describe("SCREENSHOT #4 (2026-09-06): railway-knowledge KB + class-questions booking nahi", () => {
  it("'Sleeper class kya hota hai train mein' → KB se instant jawab (web fail nahi)", async () => {
    setWebFetch(async () => {
      throw new Error("network timeout");
    });
    const r = await runAgent({ text: "Sleeper class kya hota hai train mein", now: "2026-09-06T18:15:00+05:30" });
    const reply = String(r.reply ?? "");
    expect(reply, reply).toMatch(/Sleeper class \(SL\)/i);
    expect(reply, reply).toMatch(/non-AC sleeper coach/i);
    expect(reply, reply).not.toMatch(/nahi mil paya/i);
  });

  it("'2s class kya hoti hai' → KB jawab, 'Kahan se jaana hai?' NAHI (booking-slot galti nahi)", async () => {
    setWebFetch(async () => {
      throw new Error("network timeout");
    });
    const r = await runAgent({ text: "2s class kya hoti hai", now: "2026-09-06T18:15:00+05:30" });
    const reply = String(r.reply ?? "");
    expect(reply, reply).toMatch(/Second Sitting/i);
    expect(reply, reply).not.toMatch(/Kahan se jaana|Departure station bataiye/i);
  });

  it("tatkal/rac/gnwl/chart concepts — KB se turant", async () => {
    setWebFetch(async () => {
      throw new Error("network timeout");
    });
    for (const [q, re] of [
      ["tatkal quota kya hota hai", /1 din pehle/i],
      ["rac kya hota hai", /Reservation Against Cancellation/i],
      ["gnwl kya hota hai", /GNWL/i],
      ["chart kab banta hai", /Reservation Chart/i],
      ["ac coach mein blanket milti hai kya", /Bedding/i],
    ] as const) {
      const r = await runAgent({ text: q, now: "2026-09-06T18:15:00+05:30" });
      expect(String(r.reply ?? ""), q).toMatch(re);
    }
  });

  it("REAL search ab bhi hota hai — class-question guard overreach nahi", async () => {
    railcoreMock();
    const r = await runAgent({ text: "amritsar se new delhi ki train dikhao", now: "2026-09-06T18:15:00+05:30" });
    const reply = String(r.reply ?? "");
    expect(reply, reply).not.toMatch(/sawaal main theek se samajh nahi/i);
  });

  /* ── prod-fix round (post-deploy verify): 2 aur leaks ── */

  it("'vande bharat kya hoti hai' → KB concept jawab, 10-train clarify list NAHI", async () => {
    setWebFetch(async () => {
      throw new Error("network timeout");
    });
    const r = await runAgent({ text: "vande bharat kya hoti hai", now: "2026-09-06T19:30:00+05:30" });
    const reply = String(r.reply ?? "");
    expect(reply, reply).toMatch(/semi-high-speed|semi high speed/i);
    expect(reply, reply).not.toMatch(/trains mili|kaunsi\?/i);
  });

  it("'engine wap7 ka matlab' → KB se loco jawab (matlab QUESTION_RE mein ab hai)", async () => {
    setWebFetch(async () => {
      throw new Error("network timeout");
    });
    const r = await runAgent({ text: "engine wap7 ka matlab", now: "2026-09-06T19:30:00+05:30" });
    const reply = String(r.reply ?? "");
    expect(reply, reply).toMatch(/WAP-7/i);
    expect(reply, reply).toMatch(/6350 hp/i);
  });
});


/* ══ ROUND-4 (2026-09-06): "Jaise ChatGPT — railway ka KUCHH BHI poocho,
 * API se na mile to web se" — wiki topic-page + table-extract + LLM layer ══ */

describe("ROUND-4: ChatGPT-jaisa universal railway knowledge", () => {
  afterEach(() => {
    setLlmFetch(null);
  });

  /** Wiki mock helper: search→titles, extracts→text, parse→wikitext. */
  function wikiMock(opts: {
    searchHits?: Record<string, string[]>; // srsearch-substring → titles
    extracts?: Record<string, string>; // title → extract
    wikitext?: Record<string, string>; // title → wikitext
    snippets?: Record<string, { title: string; snippet: string }[]>; // for wikipediaLookup (exintro)
  }): void {
    setWebFetch(async (input: any) => {
      const url = String(input);
      if (url.includes("duckduckgo.com")) return jsonResponse(200, {});
      const u = new URL(url);
      if (u.searchParams.get("action") === "parse") {
        const page = u.searchParams.get("page") ?? "";
        const wt = opts.wikitext?.[page];
        if (wt) return jsonResponse(200, { parse: { title: page, wikitext: { "*": wt } } });
        return jsonResponse(200, { parse: { title: page, wikitext: { "*": "" } } });
      }
      if (u.searchParams.get("list") === "search") {
        const q = (u.searchParams.get("srsearch") ?? "").toLowerCase();
        for (const [needle, titles] of Object.entries(opts.searchHits ?? {})) {
          if (q.includes(needle)) return jsonResponse(200, { query: { search: titles.map((t) => ({ title: t })) } });
        }
        return jsonResponse(200, { query: { search: [] } });
      }
      if (u.searchParams.get("prop") === "extracts") {
        const titles = (u.searchParams.get("titles") ?? "").split("|");
        const pages: Record<string, { title: string; extract?: string; fullurl?: string }> = {};
        for (const t of titles) {
          if (u.searchParams.get("exintro") !== null && u.searchParams.get("exintro") !== "1") break;
          const ex = opts.extracts?.[t];
          if (ex) pages[String(Object.keys(pages).length + 1)] = { title: t, extract: ex };
        }
        if (u.searchParams.get("exintro") === "1") {
          // wikipediaLookup path — use snippets map
          const out: Record<string, { title: string; extract?: string }> = {};
          for (const t of titles) {
            for (const [, arr] of Object.entries(opts.snippets ?? {})) {
              const hit = arr.find((x) => x.title === t);
              if (hit) out[String(Object.keys(out).length + 1)] = { title: t, extract: hit.snippet };
            }
          }
          return jsonResponse(200, { query: { pages: out } });
        }
        return jsonResponse(200, { query: { pages } });
      }
      return jsonResponse(404, {});
    });
  }

  it("'sabse lambi train kaunsi hai' → Wikipedia TABLE se top rows (slot-ask nahi)", async () => {
    wikiMock({
      searchHits: { "longest train": ["Longest train services of Indian Railways"] },
      extracts: {
        "Longest train services of Indian Railways":
          "This article lists the longest passenger rail services that are currently scheduled and running directly between two cities. Services that require railcar exchanges, coach changes, shunting or station transfers are not listed here.",
      },
      wikitext: {
        "Longest train services of Indian Railways": [
          '{| class="wikitable sortable"',
          "! No.",
          "! Train name/No.",
          "! Distance",
          "|-",
          "| 1",
          "| 22503/22504 [[Dibrugarh–Kanyakumari Vivek Express|Dibrugarh–Kanyakumari Vivek Superfast Express]]",
          "| 4,154.1&nbsp;km",
          "|-",
          "| 2",
          "| [[Himsagar Express]]",
          "| 3,788.7&nbsp;km",
          "|}",
        ].join("\n"),
      },
    });
    const r = await runAgent({ text: "sabse lambi train kaunsi hai india mein", now: "2026-09-06T20:00:00+05:30" });
    const reply = String(r.reply ?? "");
    expect(reply, reply).toMatch(/Vivek/i);
    expect(reply, reply).toMatch(/4,154/);
    /* Round-39: "sabse lambi train" ab RailBook KB se aata hai (concise Hinglish, top-1 fact —
     * Wikipedia table path bhi maujood hai jab KB me entry na ho). Dono mein se koi bhi honest
     * label chalega. */
    expect(reply, reply).toMatch(/web-scrape ka jawab|general railway knowledge/i);
  });

  it("'sabse tez train' wiki fail → LLM layer (labeled), denial nahi", async () => {
    setWebFetch(async () => jsonResponse(200, { query: { search: [] } }));
    setLlmFetch(async () =>
      jsonResponse(200, {
        choices: [{ message: { content: "Sabse tez train India ki Vande Bharat Express hai — 160 km/h operational speed." } }],
      }),
    );
    const r = await runAgent({ text: "sabse tez train kaunsi hai india mein", now: "2026-09-06T20:00:00+05:30" });
    const reply = String(r.reply ?? "");
    expect(reply, reply).toMatch(/Vande Bharat/i);
    /* Round-40: "sabse tez train" ab KB me hai (Vande Bharat 160 km/h) — KB label bhi honest hai. */
    expect(reply, reply).toMatch(/AI ka general jawab|general railway knowledge/i);
    expect(reply, reply).not.toMatch(/confirm nahi kar paya/i);
    expect(reply, reply).not.toMatch(/Kahan se jaana/i);
  });

  it("KB-miss + web-miss concept ('bifurcation') → LLM layer se jawab", async () => {
    setWebFetch(async () => jsonResponse(200, { query: { search: [] } }));
    setLlmFetch(async () =>
      jsonResponse(200, {
        choices: [{ message: { content: "Bifurcation railway mein ek line ka do alag routes mein baant na hota hai — slip coach isse juda concept hai." } }],
      }),
    );
    const r = await runAgent({ text: "railway mein bifurcation kya hota hai", now: "2026-09-06T20:00:00+05:30" });
    const reply = String(r.reply ?? "");
    expect(reply, reply).toMatch(/Bifurcation/i);
    expect(reply, reply).toMatch(/AI ka general jawab/i);
  });

  it("irrelevant wiki page (Sikhism/Iraq) REJECT — relevance guard", async () => {
    wikiMock({
      searchHits: {
        "rail transport in india": [],
        "first railway line india": ["Sikhism in Iraq"],
      },
      extracts: {
        "Sikhism in Iraq":
          "Sikhism has a historical presence in Iraq because of the founder Guru Nanak's travels throughout the region in the sixteenth century.",
      },
    });
    setLlmFetch(async () =>
      jsonResponse(200, {
        choices: [{ message: { content: "India ki pehli railway line 16 April 1853 ko Bombay (Mumbai) se Thane tak khuli thi — 34 km." } }],
      }),
    );
    const r = await runAgent({ text: "first railway line india mein kahan bani thi", now: "2026-09-06T20:00:00+05:30" });
    const reply = String(r.reply ?? "");
    expect(reply, reply).not.toMatch(/Sikhism|Iraq/i);
    expect(reply, reply).toMatch(/1853|AI ka general jawab/i);
  });

  it("ROUND-5: general web SCRAPE — Bing result → page text → labeled answer", async () => {
    /* Bing se railway result + uska page-scrape — dono mock. Question aisa
     * jo KB miss kare ("password reset" KB/wiki mein nahi). */
    setWebFetch(async (input: any) => {
      const url = String(input);
      if (url.includes("bing.com/search")) {
        const html = [
          '<li class="b_algo">',
          '<h2><a href="https://contents.irctc.co.in/en/faq.html">How to reset IRCTC password</a></h2>',
          '<p>IRCTC password reset steps: forgot password link on the login page.</p>',
          "</li>",
        ].join("");
        /* HTML mock — jsonResponse JSON.stringify kar deta (escaped quotes
         * regex tod dete hain), isliye raw Response. */
        return new Response(html, { status: 200 });
      }
      if (url.includes("contents.irctc.co.in")) {
        const html =
          "<html><body><p>To reset your IRCTC password, open the IRCTC login page and click the Forgot Password link, then enter your user ID and the OTP sent to your registered mobile number.</p></body></html>";
        return new Response(html, { status: 200 });
      }
      return new Response("{}", { status: 404 });
    });
    const r = await runAgent({ text: "irctc password reset kaise kare", now: "2026-09-06T21:00:00+05:30" });
    const reply = String(r.reply ?? "");
    expect(reply, reply).toMatch(/Web se scrape karke mila \(contents\.irctc\.co\.in\)/i);
    expect(reply, reply).toMatch(/Forgot Password|password reset/i);
    expect(reply, reply).toMatch(/web-scrape ka jawab/i);
  });

  it("'vivek express kitna lamba route' → wiki answer ('Train number chahiye' fail nahi)", async () => {
    wikiMock({
      searchHits: { vivek: ["Vivek Express"] },
      extracts: {
        "Vivek Express":
          "Vivek Express refers to a series of Indian Railways express trains.\n\nThe 22503/22504 Dibrugarh–Kanyakumari Vivek Express covers the longest route in Indian Railways, approximately 4,154 km.",
      },
    });
    const r = await runAgent({ text: "vivek express kitna lamba route cover karta hai", now: "2026-09-06T20:00:00+05:30" });
    const reply = String(r.reply ?? "");
    expect(reply, reply).toMatch(/Vivek/i);
    expect(reply, reply).toMatch(/4,154|longest/i);
    expect(reply, reply).not.toMatch(/Train number chahiye/i);
  });
});

/* ══ ROUND-6 (NTES question): railenquiry.in live-status fallback ══
 * NTES (enquiry.indianrail.gov.in) datacenter IPs par TLS-level drop karta
 * hai — anti-bot evasion nahi karenge. railenquiry.in (SSR mirror,
 * number-only URL) last-resort live fallback hai. */

describe("ROUND-6: railenquiry.in live-status scrape fallback", () => {
  it("parse: +7 Mins Late / RUNNING / Departed — sab fields", () => {
    const html = [
      "<html><head><title>12958 Swrn J Rajdhani Live Train Running Status</title></head><body>",
      "<div>NDLS NEW DELHI SBIB SABARMATI BG</div>",
      "<div>+7 Mins Late</div>",
      "<div>RUNNING · KHALILPUR</div>",
      "<div>Departed from KHALILPUR(KIP) at 21:19 06-Sep</div>",
      "</body></html>",
    ].join("");
    const r = parseRailEnquiryLive(html, "12958", "https://railenquiry.in/runningstatus/12958");
    expect(r, "parsed").not.toBeNull();
    expect(r!.trainName).toBe("Swrn J Rajdhani");
    expect(r!.delayMinutes).toBe(7);
    expect(r!.currentStation).toBe("KHALILPUR");
    expect(r!.status).toMatch(/Departed from KHALILPUR \(KIP\) at 21:19/);
    expect(r!.provider).toBe("web_railenquiry");
  });

  it("parse: On Time + garbage/empty HTML → null ya honest fallback", () => {
    const html =
      "<html><head><title>12054 Hw Janshatabdi Live Train Running Status</title></head><body><div>On Time</div></body></html>";
    const r = parseRailEnquiryLive(html, "12054", "https://x");
    expect(r, "on-time parse").not.toBeNull();
    expect(r!.delayMinutes).toBe(0);
    expect(r!.status).toBe("On time");
    const bad = parseRailEnquiryLive("<html></html>", "12054", "https://x");
    expect(bad, "empty → null").toBeNull();
  });
});
