# RailBook

AI-first railway booking: tell RailBook the journey in Hindi, English, or Hinglish.

**Architecture: AI-driven tool calling.** `POST /api/agent` sends the user's request to **NVIDIA GPT-OSS-20B** (`https://integrate.api.nvidia.com/v1`, `NVIDIA_MODEL`). The MODEL decides which approved tools to call — multi-step, in any order it needs:

```
USER → NVIDIA GPT-OSS-20B (understands request, SELECTS approved tools)
     → SERVER executes each tool call securely (provider keys NEVER reach the model)
     → RailCore PRIMARY → RailKit FALLBACK (every tool result carries `source`)
     → tool result returned to the model → model may chain the next tool
     → final GROUNDED response (train no./₹/seats/delay must exist in tool evidence)
```

Approved tool allowlist (nothing else can ever execute): `SEARCH_TRAINS`, `GET_TRAIN_INFO`, `GET_TIMETABLE`, `TRACK_TRAIN`, `CHECK_AVAILABILITY`, `GET_FARE`, `CHECK_PNR`, `GET_CANCELLED_TRAINS`, `GENERAL_RAILWAY_ANSWER`, `JOURNEY_ANALYZE` (Atlas journey intelligence — fastest/cheapest/earliest/best-value, alternative dates, connections — deterministic engine output the model explains). No arbitrary URLs, no invented tools; args are zod-validated and URL-bearing args are rejected.

If GPT-OSS-20B is missing, times out, errors, or goes ungrounded, the **deterministic NLU + tool-routing fallback** answers instead (architecture preserved). Booking/payment mutations (passengers, fare review, payment, confirm) NEVER reach the model — they stay in the deterministic booking engine, and `confirmBook` is always `false`. Slot extraction for `/api/understand` also runs server-side with the same NVIDIA NIM account. Per-request timeout: `AI_REQUEST_TIMEOUT_MS` (default 7000); agentic turn budget: `AI_AGENTIC_TURN_BUDGET_MS` (default 30000).

Primary UI is a travel concierge (voice + text). The only structured form is passenger details. Backend booking, wallet, and the mock railway provider are unchanged.

## Honest status

The default **production railway provider is RailCore** (`RAILWAY_PROVIDER=railcore`, server-side `RAILCORE_API_KEY`). RailKit stays installed as **fallback**, and is the only source for **PNR** and **cancelled-train list**. RailRadar is not used. NVIDIA still only understands language — it never invents trains, seats, fares, live location, or PNRs. Station lookup uses RailCore `GET /v1/stations/search` with ranking (Kochi first-hit KFX is rejected). Seat/fare numbers are provider snapshots, not a live IRCTC booking counter. Booking confirmation remains a **mock PNR** unless a real booking API exists.

- Demo bookings are labelled **Mock / demo booking**.
- Mock PNRs always start with `MOCK`.
- Nothing is marked confirmed until the provider returns success.
- Coach position/composition RailCore `GET /v1/trains/:number/coach-position` se aati hai (RailCore-only; RailKit isme fallback nahi). Na aaye to UI honestly kehta hai — fake layout kabhi nahi banata.
- Voice/chat bhi coach position samajhta hai: "12014 ki coach position batao" / "coach dikhao" / "12926 की कोच पोजिशन" — TrainBoard par diagram sheet khulti hai, Concierge mein composition ka jawab aata hai.
- Connecting a licensed/authorized railway API later should only require a new adapter under `server/providers/` plus server-side env vars.

This project does **not** scrape IRCTC, call unofficial APIs, or invent production PNRs.

## Deploy on Vercel

```bash
npx vercel login
npx vercel --yes --prod
```

Frontend (`dist`) + `/api/*` Express function dono deploy hote hain. Mock provider default hai — secrets Vercel dashboard pe `RAILWAY_*` se add karo, frontend bundle mein nahi.

Microphone: `Permissions-Policy: microphone=(self)` already set.

## Run

```bash
cp .env.example .env
npm install
npm test
npm run dev
```

- Client: `http://localhost:5173` (proxies `/api` to the server)
- API: `http://localhost:3001`

## Environment

See `.env.example`. Secrets stay on the server:

| Variable | Purpose |
| --- | --- |
| `RAILWAY_PROVIDER` | Default `railcore`. Explicit `railkit` / `mock` / `authorized` override. |
| `RAILCORE_API_KEY` | Server-only RailCore key (never frontend) |
| `RAILKIT_API_KEY` | Server-only RailKit fallback / PNR / cancel-list key (never frontend) |
| `RAILWAY_API_BASE_URL` | Optional licensed-provider stub |
| `RAILWAY_API_KEY` | Server-only licensed-provider key |
| `RAILWAY_API_SECRET` | Server-only licensed-provider secret |
| `WALLET_INITIAL_BALANCE` | Demo wallet opening balance |
| `SERVICE_FEE_INR` | Per-passenger service fee |
| `MOCK_FORCE_FAIL` | Force mock confirmations to fail |
| `NVIDIA_API_KEY` | Server-only NVIDIA NIM key for `/api/understand` |
| `NVIDIA_BASE_URL` | `https://integrate.api.nvidia.com/v1` |
| `NVIDIA_MODEL` | Chat model id (default `openai/gpt-oss-20b`) |
| `AI_REQUEST_TIMEOUT_MS` | NVIDIA request timeout (default 7000, max 20000) |

Add them in **Vercel → Project Settings → Environment Variables** for Production and Preview. Never put keys in the Vite client bundle or git. If `NVIDIA_API_KEY` is unset, `/api/understand` uses deterministic Hindi/English/Hinglish NLU.

Admin catalog (no API key in the browser): `#/admin/models` → **Check NVIDIA models**.

```
User message → POST /api/understand (structured slots)
            → booking state
            → validation → search → class → passengers → fare
            → explicit confirm → booking API
```

The model cannot book. Confirmation and provider calls stay on the backend.

## Architecture

```
server/agent/agentic.ts       AI tool-calling loop (allowlist, grounding, provider routing, repair pass, time budget)
server/agent/run.ts           AI-FIRST runAgent: model picks tools; deterministic NLU/tools = fallback only
server/understand/            Structured AI + fallback NLU (no src/ imports)
server/providers/types.ts     Provider contract
server/providers/mock.ts      Deterministic mock inventory
server/providers/authorized.ts Stub for a licensed provider
server/railway/router.ts      RailCore primary → RailKit fallback routing (`source` on every result)
server/app.ts                 HTTP API (POST /api/agent accepts multi-turn `history`)
src/views/Concierge.tsx       Chat UI: AI-first agent turn with visible tool trace, deterministic booking fallback
src/booking/state.ts          Booking state machine (payment/confirm never model-driven)
```

Multi-turn state: the client sends back `context` (origin/destination/date/passengers) and the last 8 conversation turns as `history`, so "Amritsar se Delhi jaana hai" → "Kis date ko?" → "Saturday" continues without re-asking. The model asks for genuinely missing info instead of silently assuming today's date.

Provider operations: search, availability, fare, create, confirm, retrieve, cancel.

Booking states: `SEARCHING` → `RESULTS_FOUND` → `TRAIN_SELECTED` → `CLASS_SELECTED` → `PASSENGERS_PENDING` → `FARE_REVIEW` → `PAYMENT_PENDING` → `BOOKING_PENDING` → `CONFIRMED` | `FAILED` | `CANCELLED`.

Changing the date, train, or class clears downstream selections so stale cards cannot linger.

## Tests

`npm test` covers search, empty routes, date-change resets, passenger validation, wallet shortfall, mock success/failure, and PNR retrieval.

## Live status of yesterday / earlier runs (Round-16p)

Live status is per **start-date run**. "kal / parson / yesterday / 7 Sep wali
kahan hai" resolves to the *past* run (`parseStatusDate`, opposite of the booking
parser where "kal" = tomorrow). Without a date, if today's run is still idle at
its origin (multi-day trains), the router auto-probes the previous 3 days and
returns the run that is actually moving. Completed runs return their final
status/delay. Replies label the run: `[kal (08 Sep) se chali wali run]`.

## Journey intelligence — RailBook Atlas (Round-17)

`server/journey/engine.ts` is a **deterministic** ranking/recovery engine over
real provider data; the LLM only picks the tool and explains the result.

| Tool / endpoint | What it does | Data source |
| --- | --- | --- |
| `RANK_JOURNEY_OPTIONS` · `POST /api/journey/plan` | Ranks direct + connecting options: `best_overall`, `fastest`, `direct`/`fewest_changes`, `best_availability`, `cheapest`, `earliest`. Stable order, ties by train number. Returns `recovery{differentTrain, partialRoute, connecting, alternativeDates}` when the direct train has no seat. | `searchTrainsRouted`, bounded `routedClassBoard` probe (`JOURNEY_AVAIL_PROBE`, default 4) |
| `FIND_VACANT_SEATS` · `POST /api/journey/vacant` | Class-level AVAILABLE/RAC/WL counts + fare for one train segment. | `routedClassBoard` (RailCore → RailKit → RailRadar → RailYatri scrape) |
| `FIND_PARTIAL_ROUTE_SEATS` · `POST /api/journey/partial` | Same-train split (`origin→X` + `X→destination`) and same-train switch ("seat available after X"). Verifies station order, class, date, running day; probes ≤ `PARTIAL_SPLIT_LIMIT` (3) mid-halts. | timetable + class board |
| `FIND_CONNECTIONS` · `POST /api/journey/connections` | One-change connections via hubs; `layoverMinutes = departureB − arrivalA`; rejected if `< MIN_TRANSFER_MINUTES` (default 30), `> MAX_LAYOVER_MINUTES` (default 360) or negative/next-day. | two routed searches |

Honesty rules baked in: `reliability` is always `null` (no provider gives
punctuality data), `berths`/`berth` are always `null` (no configured provider —
RailCore, RailKit, RailRadar — exposes coach/berth-level or post-chart vacancy;
the engine says so in `capability.note`). The user's date is never changed —
alternative dates are suggestions only. The chat UI renders the plan as a
**BEST OPTION** card (⚡ ⏱ 🚆 💺 ₹) with **OTHER OPTIONS** chips; when the direct
train has no seat it shows "Direct seat nahi mili. Ye alternatives mile:" with
only provider-verified alternatives.

## Round-18 — capability registry, provenance, proactive alternatives, smart train picker

- **Provider capability registry** (`server/providers/capabilities.ts`, `GET /api/capabilities`): per provider (RailCore, RailKit, RailRadar, Indian Rail API, verified web sites, RailBook engine) each internal capability is `available | unavailable | needs_key | derived`. The backend only selects supported capabilities. Berth-level vacancy, post-chart vacancy and reliability scores are `unavailable` everywhere → the UI/LLM says **"Seat recovery data is currently unavailable."** — never a fake coach/berth.
- **Provenance & freshness** (`server/providers/provenance.ts`): dynamic results carry `retrievedAt, source, sourceType, requestDate, travelDate, freshness (live/fresh/recent/stale)`. Stale live data is labelled, never presented as current.
- **Data-conflict resolution**: two sources disagreeing are never blended (10 + 15 ≠ 25). Rule = source priority (RailCore > RailKit > RailRadar > IndianRailAPI > web) + freshness; if a lower-priority source is materially fresher and disagrees, the response says **"Data sources are conflicting right now. Please retry."**
- **Proactive alternatives** (§5/§6): every journey search attaches the deterministic Atlas plan (BEST FOR YOU + YOU MAY ALSO CONSIDER chips: ⚡ Fastest · 💺 Best availability · 💰 Lowest fare · 🚆 Fewest changes · 🔁 Connecting · 📅 Alternative date) — cards only when backed by real data. When a checked train is WL/RAC/low/no-class, `FIND_ALTERNATIVE_TRAINS` (`POST /api/journey/alternatives`) runs automatically: other trains (verified AVAILABLE/RAC), same-train other class, split booking, connecting, alternative dates (suggestion only — origin/destination/date never changed silently).
- **Smart train picker** (§9/§10): `SEARCH_TRAIN_BY_NUMBER` / `SEARCH_TRAIN_BY_NAME` (`GET /api/trains/pick?q=`) — exact number → exact name → normalized/fuzzy partial name (handles erail spellings like "SHTABDI") → route context. Ambiguous names open a **SELECT TRAIN** card list in chat; the user taps to choose. Typing a bare number or a short name in chat shows the picker instantly, before the LLM round-trip.
- No auto-booking: `Confirm & Book` remains the only booking action; payment/wallet/booking stay deterministic.

### Round-18c — gap-fill vs spec
- **§8 alternate boarding/destination station**: `findAlternateStationOptions` / `clusterSiblings` (`server/journey/engine.ts`) probe same-city siblings from `MULTI_STATION_CITIES` (max 2 per side, fastest train availability-verified). Attached as `plan.recovery.alternateStations` only when no good direct option; UI shows "📍 Doosra station, same city — confirm karein" cards; tapping sends an explicit new query — origin/destination are never changed silently.
- **§5 proactive plan on deterministic path**: when the LLM engine is unavailable, `/api/agent` still returns `journey` (BEST FOR YOU + chips) built from the same real search (no extra provider call).
- **§14 live-status freshness**: TRACK_TRAIN attaches `provenance{retrievedAt,source,sourceType,requestDate,travelDate,freshness}`; stale provider updates are labelled "purana update hai" instead of being presented as current.

### Round-18e — user-reported bug: "sidha card open ho jata, alternatives nahi dikhte"
- Root cause: after a journey search the client auto-opened the full-screen TrainBoard (booking continuity) which covered the chat's BEST FOR YOU / YOU MAY ALSO CONSIDER / SELECT TRAIN blocks.
- Fix: no auto-open when the agent reply carries a `journey` / `alternatives` / `trainPicker` block. BEST FOR YOU card now has an explicit **"Sabhi trains · Book →"** CTA (and "Phir bhi sabhi trains dekho / book →" when direct is unavailable) — the board opens only on that tap.
- TrainBoard: tapping a WL / RAC / Not-available / <10-seat class opens a **YOU MAY ALSO CONSIDER** sheet (`POST /api/journey/alternatives` with the cell's verified `knownRow`) — other trains verified AVL/RAC, other classes, split, connecting, alt dates; "Phir bhi … book karo" keeps the explicit user choice.

### Round-18f — real-browser E2E of every Round-18 feature (headless Chromium against the production build)
- Found & fixed: `BlockView` was missing the `onOpenBoard` prop → `ReferenceError` on render → blank reply right after the date (this is what made Round-18 look "not working"); `openBoardFor` was nested inside `handleText`. `scripts/release.sh` now fails on client undefined-name errors (TS2304/TS2552).
- Picker: one card per train number (providers return case/spelling variants). Agent: user-typed station codes (FZR, CSMT…) are used directly — no "FZR ka matlab…?" confirmation.
- Verified in-browser: date asked first → BEST FOR YOU + chips (no board auto-open) → chip list → "Sabhi trains · Book →" opens TrainBoard → WL cell tap opens YOU MAY ALSO CONSIDER sheet; "12014" / "Amritsar Shatabdi" → SELECT TRAIN cards with dep→arr; "12014 mein CC available hai?" asks date; WL query → alternatives card; `/api/capabilities` honest "Seat recovery data is currently unavailable.".

### Round-18g — Muse stays primary; general-question web answers; fare on seat rows
- **Muse duplicate tool calls**: Muse frequently emits the same tool call 2-3× in parallel (e.g. `WEB_SEARCH` ×3 for "India mein longest train journey"); each duplicate cost 5-10 s and blew the turn budget, so GPT-OSS/GLM answered instead. Now identical name+args calls execute once and every `tool_call_id` still receives the tool message → Muse finishes inside budget and remains the primary model.
- **General railway questions** already route to `WEB_SEARCH` (Wikipedia etc.) or the KB — verified live: longest journey (Vivek Express 4,154 km), Vande Bharat speed, Tatkal timings.
- **Fare on RailRadar/IndianRailAPI seat rows**: those APIs return seats without fare (fare 0 → "Fare on select", no 💰 Lowest fare chip). `withFareFilled` adds fare from RailRadar fare API → erail (web), recorded as `fareSource` (seats and fare provenance never merged).

### Round-18g-3 — Muse primary: measured & fixed
- New telemetry: every `/api/agent` response carries `modelFallbacks[{model,reason,ms,round}]` (+ structured log line). Prod showed Muse **timing out** in rounds 2+ (it got only 4–8 s after the first round, while Muse needs 20–35 s per round on NIM), so GPT-OSS/GLM answered.
- Fix: primary model always gets ≥ `AI_PRIMARY_MIN_MS` (25 s on Render) while budget remains; turn budget 120 s, per-call 40 s (Render env updated). Fallback reserve 8 s → 6 s. Muse stays primary; GPT-OSS/GLM only when Muse genuinely fails.

### Round-18h — browser E2E of general questions / Muse / seat+fare web-scrape
- Client bug: "Bharat ki pehli train kab chali thi" never reached the server — `classifyFollowUp` treated "pehli train" as a list pick ("Pehle trains search karni hongi"). Knowledge phrasing (kab/kahan/history/bharat/india/…) now bypasses `train_pick`.
- Verified live in Chromium: longest journey (Muse + Wikipedia), first train 1853 (Muse + Wikipedia), Rajdhani vs Shatabdi (KB+web), 12014 CC seats **with fare** (RailRadar seats + fare fill), and with all API keys removed seats+fare still come from railyatri.in (web) — CC AVL ₹1,125.

### Round-18i — rules questions prefer KB, fact questions prefer web
- Browser E2E: "IRCTC tatkal booking kab shuru hoti hai" got a generic IRCTC Wikipedia paragraph (no timing). `WEB_SEARCH` now checks `RULES_TOPIC_RE` (tatkal/RAC/WL/chart/PNR/refund/luggage/ID/quota/concession…) and answers from the stable KB first (10:00 AM AC / 11:00 AM non-AC). Fact questions (longest/fastest/zones/history/largest) still go to Wikipedia topic-page first.
- `railKbAnswer` normalises "X ka matlab/meaning kya hai" → "X kya" so "RAC ka matlab kya hai" hits the KB.

### Round-18j — 0 direct trains → same-city stations probed automatically (§8)
- Browser E2E "Ludhiana se Mumbai sleeper mein seat hai kya 20 September ko": "Mumbai" resolved to BCT → 0 direct → the agent asked the user to try another station. `SEARCH_TRAINS` now probes cluster siblings (`findAlternateStationOptions`) and returns "YOU MAY ALSO CONSIDER: LDH→BDTS (12926, 12904); LDH→CSMT (11058)" with an explicit instruction to confirm with the user (origin/destination are never switched silently). `AlternateStationOption.allTrainNumbers` added; ranking failures no longer drop a real option.

### Round-18k — build tag + no-cache index.html (stale-UI diagnosis)
- The user kept reporting behaviour that no longer exists on the deployed build. Now the header shows a small build tag (short commit, e.g. `9dd6e9c`) and `GET /api/version` returns `{commit, startedAt, primaryModel, fallbackModel}`. If the header tag ≠ `/api/version.commit`, the browser is serving a cached bundle → hard refresh.
- `index.html` is served with `Cache-Control: no-store`; hashed `/assets/*` are `immutable` (1y). Previously everything was `max-age=0`, which some mobile browsers/CDNs still revalidated lazily.

### Round-18l — "AI journey summary" for any route (screenshot parity)
- `planJourney()` now returns `summary` — a deterministic plain-language line built ONLY from retrieved data: `Best plan: <train> <dep→arr>, <duration> (<class avail>). If it slips, route via <hub> (<legs>, layover) / take <alt train>. Or shift to <Day dd Mon> — N trains.` Shown in the journey card ("AI journey summary" panel), fed to Muse as `JOURNEY SUMMARY` in `RANK_JOURNEY_OPTIONS`, and used verbatim when every model times out (replaces the old model-instruction text that leaked into replies).
- "Goa" is now a multi-station region (MAO/VSG/THVM/KRMI) — RailRadar lookup returned "GOA Gohad Road Halt".
- "is weekend" → date-ask offers the real Sat/Sun dates (never assumed).
- Route-level seat question without a train ("Amritsar se Goa … confirm seat hai?") no longer hits `getAvailability` ("Train, date, stations aur class chahiye") — it goes through the journey flow.
- Muse latency note: no model/timeout config changed in this round. Muse on NIM measures 20–40 s per tool round (see Round-18g-3); when NVIDIA is loaded it exceeds the 40 s per-call cap and GPT-OSS/GLM answer with the same deterministic data.

### Round-18m — "1" picks the 1st train · seat data on fallback · live-status date chooser
- **"1" after a train list** = first train of that list (`resolveTrainNumber` bare-index; only when route is set and no station choice is pending). Reply confirms the train and asks class; never books.
- **Seat availability on fallback:** RailRadar/erail search rows have no class list and RailCore schedule is blocked → `routedClassBoard` had no class codes → probe never ran ("Seat data nahi"). New `webTrainClasses()` discovers classes from the erail fare page (12h cache); the railyatri/railradar seat probe now runs — LDH→NDLS best became 12014 (EC AVL) instead of a WL Vande Bharat.
- **Live status → choose the run date:** "12424 kahan hai" (no date cue) → `routedLiveDates()` probes today-3…today through the same provider chain and returns ONLY dates that have a run (`liveDates` in `/api/agent`); UI shows chips "Aaj (Thu 10) · chal rahi", "Kal (Wed 9) · chal rahi", "Tue 8 · poori" … Tap → "12424 2026-09-09 ka live status" → that run. Explicit cues (kal/parson/date) still go straight to the run.

### Round-18m-2 — stale web rows shown (⚠), alt-date seat proof, no duplicate connections
- **RailYatri rows older than 24h** are no longer hidden (that left cells as "↻ Refresh"): they come through with `stale: true` → UI shows "AVL 80 ⚠" / "WL 13 ⚠" (last known) and never counts as proven seat for ranking/recovery.
- **Alternative date** now probes the fastest train's seat on that date → chip/summary say "22478 CC AVL 43" or "… WL 68"; the summary says "shift to <date>" only with proven AVL/RAC, otherwise "N trains run, seat status unverified". Count is trains, never seats.
- **Connecting journey** — recovery block shows the first 2; the "🔁 Connecting" chip lists only the remaining ones (no duplicates).

### Round-18m-3 — connecting journeys: boarding station, train name, real dates, per-leg seat
- Every connecting leg now shows **train name + boarding/alighting station name (code) + calendar date** (no more bare "+1d"), plus a "↓ Yahan train badlo: Ambala Cant Jn (UMB)" marker.
- **Seat per leg:** `probeConnectionLegs()` probes leg A (origin→hub) and leg B (hub→destination) separately — never origin→destination on a train that doesn't go there. Tapping a leg asks for that leg's segment and date only.

### Round-18m-5 — connecting routes only when BOTH legs have seats
- `bookableConnections()` keeps a connection only if **every leg** has provider-proven, fresh AVL/RAC; WL / N-A / unknown / stale legs are dropped (never shown as an "alternative").
- More candidates: fixed hubs (up to 10 connections) + **route-derived hubs** (`routeDerivedHubs()` — junction/major stops from the direct trains' timetable, e.g. JAT→BDTS tries PTKC/LDH/NDLS/SWM/RTM/BH), all legs probed, then filtered.
- When nothing passes: card + `plan.notes` say "Connecting routes mile lekin kisi mein dono trains par seat available nahi thi — isliye connecting option nahi dikhaya." Summary's "route via X" line lists per-leg seats.

### Round-18m-28 — Route-level seat ask ≠ pichhli selected train
- **Bug (user screenshot 02:09):** pichhli chat mein 12426 select thi; "Muje jammu se ndls jaana hai aaj seats dikhao" par app ne SIRF 12426 ka CHECK_AVAILABILITY chalaya (3A/2A/1A WL) — SL nahi, baaki trains nahi, leg-1/leg-2/book-from-earlier/book-upto kuch nahi, passengers bhi nahi poochhe.
- **Fix (`mergeAgentContext`, server + client):** user ne ROUTE (from+to) bola aur koi train number/naam nahi → stale selected train clear → pax gate → poora planner (har train × har class, origin→boarding, boarding→destination, +2–3 stations book-upto, connections leg-1/leg-2). Exceptions: text mein train number/naam; ya pichhla turn train-specific slot-ask tha (`12426 seats?` → `route+date?`).
- Tests: `tests/round18m28-route-ask-not-stale-train.test.ts` (5, incl. runAgent end-to-end: pax gate fires, no getAvailability on 12426) — total 767.

### Round-18m-27 — RAC current position + IRCTC ticket fare (railyatri parity)
- **Bug (user screenshot 12426 JAT→NDLS 3A):** railyatri site "8 RAC ₹1520", app "RAC 63 ₹1,705". Data live hi tha (data_from IRCTC, fresh), parse galat tha.
- IRCTC text `"RAC  63/RAC   8"` = booking-time RAC 63 / **current RAC 8**; `"GNWL2/RAC26"` = current RAC 26 (app pehle "WL 2" dikhata tha). Ab "/" ke baad wala CURRENT status hi liya jata hai — WL ke liye ye pehle se tha, RAC ke liye fix.
- Fare: `ticket_fare` (IRCTC fare, jo site dikhati hai) — `total_fare` mein RailYatri catering (₹185) judi thi. Catering ho to webNote mein "fare ₹1520 + optional catering ₹185".
- Tests: `tests/round18m27-rac-current-position.test.ts` — total 762.

### Round-18m-26 — Ek colour scheme har jagah + "kitna purana data"
- **Legend** (journey card ke header + Train Board ke upar): 🟩 green = Available (AVL/RAC) · 🟫 tan = Purana/stale data · 🟦 blue = Waitlist · 🟥 red = Not available / Regret.
- **Stale rows tan rehte hain**, par label ke saath **"12 din pehle ka data"** (min/ghante/din — provider ke `last_updated_at` se; timestamp na ho to "purana data"). Label khud (AVL 56 / WL 4) provider ka hi rehta hai — kabhi rewrite nahi.
- Age path: railyatri `last_updated_at` → `ClassAvailability.updatedAt` (ISO) → `RouteAvailability.asOf` → client (`SeatPill`, class chips, Train Board cell `tb-avl-age`).
- Same palette: `jx-seat-*`, `jx-cchip-*` (journey card), `.chip.*` (results), `.tb-avl.*` (board), `.jo-avl-*` (alternatives). WL ab violet nahi — blue; N/A ab grey/strike nahi — red.
- Tests: `tests/round18m26-colour-scheme.test.tsx` (3) — total 761.

### Round-18m-25 — Fresh RailYatri data (live retry), green AVL always, fare in seat pill

User (JAT→NDLS, 12:57 IST): side pill "2A AVL 56" had no fare; stale AVL looked tan/yellow; data was
12 days old. Findings: RailYatri `refresh=true` (live IRCTC) intermittently returns "Unable to perform
Transaction, Please try later" and we immediately fell back to the 12-day cache (which said AVL 56;
live said WL 4). Fixes: (1) `scrapeSeatAvailabilityWeb` retries the live call twice (1.5 s apart)
before touching the cache — maintenance-window errors skip the retry; (2) `SeatPill` shows
`· ₹fare`; (3) AVL/RAC chips and pills are green even when stale — freshness is conveyed by the
"(Not fresh)" / "↻ Refresh" tag and a dashed border (`.jx-cchip-notfresh`), never by colour.
Test: `tests/round18m25-live-retry-green-fare.test.tsx`.

### Round-18m-24 — No phantom "2S" column

User screenshot (LDH→CNB board): 22432 / 18310 showed a "2S — Refresh" column although those trains
have no 2S coach. Cause: erail's trains-between list writes `2S` for unreserved/GN too. Fix in
`parseErailTrainList`: the same row's rake composition (`…:S,S1,SL:B,B1,3A:…`) is parsed and the
class list is pruned to reserved classes actually present in the rake (never adds, only removes;
rows without rake data are left untouched). Verified live: 22432 → 1A 2A 3A 3E SL; 12057 Janshatabdi
keeps 2S. Test: `tests/round18m24-no-phantom-2s.test.ts`.

### Round-18m-23 — No invented "reference fare"; segment-only web fare; IRCTC maintenance fallback

User screenshot (LDH→BSB, 23:54 IST): every direct train "Seat data provider se nahi aayi", and the
agent replied "Fare reference: 2A ₹3000, 3A ₹2090, SL ₹815" — those were 13152's WHOLE-ROUTE
(JAT→Kolkata) fares from erail, not LDH→BSB (real segment: 2A ₹1960 / SL ₹530). Fixes:
1. `scrapeTrainFareWeb(train, from, to)` → erail `?from=&to=` segment page; the page's selected
   from/to selects are verified (`erailPageIsForSegment`) — mismatch → null. Router passes from/to on
   every erail fare path (availability fare-fill, fare-only rows, `getFare` breakdown). Whole-route
   fare is never presented as a segment fare.
2. Agentic CHECK_AVAILABILITY (class board): all classes UNKNOWN → FAIL result (no ok+fares), fare
   fields zeroed unless segment-verified; system prompt forbids "reference/approx/route" fares when
   seat status is unknown.
3. RailYatri SA: IRCTC daily maintenance (~23:45–00:20 IST) makes `refresh=true` return
   `success:false` — now falls back to RailYatri's cached endpoint (real IRCTC data with
   `cache_text`, same 24h stale guard) instead of "seat data nahi aayi".
Tests: `tests/round18m23-segment-fare-no-invent.test.ts`; `router.test.ts` erail mock now a segment page.

### Round-18m-22 — RAC treated as an available seat (green)

User rule: RAC berths confirm after chart preparation, so RAC must be treated like AVAILABLE —
bookable for any party size, green everywhere — while the provider's label/data stay untouched
(`SL RAC 7` remains `SL RAC 7`; nothing is rewritten to AVL). AVL still ranks above RAC when both
exist (`AVAIL_RANK`), so RAC is used when no AVL is found. Changes: `enoughSeats` accepts RAC for
any pax (was ≤2); `findAlternativeTrains` reason `rac` → no alternatives pushed; agentic
CHECK_AVAILABILITY auto-alternatives no longer treat RAC as poor; TrainBoard RAC tap no longer opens
the alternatives sheet; JourneyOptions / AlternativesCard / `.chip.rac` / `.tb-avl.rac` are green;
LLM facts (decide.ts) updated. Tests: `tests/round18m22-rac-is-available.test.ts` (+ updated
R18m-9/12/18/18e expectations).

### Round-18m-21 — Dead leg → don't show the other leg

User rule: in a connecting plan, if EITHER leg has zero trains with seats, the whole hub route is
unusable — listing the other leg's seated trains (e.g. "Leg 1 · LDH → UMB · 15 of 20 with seats")
is misleading. `LegPlanCard` now short-circuits: red verdict card ("Leg 2 · UMB → INDB mein kisi
train mein seat nahi — isliye ye connecting route possible nahi") + only the failing leg's checked
list (transparency: every train × class). Section title flips to "Connecting · koi route possible
nahi" when no hub has both legs seated. AI facts (`engine.ts` summary + `decide.ts` candidate
sheet) mark such hubs "NOT usable" so the LLM never recommends the seated leg. Tests:
`tests/round18m21-dead-leg-hides-other-leg.test.ts(x)` (source + jsdom render).

### Round-18m-20 — Direct-train rule: origin→boarding ALL stops + destination+2–3 stops, ALWAYS

User rule (binding): when a DIRECT train has no seat on the user's segment, the engine must (a) check
every earlier stop from the train's ORIGIN up to boarding × every class (book-from-earlier, already
bounded to 15 stops / 20 trains), and (b) check the 2–3 stops AFTER the destination × every class
("Book Upto" — ticket beyond, deboard at destination). Previously (b) ran only when both
book-from-earlier AND connecting routes failed. Now `planJourney` runs the book-upto scan for every
WL direct train that has no fresh earlier-stop seat, regardless of connecting results.
`JOURNEY_CONFIG.bookUptoStops` 6 → 3 (env `BOOK_UPTO_STOPS`) to match the 2–3 stop rule and keep the
turn inside the 180 s budget. Test: `tests/round18m20-direct-always-upto.test.ts`.

### Round-18m-19 — Readability + seat colours + no client-side "1 passenger" assumption
- Seat chips everywhere: **AVL = green, RAC = yellow, WL / Regret / N-A = red** (`.jx-cchip-ok/-warn/-bad`, SeatPill warn now yellow). Checked-list chips no longer repeat the class code ("1A 1A WL 1" → "1A WL 1").
- Headings bolder/larger: "Via <hub>", "Leg 1 · A → B", "Leg 2 …", section titles, class-row labels, and the "N aur trains check ki — seat nahi" button (filled, bold). Nothing else in the layout changed.
- Passengers: client fallback (`planTurn`, used when the server agent times out) assumed 1 pax when a train list/selection existed or after a station/class prompt → now only when the user actually gave a count. Server already resets pax per new journey (R18m-15).

### Round-18m-18 — Connecting legs: every train × every class + ConfirmTkt rescue per leg; always show leg-wise card
- Bug: when no connection had seats on BOTH legs, `legPlans` stayed empty so the leg-wise expansion never ran → user saw nothing under "Connecting" (LDH→INDB). Now the top hub is expanded anyway: leg-1 (origin→hub) and leg-2 (hub→destination) — every train that day × every class (hint = user class + train's full class list).
- Per-leg rescue (only when that leg has no seat): same train, ticket from the train's ORIGIN (all earlier stops) or upto 1–2 stops beyond the leg's destination — `RouteLeg.ticketFrom/ticketUpto`. Card shows "ticket X→Y" tag; tap runs the fresh check on the ticket segment.
- LegPlan carries `leg1All/leg2All` (full boards incl. WL/N-A). Card lists "N aur trains check ki — seat nahi (dekho)" with tappable class chips so the user can see every train × class that was checked. AI candidate sheet gets the same coverage facts.
- `probeConnectionLegs` now probes every class of each leg train (was user-class only). Bounded: 1 hub, 20+20 trains, rescue 4 trains/leg → ~85s worst case.

### Round-18m-17 — LIVE IRCTC seat data via RailYatri refresh + "GNWL/AVAILABLE" parse fix (real seat found)
- RailYatri SA API with `refresh=true` pulls LIVE from IRCTC (`data_from:"IRCTC"`, timestamp now) instead of a days-old cache — fresh seat data even when RailCore/RailKit/RailRadar quotas are exhausted. Scraped rows carry `live:true`.
- Parser: IRCTC live text `GNWL/AVAILABLE` (quota GNWL, current status AVAILABLE) was mis-read as WAITLIST → now AVAILABLE; `GNWL/RAC n` → RAC. Regression tests.
- Book-upto combo scan: ALL earlier stops (to train origin) × nearest 3 later stops (was 3×3 — missed JAT, 6 stops before LDH).
- Verified live 2026-09-12: LDH→INDB 13 Sep, 12920 Malwa Exp — every class WL; engine found **Book From JAT · Board LDH · Deboard INDB · Book Upto DADN → 1A AVAILABLE ₹4,345** (same as ConfirmTkt).

### Round-18m-16 — ConfirmTkt-style "Book Upto" seat finder (ticket beyond destination)
- User screenshot (LDH→INDB, 12920 Malwa Exp): direct WL, but ConfirmTkt found **Book From JAT · Boarding LDH · Deboarding INDB · Book Upto DADN → 1A AVL**.
- `findBoardFromEarlier` now has `mode: "upto"`: for every WL direct train it probes origin→(stops after destination, up to `BOOK_UPTO_STOPS`=6) and earlier×later combos (3×3), **every class**, provider-proven rows only.
- Runs ONLY when direct ✗, book-from-earlier ✗ and connecting ✗ (user rule). Options carry `bookUpto/bookUptoName/bookUptoArrival/stopsAfter`; candidate id `B:<train>:<from>><upto>`; AI decision sheet + why-points explain "ticket upto X, deboard at destination, pay fare upto X".
- UI: 4-column strip (Book from · Boarding · Deboarding · Book upto) + green note; class chips / row taps run the fresh check on the ticket segment (bookFrom→bookUpto).

### Round-18m-15 — Passenger count re-asked per journey; leg-1 scan all trains × every class
- New route (from/to changed) without pax in the same message → `passengers/paxProvided` reset on server + client (`CLEAR_PASSENGER_COUNT`) — no more silent "1 passenger".
- Book-from-earlier scan: 10 → 20 trains, hint = user class + train's full class list; audit strip shows leg-1/leg-2 coverage.

### Round-18m-14 — RailCore key rotated, leg-1/leg-2 full coverage, tappable class chips (refresh)

- RailCore key rotated (local `.env` + Render env). Search + seats back on `railcore` (fresh); 20 req/min → direct probe now **two-pass**: pass-1 one priority class per train (user class → SL/3A/CC/2S…) = guaranteed fresh row per train; pass-2 remaining classes (fresh if budget, else verified web cache flagged stale).
- Connecting legs: `expandLegPlan` probes **every train running that day** on leg-1 (origin→hub) and leg-2 (hub→destination), bounded 20/leg (specials included — search is date-filtered), **every class** (hint = user class + train's class list), `classOptions` = full board incl. WL/stale.
- UI: every class chip (direct board, hero, same-train alternatives) is a **button** → taps auto-type "NNNNN ki fresh seat availability CLS DATE ko FROM se TO" in chat, sends it, thread scrolls to the reply (fresh provider check, YOU MAY ALSO CONSIDER card). Stale chips read "↻ Refresh". Unprobed train row → "↻ check karo".

### Round-18m-13 — AI decides the journey plan (engine = data only)

User: "engine ki jagah AI journey planner handle kare — recommendation, seat availability, leg-1/leg-2 — sab AI samajh ke." Also: direct trains first in the card; explain why 13308-from-PHR beat 14624.

- New `server/journey/decide.ts`: engine builds a **candidate sheet** (every direct train × every class board, same-train earlier-stop options, connecting legs — each with FRESH / STALE / NOT CHECKED tiers) and the **LLM (Muse → gpt-oss fallback) decides**: `recommendedId`, `ranking`, Hinglish `verdict`, 4–5 `why` points. Grounded: ids only, WL/unchecked never "seat hai", ₹ only real fares, ids humanised to train no + name. Model fail → `rulesDecision` (source `"rules"`), never blank.
- `plan.decision` (+ `verifyFirst`: faster DIRECT train whose AVL is only in 24h+ web cache → "Pehle ye check karo" strip with Seat check button). `applyDecision` re-orders `best`/`boardFromEarlier`/`connections` so hero == AI pick.
- Card order: header → **Direct trains (all, departure-sorted, full class board, AI pick tag)** → AI ka faisla → Verify-first → AI Recommended hero → alternatives → explore.
- Why 13308-from-PHR over 14624: 14624's AVL 11 was STALE (railyatri cache 24h+), 13308 PHR→SRE 1A AVL 11 was FRESH provider data. AI now says this explicitly and tells you to Seat-check the faster stale train first.
- Tests `tests/round18m13-ai-decision.test.ts` (728 total).

### Round-18m-12 — Every train × every class seat-probe, stale-AVL tier, RAC as option

Bug (user screenshot LDH→SRE "kal"): planner said "direct mein koi seat nahi" while the board showed 12588 1A AVL 2 and 14682 2S AVL 559. **Engine fault, not AI**: `JOURNEY_AVAIL_PROBE` defaulted to 4 → only the 4 fastest trains were seat-checked; the rest were silently counted as "no seat".

- `planJourney`: probes **every direct train (bounded 20) × every class** in parallel; `RouteOption.classOptions[]` = full class board (AVL/RAC/WL/N-A, stale flag), `probed` flag per train.
- `directUnavailable` only when every probed train has no fresh AND no stale bookable row. New `directStaleAvailable`: AVL/RAC seen only in 24h+ web cache → "available (not fresh) — verify" tier (never "seat nahi"). Unprobed trains → explicit note ("seat data nahi aayi — 'seat nahi' nahi maana").
- Ranking pax-aware: fresh bookable for N pax → stale bookable → rest. `recommendedOf` / summary / UI hero share one rule: fresh same-train book-from-earlier beats a stale or slower best.
- UI: hero shows "All classes (this train)" (RAC rows included), new **"Seat check · every train, every class"** section listing each direct train's full board + unprobed trains; pills show the stale tier.
- Tests: `tests/round18m12-probe-all.test.ts` (724 total).

### Round-18m-11 — Station-safety fix (prayagraj ≠ Agra), alt-row book/board/deboard, audit strip

- **Bug (screenshot):** "ludhiana se prayagraj" → AGC. Root cause: `matchStation()` ka `q.includes(city)` — "pr**agra**j" ke andar "agra" substring. Fix: city sirf **whole-word** match; fuzzy matcher ke liye `DISTINCT_CITIES` guard (raipur→Jaipur jaisi 1-edit galtiyan bhi band). Prayagraj/Allahabad ab `MULTI_STATION_CITIES` group (PRYJ → PCOI → PRRB → PYGS); goods/power-plant sidings aur "PRYJ2" duplicates options se hidden (`isPassengerStation`).
- **Same-train alternatives rows:** ab har row mein hero jaisi strip — **Book from / Boarding / Deboarding** (station name, code, time, +1d), duration · board-at, other-class chips.
- **Audit strip** card ke upar: "Checked for N pax: x/y direct trains · a trains × b earlier-stop segments (leg-1, every class) · via HUB: p + q trains (leg-1 + leg-2)" — sirf real counts. Book-from-earlier scan ab train origin tak (15 stops) jaata hai.
- Tests: `tests/round18m11-station-safety.test.ts` (5).

### Round-18m-10 — Leg-wise joint planning (all trains per leg), AI-written "kyun chuna", pax gate hardening

- **Leg-wise plan (`plan.legPlans[]`):** direct seat na mile to top hub (e.g. NDLS) ke liye **Leg 1 = origin→hub ki HAR train** aur **Leg 2 = hub→destination ki HAR train** (10+10, parallel) par pax-aware seat probe (`expandLegPlan`). UI mein "Connecting · leg-wise seat options": upar **AI ka joint best combo**, phir "Leg 1 · N of M with seats" / "Leg 2 · N of M with seats" lists — user apna combo bhi bana sakta hai. `buildLegPlans()` baaki hubs ko probed connections se group karta hai.
- **"AI ne ye plan kyun chuna" — AI-written:** `aiWhyPoints()` model (Muse primary 12s → gpt-oss 12s → rules) ko sirf **facts sheet** deta hai (`whyFactsSheet`: har direct train ka seat status, bfe options, leg-wise counts, pre-computed COMPARISON/PRACTICAL/RISK lines, explicit RECOMMENDED/REJECTED). Output grounding-checked: unknown train no./₹ amount, WL train ko "confirmed" bolna, galat "fastest" claim → point drop; 4–5 se kam ho to rules-based points se top-up. `whySource: "ai"|"rules"` → UI "AI-WRITTEN" tag.
- **Passenger gate:** bare "2" → server explicit search text banata hai (model "2 se kya matlab" nahi poochta); client deterministic `resumeAsk` par bhi `lastAsked` set karta hai. Station-pick / date-follow-up flows ke baad bhi gate fire hota hai (verified).
- Tests: `tests/round18m9-pax-gate.test.ts` (+3: buildLegPlans, facts sheet, UI wiring).

### Round-18m-9 — Passenger-aware planning, full-route 2-leg search, journey card v3

- **Passenger gate:** origin + destination + date pata hone par, train dhundhne/seat verify karne se PEHLE AI poochta hai "kitne passengers hain? (1–6)". Jawab ("2") deterministic resume ban kar poori search chalata hai — origin/destination/date change nahi hote. Seats ab `seats ≥ passengers` par hi "confirmed" maani jaati hain (RAC sirf ≤2 pax).
- **Joint 2-leg planning:** leg-1 = train ke origin se boarding tak HAR station × HAR class × HAR train (`findBoardFromEarlier(passengers)`); leg-2 = boarding → destination full route par har train ki availability (`findConnections` fan-out 8 legs/hub, 40 candidates, 24 probes). `bookableConnections()` class-agnostic — jis class mein pax ke liye seat ho wahi leg par dikhti hai; AI seat-proven + fastest combo chunta hai.
- **"AI ne ye plan kyun chuna":** `journeyWhyPoints(plan)` 4–5 genuine, data-driven points banata hai (kitni direct trains check hui, bfe seat+fare, duration vs fastest, other classes, IRCTC boarding note, connecting comparison) → `journey.whyPoints[]`.
- **Journey card v3 (`.jx-*`):** header "RAILBOOK ATLAS · JOURNEY PLAN" LDH → LKO + date/pax/trains pills; status pills (Direct / Recommended / Connecting); hero "RECOMMENDED · SAME TRAIN" (train, class AVL badge, 3-col Book-from / Boarding / Deboarding strip, duration·direct·fare row, Available/Other classes chips, "Availability may have changed" note, orange "Seat check 2A →", navy "SABHI TRAINS · BOOK →", light-blue why-list); Same-train alternatives (+N options), Connecting card, Other dates (N alternatives), Explore options chips, footer source/last-checked.
- Tests: `tests/round18m9-pax-gate.test.ts`; 4 older tests updated for the gate (now pass `2 logon ke liye`).

### Round-18m-8 — journey card layout v2 (results page, not chat) + new RailCore/RailKit keys

- Chat prose collapses into an "AI note" pill when a journey card is the answer; the card is the result.
- Card: navy route hero (`LDH → LKO`, date/class/train pills) → status pills (Direct: seat nahi · Same train pichhle station se: 2A AVL 36 · Connecting …) → **BEST FOR YOU** hero = the fresh seat-proven book-from-earlier option (ConfirmTkt-style Book from / Boarding / Deboarding strip, duration/seat/fare grid, all seat classes as chips, LDH→LKO vs PHR→LKO key-value lines, "Seat check" + "Sabhi trains · Book" CTAs) → collapsible "AI ne ye plan kyun chuna" → numbered sections with counts (aur same-train options, doosri train, connecting, doosri date, doosra station) → YOU MAY ALSO CONSIDER tabs.
- Keys rotated (RailCore `rk_live_0yKp…`, RailKit `railkit_c842…`) in `.env` and Render env; RailCore search/availability verified live again.

### Round-18m-7 — date survives station pick; no auto TrainBoard; ConfirmTkt-style options for EVERY train & class

- **Date kept across the station-choice turn.** "Ludhiana se Varanasi jaana hai kal" → "1. BSB / 2. BCY" → "Bsb" no longer re-asks the date. Root cause: `mergeAgentContext` (server + client) treated the picked station as a *new route* (`routeChanged`) and reset `date/dateProvided`; a pick that resolves a `pendingDestinationChoice`/`pendingOriginChoice` is now exempt. The station-pick turn also returns the full **journey planner card** (`planJourney`) instead of a plain table.
- Deterministic path fix: the server-verified station pick is stripped from the NLU's `unresolvedTo/From` before `mergeAgentContext` (it was still counted as a "new route" → date reset on prod).
- **Full-screen TrainBoard never auto-opens** after an agent reply (`AUTO_BOARD=false` in `Concierge.tsx`) — the chat journey card is the planner; the board opens only from "Sabhi trains · Book →" / a train pick.
- **Book-from-earlier like ConfirmTkt:** `findBoardFromEarlier` now probes up to `BOARD_EARLIER_TRAINS` (10) direct trains × `BOARD_EARLIER_STOPS` (5) earlier stops, keeps **every** AVL/RAC class (`classOptions`, `bookableRows`), includes stale web-cache rows flagged ⚠ (fresh first), computes boardAt→destination `durationMinutes`, and ranks **fresh seat → AVL>RAC → least travel time → nearest stop**. Card shows up to 8 options with class chips; summary leads with the seat-proven least-time option, lists the other classes and the option count.
- **Connections show every seat class per leg** (`RouteLeg.classOptions` from `probeConnectionLegs`), in the leg rows and in the summary ("12426 3A AVL 5/SL RAC 3, …").

### Round-18m-6 — honest "best plan" + ConfirmTkt-style "book from earlier station"
- **Ranking fix:** a seat-proven (fresh AVL/RAC) option always outranks WL/N-A/unknown — even a connecting route; "no seat data" no longer ties with AVAILABLE (13152 bug). Connecting option's combined availability = weakest leg.
- **Summary says why:** "… (SL WL 27) — kisi option mein confirmed seat nahi; ye sabse kam WL/fastest direct hai" or "— direct trains mein seat nahi, is route par dono legs available".
- **Book from earlier station** (`findBoardFromEarlier`, `recovery.boardFromEarlier`): for each WL direct train, timetable → up to 3 stops before origin → probe bookFrom→destination → keep AVL/RAC. Card shows Book from / Boarding / Deboarding (e.g. 13308: book Phillaur Jn PHR 19:00, board Ludhiana Jn LDH 19:55 — 2A AVL 19 ₹1545). Summary leads with it when best is WL. Provider-proven only, never invented.

## Extra fallback APIs (Round-16o, optional)

Data chain per method: **RailCore → RailKit → RailRadar → Indian Rail API → verified-site web-scrape → none**. The two new providers are *additional* and fully optional — with no key set they are skipped and nothing else changes.

| Provider | Env var | Signup | Covers |
| --- | --- | --- | --- |
| RailRadar (`api.railradar.in/v1`) | `RAILRADAR_API_KEY` (`rr_live_…`) | https://railradar.in/developers — free sandbox, 1,000 req/month, no card | trains-between, seat availability, fare, live status, schedule, coach position, station + train-name autocomplete |
| Indian Rail API (`indianrailapi.com/api/v2`) | `INDIANRAILAPI_KEY` | https://indianrailapi.com (register → API key; seat availability needs Advanced/Enterprise plan) | schedule, live status, fare, coach position, station + train autocomplete, (seat availability on paid plan) |

Train-name search additionally falls back to the erail.in train list (`web_erail`) when every API is limited. General/knowledge questions that no provider can answer are auto-answered from the web (Wikipedia/KB/DDG) — never "provider se nahi mil pa rahi" for a non-booking question.
